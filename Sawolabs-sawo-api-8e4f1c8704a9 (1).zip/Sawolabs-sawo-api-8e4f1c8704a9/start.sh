#!/bin/sh
echo "Starting WSGI server"
uwsgi uwsgi.ini
