#!/bin/sh
echo "Starting celery"
celery -A sawo worker -l info 
