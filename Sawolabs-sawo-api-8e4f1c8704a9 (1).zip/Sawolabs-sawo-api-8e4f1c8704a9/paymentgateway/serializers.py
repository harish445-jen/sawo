from rest_framework import serializers


class OrderSerializer(serializers.Serializer):
    price = serializers.IntegerField()
    currency = serializers.CharField()
    country_code = serializers.CharField()
    plan_type = serializers.CharField()
    receipt = serializers.UUIDField(read_only=True)

    def validate(self, data):
        data['plan_type'] = data.get('plan_type', '').lower()
        return data


class ConfirmOrderSerializer(serializers.Serializer):
    price = serializers.IntegerField()
    currency = serializers.CharField()
    plan_type = serializers.CharField()
    order_id = serializers.CharField()
    payment_id = serializers.CharField()
    signature = serializers.CharField()
    subscription_id = serializers.CharField()


class ShopifyOrderSerializer(serializers.Serializer):
    price = serializers.IntegerField()
    currency = serializers.CharField()
    plan_type = serializers.CharField()
    order_id = serializers.CharField()
    payment_id = serializers.CharField()
    subscription_id = serializers.CharField()
    shopify_app = serializers.BooleanField()