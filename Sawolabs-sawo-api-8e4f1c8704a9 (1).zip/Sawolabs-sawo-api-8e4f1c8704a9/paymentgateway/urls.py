from django.urls import path

from . import apis

urlpatterns = [
    path('placeorder/', apis.PlaceOrder.as_view()),
    path('confirmorder/', apis.ConfirmOrder.as_view()),
    path('shopifyBilling/', apis.ShopifyBilling.as_view()),
]
