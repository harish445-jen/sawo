import razorpay
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from uuid import uuid4

from authhelper.auth import SawoAuthentication
from authhelper.permissions import IsAuthenticated
from authhelper.collections import sawo_users_collection

from client.collections import sawo_clients_purchased_plan_collection
from paymentgateway.collections import sawo_razorpay_plans

from client.permissions import IsClientUser

from paymentgateway.serializers import OrderSerializer, ConfirmOrderSerializer, ShopifyOrderSerializer

from sawo.settings.base import get_env_var
from datetime import datetime
from pymongo import ReturnDocument

client = razorpay.Client(auth=(get_env_var("RAZORPAY_KEY_ID"),
                               get_env_var("RAZORPAY_SECRET")))


class PlaceOrder(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = OrderSerializer(data=request.data)
        if serializer.is_valid():
            receipt_id = str(uuid4())
            orderData = {
                "amount": serializer.validated_data['price'] * 100,
                "currency": serializer.validated_data['currency'],
                "receipt": receipt_id,
                "notes": {
                    "plan_type":
                    serializer.validated_data['plan_type'],
                    "client_id":
                    str(request.user['_id']),
                    "client_name":
                    request.user['first_name'] + ' ' +
                    request.user['last_name'],
                    "client_email":
                    request.user['identifier']
                }
            }
            response = client.order.create(orderData)

            if response['status'] == 'created':
                associated_plan = sawo_razorpay_plans.find_one({
                    'country_code': serializer.validated_data[
                        'country_code'],
                    'plan_type': serializer.validated_data[
                        'plan_type']
                })
                new_subscription = client.subscription.create(data={
                    'plan_id': associated_plan['plan_id'],
                    'total_count': 6,  # no. of months in the billing cycle
                    'quantity': 1,
                    'customer_notify': 1
                })
                orderData['id'] = response['id']
                orderData['subscription_id'] = new_subscription['id']
                return Response(orderData)
            else:
                return Response({'error': 'Problem with creating Order.'},
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ConfirmOrder(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):

        serializer = ConfirmOrderSerializer(data=request.data)

        if serializer.is_valid():
            params_dict = {
                'razorpay_payment_id': serializer.validated_data['payment_id'],
                'razorpay_subscription_id': serializer.validated_data['subscription_id'],
                'razorpay_signature': serializer.validated_data['signature']
            }
            try:
                client.utility.verify_subscription_payment_signature(
                    params_dict)
                plantoken = {
                    'is_consumed': False,
                    'related_client_id': request.user["_id"],
                    'plan_currency_code':
                    serializer.validated_data["currency"],
                    'plan_type': serializer.validated_data['plan_type'],
                    'price': serializer.validated_data['price'],
                    'order_id': serializer.validated_data['order_id'],
                    'payment_id': serializer.validated_data['payment_id'],
                    'subscription_id': serializer.validated_data[
                        'subscription_id'],
                    'created_at': datetime.utcnow()
                }
                sawo_clients_purchased_plan_collection.insert_one(plantoken)

                plantoken.pop('_id')
                plantoken.pop('is_consumed')
                plantoken['related_client_id'] = str(
                    plantoken['related_client_id'])
                return Response(plantoken)

            except Exception as e:
                print("EXCEPTION IN CONFIRMORDER: ", e)
                return Response({'error': 'Payment could not be verified.'},
                                status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ShopifyBilling(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = ShopifyOrderSerializer(data=request.data)
        if serializer.is_valid():
            try:
                plantoken = {
                    'is_consumed': False,
                    'related_client_id': request.user["_id"],
                    'plan_currency_code':
                    serializer.validated_data["currency"],
                    'plan_type': serializer.validated_data['plan_type'],
                    'price': serializer.validated_data['price'],
                    'order_id': serializer.validated_data['order_id'],
                    'payment_id': serializer.validated_data['payment_id'],
                    'subscription_id': serializer.validated_data[
                        'subscription_id'],
                    'shopify_app': serializer.validated_data['shopify_app'],
                    'created_at': datetime.utcnow(),

                }
                sawo_clients_purchased_plan_collection.insert_one(plantoken)

                plantoken.pop('_id')
                plantoken.pop('is_consumed')
                plantoken['related_client_id'] = str(
                    plantoken['related_client_id'])
                return Response(plantoken)
            except Exception:
                return Response({'error': 'Payment could not be verified.'},
                                status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
