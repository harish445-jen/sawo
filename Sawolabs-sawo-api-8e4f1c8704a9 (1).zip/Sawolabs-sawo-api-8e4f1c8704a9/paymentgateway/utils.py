from django.core.mail import EmailMultiAlternatives
from django.template import loader


def send_plan_upgrade_emailer(email, parameters):
    email_template = loader.get_template('client/emails/billing-emailer.html')
    msg = EmailMultiAlternatives('Plan upgrade request.',
                                 'Plan upgrade',
                                 'noreply@sawolabs.com', [email])
    msg.attach_alternative(
        email_template.render(parameters), 'text/html')
    return msg.send()

def send_plan_expired_emailer(email, parameters):
    email_template = loader.get_template('client/emails/billing-emailer.html')
    msg = EmailMultiAlternatives('MONTHLY USAGE LIMIT EXCEEDED',
                                 'Usage exceeded',
                                 'noreply@sawolabs.com', [email])
    msg.attach_alternative(
        email_template.render(parameters), 'text/html')
    return msg.send()