from celery import shared_task
from paymentgateway.utils import send_plan_expired_emailer, send_plan_upgrade_emailer


@shared_task
def task_send_plan_upgrade_emailer(email: str, parameters: dict):
    return send_plan_upgrade_emailer(email, parameters)

@shared_task
def task_send_plan_expired_emailer(email: str, parameters: dict):
    return send_plan_expired_emailer(email, parameters)
