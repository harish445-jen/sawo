from django.urls import path

from blog import apis

urlpatterns = [
    path('', apis.BlogAPI.as_view()),
    path('admin/', apis.BlogAdminAPI.as_view())
]
