import os

from django.conf import settings
from django.utils.crypto import get_random_string
from django.utils.text import slugify

from blog.collections import sawo_blogs_collection


def save_image(image):
    image_dir = os.path.join(settings.MEDIA_ROOT, 'blog_images')
    if not os.path.isdir(image_dir):
        os.makedirs(image_dir)
    dest_file_path = os.path.join(image_dir, image.name)
    if os.path.isfile(dest_file_path):
        image_s = image.name.split('.')
        image_s[0] = image_s[0] + '-' + get_random_string(length=6)
        if len(image_s) > 1:
            image_name = image_s[0] + '.' + image_s[1]
        else:
            image_name = image_s[0]
        dest_file_path = os.path.join(image_dir, image_name)
    with open(dest_file_path, 'wb') as image_file:
        for chunk in image.chunks():
            image_file.write(chunk)
    image_url = "{}blog_images/{}".format(
        settings.MEDIA_URL, dest_file_path.split('/')[-1])
    return image_url


def save_pdf(pdf_file):
    pdf_dir = os.path.join(settings.MEDIA_ROOT, 'whitepaper_pdfs')
    if not os.path.isdir(pdf_dir):
        os.makedirs(pdf_dir)
    dest_file_path = os.path.join(pdf_dir, pdf_file.name)
    if os.path.isfile(dest_file_path):
        pdf_f = pdf_file.name.split('.pdf')
        pdf_f[0] = pdf_f[0] + '-' + get_random_string(length=6)
        pdf_name = pdf_f[0] + '.pdf'
        dest_file_path = os.path.join(pdf_dir, pdf_name)
    with open(dest_file_path, 'wb') as final_pdf:
        for chunk in pdf_file.chunks():
            final_pdf.write(chunk)
    pdf_url = "{}whitepaper_pdfs/{}".format(
        settings.MEDIA_URL, dest_file_path.split('/')[-1])
    return pdf_url


def get_slug(slug: str) -> str:
    slug = slugify(slug)
    blog = sawo_blogs_collection.find_one({'slug': slug})
    if blog:
        slug = "{}-{}".format(slug, get_random_string(6))
    return slug
