from rest_framework import serializers


blog_schema = [
    'title', 'slug', 'content', 'of_type',
    'main_image_url', 'author_id', 'created_on', 'is_published'
]


class BlogSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=255)
    slug = serializers.CharField(max_length=80)
    of_type = serializers.CharField(max_length=80)
    content = serializers.CharField()
    main_image = serializers.ImageField()
    pdf_upload = serializers.FileField(required=False, allow_empty_file=True)
    is_published = serializers.BooleanField()
    external_url = serializers.CharField(required=False)


class BlogUpdateSerializer(serializers.Serializer):
    _id = serializers.CharField()
    title = serializers.CharField()
    of_type = serializers.CharField(max_length=80)
    main_image = serializers.ImageField(required=False)
    pdf_upload = serializers.FileField(required=False)
    external_url = serializers.CharField(required=False)
    content = serializers.CharField()
