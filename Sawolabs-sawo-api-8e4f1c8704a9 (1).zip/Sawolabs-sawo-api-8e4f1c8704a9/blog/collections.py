from pytz import timezone
from bson.codec_options import CodecOptions

from sawo.mongodb import db

from django.conf import settings


sawo_blogs_collection = db.sawo_blogs.with_options(
    codec_options=CodecOptions(
        tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))
