from datetime import datetime
# from bson.ObjectId import ObjectId
from core.utils import toObjectId
from pymongo import DESCENDING

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, parsers

from authhelper.permissions import IsAuthenticated
from authhelper.auth import SawoAuthentication
from authhelper.collections import sawo_users_collection

from admindash.permissions import IsSawoAdmin

from blog.collections import sawo_blogs_collection
from blog.serializers import (BlogSerializer, BlogUpdateSerializer)
from blog.utils import (save_image, get_slug, save_pdf)


class BlogAdminAPI(APIView):
    """
    This view will be used to do CRUD operations on blog
    by admins
    """

    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )
    parser_classes = (parsers.FormParser, parsers.MultiPartParser,
                      parsers.JSONParser)

    def get(self, request, format=None):
        blogs = []
        blogs_cursor = sawo_blogs_collection.find({}).sort('_id', DESCENDING)
        for blog in blogs_cursor:
            author = sawo_users_collection.find_one({'_id': blog['author_id']},
                                                    {
                                                        'auths_remaining': 0,
                                                        'auths_filled': 0
                                                    })
            author.pop('_id')
            blog['author'] = author
            blog['_id'] = str(blog['_id'])
            blog.pop('author_id')
            blogs.append(blog)
        return Response(blogs)

    def post(self, request, format=None):
        serializer = BlogSerializer(data=request.data)
        if serializer.is_valid():
            blog = serializer.validated_data
            author = sawo_users_collection.find_one(
                {'_id': request.user['_id']}, {
                    'auths_remaining': 0,
                    'auths_filled': 0
                })
            blog['author_id'] = author['_id']
            blog['created_on'] = datetime.utcnow()
            blog['main_image_url'] = save_image(
                serializer.validated_data['main_image'])
            if blog['of_type'] == 'wp' and serializer.validated_data[
                    'pdf_upload']:
                blog['pdf_url'] = save_pdf(
                    serializer.validated_data['pdf_upload'])
            if blog['of_type'] == 'ps' and serializer.validated_data[
                    'external_url'] != "":
                blog['external_url'] = serializer.validated_data[
                    'external_url']
            else:
                if 'external_url' in blog:
                    blog.pop('external_url')
            blog['slug'] = get_slug(serializer.validated_data['slug'])
            blog['type'] = blog['of_type']
            blog.pop('main_image')
            if 'pdf_upload' in blog:
                blog.pop('pdf_upload')
            blog.pop('of_type')
            inserted_blog = sawo_blogs_collection.insert_one(blog)
            blog['_id'] = str(inserted_blog.inserted_id)
            blog.pop('author_id')
            author.pop('_id')
            blog['author'] = author
            return Response(blog)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, format=None):
        serializer = BlogUpdateSerializer(data=request.data)
        if serializer.is_valid():
            blog = sawo_blogs_collection.find_one(
                {'_id': toObjectId(serializer.validated_data['_id'])})
            if blog:
                main_image_url = blog['main_image_url']
                if serializer.validated_data.get('main_image', None):
                    main_image_url = save_image(
                        serializer.validated_data['main_image'])
                update_fields = {
                    'title': serializer.validated_data['title'],
                    'content': serializer.validated_data['content'],
                    'main_image_url': main_image_url,
                    'type': serializer.validated_data['of_type']
                }
                pdf_url = None
                if blog['type'] == 'wp' and serializer.validated_data.get(
                        'pdf_upload', None):
                    pdf_url = save_pdf(serializer.validated_data['pdf_upload'])
                    update_fields['pdf_url'] = pdf_url
                if blog['type'] == 'ps' and serializer.validated_data.get(
                        'external_url', None):
                    update_fields['external_url'] = serializer.validated_data[
                        'external_url']

                sawo_blogs_collection.update_one({'_id': blog['_id']},
                                                 {'$set': update_fields})
                result = {
                    '_id': str(blog['_id']),
                    'title': serializer.validated_data['title'],
                    'main_image_url': main_image_url,
                    'pdf_url': pdf_url,
                    'content': serializer.validated_data['content'],
                    'type': serializer.validated_data['of_type']
                }
                if 'external_url' in update_fields:
                    result['external_url'] = update_fields['external_url']
                return Response(result)
            return Response(status=status.HTTP_404_NOT_FOUND)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, format=None):
        blog = sawo_blogs_collection.find_one(
            {'_id': toObjectId(request.data['_id'])})
        if blog:
            sawo_blogs_collection.update_one(
                {'_id': blog['_id']},
                {'$set': {
                    'is_published': bool(request.data['is_published'])
                }})
            return Response({
                '_id': str(blog['_id']),
                'is_published': bool(request.data['is_published'])
            })
        return Response(status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, format=None):
        sawo_blogs_collection.delete_one(
            {'_id': toObjectId(request.query_params['_id'])})
        return Response({'_id': request.query_params['_id']})


class BlogAPI(APIView):
    """
    This view will be used to send blog entries
    to landing page
    """
    def get(self, request, format=None):
        blogs = []
        blogs_cursor = sawo_blogs_collection.find({
            'is_published': True
        }).sort('_id', DESCENDING)
        for blog in blogs_cursor:
            author = sawo_users_collection.find_one({'_id': blog['author_id']},
                                                    {
                                                        'auths_remaining': 0,
                                                        'auths_filled': 0
                                                    })
            author.pop('_id')
            if 'is_sawo_admin' in author:
                author.pop('is_sawo_admin')
            if 'is_sawo_client' in author:
                author.pop('is_sawo_client')
            author.pop('identifier')
            blog['author'] = author
            blog['_id'] = str(blog['_id'])
            blog.pop('author_id')
            blogs.append(blog)
        return Response(blogs)
