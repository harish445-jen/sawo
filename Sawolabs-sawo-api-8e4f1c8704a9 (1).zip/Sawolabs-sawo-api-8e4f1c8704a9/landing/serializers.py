from rest_framework import serializers


class NewsletterSignupSerializer(serializers.Serializer):
    email_id = serializers.EmailField()


class ContactSerialier(serializers.Serializer):
    name = serializers.CharField()
    email_id = serializers.EmailField()
    phone_number = serializers.CharField(allow_blank=True)
    message = serializers.CharField(allow_blank=True)
    interested_in = serializers.CharField()


class FeedbackSerializer(serializers.Serializer):
    rating_value = serializers.IntegerField(max_value=5, min_value=1)
    identifier_email = serializers.EmailField()
    feedback_text = serializers.ListField()
    feedback_categories = serializers.ListField()
