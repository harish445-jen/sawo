# from bson.ObjectId import ObjectId
from core.utils import toObjectId

from django.template import loader
from django.core.mail import EmailMultiAlternatives
from django.conf import settings

from landing.collections import contact_request_collection


def send_contact_request_to_admin(id: str) -> int:
    contact_request = contact_request_collection.find_one(
        {'_id': toObjectId(id)})
    if contact_request:
        email_template = loader.get_template(
            'landing/emails/contact_request.html')
        msg = EmailMultiAlternatives(
            'New contact request received', 'Message: {}'.format(
                contact_request['message']),
            'system@sawolabs.com', [settings.CONTACT_REQUEST_EMAIL_ID])
        msg.attach_alternative(email_template.render({
            'contact_request': contact_request
        }), 'text/html')
        return msg.send()
    return 0
