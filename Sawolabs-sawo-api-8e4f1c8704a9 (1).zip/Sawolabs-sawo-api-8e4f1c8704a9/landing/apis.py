from datetime import datetime

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from landing.serializers import (NewsletterSignupSerializer, ContactSerialier,
                                 FeedbackSerializer)
from landing.collections import (newsletter_subscription_collection,
                                 contact_request_collection,
                                 sawo_feedback_collection)
from landing.tasks import task_send_contact_request_to_admin


class NewsletterSignupAPI(APIView):
    """
    This API will be used to handle a newsletter signup
    """

    def post(self, request, format=None):
        serializer = NewsletterSignupSerializer(data=request.data)
        if serializer.is_valid():
            subscription = newsletter_subscription_collection.find_one(
                {'email_id': serializer.validated_data['email_id']})
            if not subscription:
                subscription = {
                    'email_id': serializer.validated_data['email_id'],
                    'created_on': datetime.utcnow()
                }
                newsletter_subscription_collection.insert_one(subscription)
            return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ContactAPI(APIView):
    """
    This API will be used to handle a contact request
    """

    def post(self, request, format=None):
        serializer = ContactSerialier(data=request.data)
        if serializer.is_valid():
            result = contact_request_collection.insert_one(
                serializer.validated_data)
            task_send_contact_request_to_admin.delay(str(result.inserted_id))
            return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class FeedbackAPI(APIView):
    """
    This API will be used to take user feedback
    """

    def post(self, request, format=None):
        serializer = FeedbackSerializer(data=request.data)
        if serializer.is_valid():
            sawo_feedback_collection.insert_one(serializer.validated_data)
            # today = datetime.today()
            # entry_record = str(today.month) + "/" + str(
            #     today.year) + "." + str(
            #         serializer.validated_data['rating_value'])

            # sawo_feedback_collection.update_one({},
            #                                     {"$inc": {
            #                                         entry_record: 1
            #                                     }},
            #                                     upsert=True)
            return Response({'inserted': True})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
