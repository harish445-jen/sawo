from pytz import timezone
from bson.codec_options import CodecOptions

from sawo.mongodb import db

from django.conf import settings

newsletter_subscription_collection = \
    db.sawo_newsletter_subscriptions.with_options(codec_options=CodecOptions(
        tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))


contact_request_collection = \
    db.sawo_contact_requests.with_options(codec_options=CodecOptions(
        tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))

sawo_feedback_collection = \
    db.sawo_feedbacks.with_options(codec_options=CodecOptions(
        tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))
