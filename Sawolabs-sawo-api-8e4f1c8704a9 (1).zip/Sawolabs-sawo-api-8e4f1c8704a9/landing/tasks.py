from celery import shared_task

from landing.utils import send_contact_request_to_admin


@shared_task
def task_send_contact_request_to_admin(id):
    return send_contact_request_to_admin(id)
