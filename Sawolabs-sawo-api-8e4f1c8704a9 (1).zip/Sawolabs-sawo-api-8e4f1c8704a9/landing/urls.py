from django.urls import path

from landing import apis

urlpatterns = [
    path('newslettersignup/', apis.NewsletterSignupAPI.as_view()),
    path('contact/', apis.ContactAPI.as_view()),
    path('sendfeedback/', apis.FeedbackAPI.as_view()),
]
