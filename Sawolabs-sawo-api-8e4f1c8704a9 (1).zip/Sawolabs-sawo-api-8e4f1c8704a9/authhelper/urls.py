from django.urls import path
from authhelper import apis

urlpatterns = [
    path('userprofile/', apis.UserProfileAPI.as_view()),
    path('logout/', apis.LogoutAPI.as_view())
]
