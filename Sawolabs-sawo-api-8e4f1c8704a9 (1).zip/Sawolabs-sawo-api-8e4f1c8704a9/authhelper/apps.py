from django.apps import AppConfig


class AuthhelperConfig(AppConfig):
    name = 'authhelper'
