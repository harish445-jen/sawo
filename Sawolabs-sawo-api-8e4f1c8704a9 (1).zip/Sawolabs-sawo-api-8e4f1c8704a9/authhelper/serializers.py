from rest_framework import serializers

from authhelper.collections import sawo_users_collection


class TokenAPISerializer(serializers.Serializer):
    user_id = serializers.UUIDField()
    created_on = serializers.DateTimeField()
    identifier = serializers.CharField()
    identifier_type = serializers.CharField()
    verification_token = serializers.CharField()


class UserProfileSerializer(serializers.Serializer):
    username = serializers.CharField()
    first_name = serializers.CharField()
    last_name = serializers.CharField()
    email = serializers.CharField(required=False)

    def validate_username(self, value):
        user = sawo_users_collection.find_one({'username': value}, {
            'auths_remaining': 0,
            'auths_filled': 0
        })
        if user and \
                user['username'] != self.context['request_user_username']:
            raise serializers.ValidationError('Username is taken')
        return value
