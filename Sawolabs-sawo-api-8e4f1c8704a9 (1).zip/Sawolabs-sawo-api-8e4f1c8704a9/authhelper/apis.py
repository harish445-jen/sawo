from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from authhelper.auth import SawoAuthentication
from authhelper.permissions import IsAuthenticated
from authhelper.collections import (sawo_users_collection,
                                    sawo_tokens_collection)
from authhelper.utils import update_user

from authhelper.serializers import UserProfileSerializer
from core.utils2 import delay_welcome_email
from threading import Thread


class UserProfileAPI(APIView):
    """
    This API will be used to get/update user profile
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (IsAuthenticated, )

    def get(self, request, format=None):
        profile_data = {
            'username': request.user.get('username', ''),
            'first_name': request.user.get('first_name', ''),
            'last_name': request.user.get('last_name', ''),
            'email': request.user.get('identifier', ''),
        }
        return Response(UserProfileSerializer(profile_data).data)

    def post(self, request, format=None):
        serializer = UserProfileSerializer(data=request.data,
                                           context={
                                               'request_user_username':
                                               request.user.get(
                                                   'username', '')
                                           })
        if serializer.is_valid():
            update_user(request.user, serializer.validated_data)
            user_id = request.user['_id']
            user = sawo_users_collection.find_one({'_id': user_id},
                                                  {
                                                      'auths_remaining': 0,
                                                      'auths_filled': 0
            })
            profile_data = {
                'username': user.get('username', ''),
                'first_name': user.get('first_name', ''),
                'last_name': user.get('last_name', ''),
                'email': user.get('identifier', ''),
            }

            # SEND THE WELCOME EMAIL after some time by Creating a separate thread so that it wont block the main thread

            t = Thread(target=delay_welcome_email, kwargs={
                'profile_data': profile_data, 'user_id': user_id})

            t.start()

            return Response(UserProfileSerializer(profile_data).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LogoutAPI(APIView):
    """
    This API will be used to logout an user
    """

    authentication_classes = (SawoAuthentication, )
    permission_classes = (IsAuthenticated, )

    def post(self, request, format=None):
        sawo_tokens_collection.delete_one({'token': request.auth['token']})
        return Response()
