from django.utils.timezone import now

from rest_framework import exceptions
from rest_framework.authentication import (BaseAuthentication,
                                           get_authorization_header)

from authhelper.collections import (sawo_users_collection,
                                    sawo_tokens_collection)


class SawoAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth = get_authorization_header(request).split()
        if not auth:
            return None
        if auth[0].lower().decode('utf-8') != 'token':
            return None
        if len(auth) == 1:
            msg = 'Invalid token header. No credentials provided.'
            raise exceptions.AuthenticationFailed(msg)
        if len(auth) > 2:
            msg = 'Invalid token header. ' +\
                'Token string should not contain spaces.'
            raise exceptions.AuthenticationFailed(msg)
        user, token = self.get_user_and_token(auth[1])
        return (user, token)

    def get_user_and_token(self, token):
        token = sawo_tokens_collection.find_one(
            {'token': token.decode('utf-8')})
        if token:
            if token['expires_on'] < now():
                sawo_tokens_collection.delete_one({'_id': token['_id']})
                raise exceptions.AuthenticationFailed('Token expired')
            user = sawo_users_collection.find_one(
                {'_id': token['related_user_id']}, {
                    'auths_remaining': 0,
                    'auths_filled': 0
                })
            return (user, token)
        raise exceptions.AuthenticationFailed('Invalid token')
