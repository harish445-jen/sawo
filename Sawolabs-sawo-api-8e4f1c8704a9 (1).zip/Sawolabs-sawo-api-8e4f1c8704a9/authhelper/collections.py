from pytz import timezone
from bson.codec_options import CodecOptions

from sawo.mongodb import db

from django.conf import settings


sawo_users_collection = db.sawo_users.with_options(codec_options=CodecOptions(
    tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))
sawo_tokens_collection = db.sawo_tokens.with_options(
    codec_options=CodecOptions(
        tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))
