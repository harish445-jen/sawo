from datetime import datetime, timedelta

from django.utils.crypto import get_random_string
from django.conf import settings

from authhelper.collections import (sawo_tokens_collection,
                                    sawo_users_collection)
from core.utils import user_collection


def get_or_create_user(identifier: str, verification_token: str) -> tuple:
    created = False
    user = sawo_users_collection.find_one({'identifier': identifier})

    if not user and verify_core_user(identifier, verification_token):
        sawo_users_collection.insert_one(
            {
                'identifier': identifier,
                'ref_id': get_random_string(length=10),
                'joined_at': datetime.utcnow()
            })
        user = sawo_users_collection.find_one({'identifier': identifier})
        created = True
    return (created, user)


def verify_core_user(identifier: str, verification_token: str) -> bool:
    user = user_collection.find_one({'identifier': identifier})
    if user:
        return user['verification_token'] == verification_token
    return False


def update_user(user: dict, update_data: dict) -> None:
    sawo_users_collection.update_one({'_id': user['_id']},
                                     {'$set': update_data})


def get_unique_token() -> str:
    token_str = get_random_string(length=36)
    token = sawo_tokens_collection.find_one({'token': token_str})
    if token:
        return get_unique_token()
    return token_str


def create_token(user: dict) -> dict:
    creation_time = datetime.utcnow()
    token = {
        'token': get_unique_token(),
        'created_on': creation_time,
        'expires_on': creation_time + timedelta(
            seconds=settings.SAWO_USER_TOKEN_EXPIRES_IN),
        'related_user_id': user['_id']
    }
    sawo_tokens_collection.insert_one(token)
    token.pop('_id')
    token.pop('related_user_id')
    return token
