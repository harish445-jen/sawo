from pytz import timezone
from bson.codec_options import CodecOptions

from sawo.mongodb import db

from django.conf import settings

sawo_clients_projects_collection = db.sawo_clients_projects.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

sawo_clients_plans_collection = db.sawo_clients_plans.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

sawo_clients_purchased_plan_collection = db.sawo_clients_purchased_plan \
    .with_options(
        codec_options=CodecOptions(tz_aware=True,
                                   tzinfo=timezone(settings.TIME_ZONE)))

sawo_auths_log_collection = db.sawo_auths_log.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

sawo_premium_plan_collection = db.sawo_premium_plan.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

sawo_referrals_record_collection = db.sawo_referrals_record.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

sawo_clients_address_collection = db.sawo_clients_address.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))