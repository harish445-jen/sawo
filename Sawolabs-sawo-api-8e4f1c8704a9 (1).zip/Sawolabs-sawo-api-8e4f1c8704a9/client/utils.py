from typing import Dict, Optional, List

from uuid import uuid4
from django.utils.timezone import now
from django.core.mail import EmailMultiAlternatives
from django.template import loader
import csv

from admindash.collections import sawo_referrals_collection
from admindash.utils import create_plan

from django.utils.crypto import get_random_string

from authhelper.collections import sawo_users_collection

from client.collections import (sawo_clients_projects_collection,
                                sawo_clients_plans_collection,
                                sawo_referrals_record_collection,
                                sawo_auths_log_collection,
                                sawo_clients_address_collection)

from client.exceptions import CodeExpired, AlreadyUsed

from pydig import query
import requests

from bs4 import BeautifulSoup

import calendar
from datetime import datetime, timedelta
from pytz import timezone
# from bson.ObjectId import ObjectId
from core.utils import toObjectId
import random
import string
import gspread

from django.conf import settings


def generate_secret_key():
    return ''.join(
        random.choices(string.ascii_uppercase + string.ascii_lowercase +
                       string.digits,
                       k=24))


def send_secret_key(email_id: str, api_key: str, secret_key: str) -> int:
    filename = "sawo_keys.csv"
    sawo_docs_link = 'https://docs.sawolabs.com/'
    email_template = loader.get_template('client/emails/send-key.html')

    with open(filename, "w") as csvfile:
        cr = csv.writer(csvfile, delimiter=",", lineterminator="\n")
        cr.writerow(["API KEY", "SECRET KEY"])
        cr.writerow([api_key, secret_key])
    csvfile.close()

    try:
        with open(filename, "rb") as csvfile:
            msg = EmailMultiAlternatives(
                'New project key request received',
                ('Please find the keys attached with this mail. '
                 'Use this project credentials '
                 'to validate your project with SAWO. '
                 'For more info on these, visit {}.').format(sawo_docs_link),
                'help-noreply@sawolabs.com', [email_id])
            msg.attach_alternative(
                email_template.render({
                    'email_id': email_id,
                    'sawo_docs_link': sawo_docs_link,
                }), 'text/html')
            msg.attach(filename, csvfile.read(), 'text/csv')
            csvfile.close()
            return msg.send()
    except Exception as e:
        print(e)
        return 0


def create_project(
        project_name: str, related_client: dict, host_name: str,
        enable_beta_access: bool = False, google_sheet_link: str = '',
        type_of_project: str = '', web_project_type: str = ''):

    project = {
        "project_name": project_name,
        "project_id": str(uuid4()),
        "api_key": str(uuid4()),
        "related_client_id": toObjectId(related_client['_id']),
        "host_name": host_name,
        "session_cooldown": "15d",
        'message_body': 'Here\'s your code OTP_HERE.',
        'email_header': 'Validate email',
        'email_body': 'Use code OTP_HERE',
        'email_domain': 'sawolabs.com',
        'restricted_email_domains': [],
        "email_domain_error": "",
        "createdAt": datetime.utcnow(),
        "identifier_type": "email",
        "custom_fields": [],
        "maximum_users": 50,
        "beta_access_type": "private",
        "login_button_text": "Login without password",
        "hostname_verification_token": "",
        "show_sawo_logo": True,
        "type_of_project": type_of_project,
        "web_project_type": web_project_type,
        "show_captcha": False,
        "enable_beta_access": enable_beta_access,
        "google_sheet_link": google_sheet_link,
        "company_name": "",
        "company_website": "",
        "company_logo_iframe": "",
        "company_logo_email": "",
        "from_name": "",
        "showPrivacy": False,
        "privacyLink": "",
        "theme_name": "Default",
        "theme_type": "light",
        "limit_otp_data": {
            "blocked_time": 3600,
            "max_otp_requests": 5,
            "blocked_timespan": 10
        },

        "style": {
            "preview_container": {
                "backgroundColor": "#ffffff",
            },
            "input_text": {
                "borderWidth": "2px",
                "borderStyle": "solid",
                "borderColor": "#ffde40",
                "backgroundColor": "#ffffff"
            },
            "input_label": {
                "color": "#000000",
                "backgroundColor": "#ffffff",
            },
            "button": {
                "borderRadius": "10px",
                "background": "#ffde40",
                "color": "#000000",
            },
            "privacy_policy_text": {
                "color": "#000000",
            },
            "other_texts": {
                "color": "#000000"
            }
        }
    }
    if (enable_beta_access):
        project['identifier_check'] = (settings.IDENTIFIER_CHECKPOINT_DEV, settings.IDENTIFIER_CHECKPOINT_PROD)[
            settings.SITE_TYPE == "production"] + "/" + project['project_id'] + "/"

    _id = sawo_clients_projects_collection.insert_one(project).inserted_id
    project['secret_key'] = str(_id) + generate_secret_key()
    if not host_name or host_name == 'localhost':
        project['is_hostname_verified'] = True
    if host_name and host_name != 'localhost':
        project['is_hostname_verified'] = False
        project['hostname_verification_token'] = str(_id) + get_random_string(
            length=24, allowed_chars='abcdefghijklmnopqrstuvwxyz1234567890')
    sawo_clients_projects_collection.update_one(
        {'_id': _id}, {"$set": {
            "secret_key": project['secret_key'],
            "is_hostname_verified": project['is_hostname_verified'],
            "hostname_verification_token":
            project['hostname_verification_token']
        }})
    sawo_auths_log_collection.insert_one({
        'related_client_id':
        toObjectId(related_client['_id']),
        'related_project_id':
        _id
    })
    return project

# address function


def create_address(client_id: dict, company_name: str, street: str, city: str, state: str, pincode: int, country: str):
    address = {
        "related_client_id": toObjectId(client_id['_id']),
        "company_name": company_name,
        "street": street,
        "city": city,
        "state": state,
        "pincode": pincode,
        "country": country
    }
    sawo_clients_address_collection.insert_one(address)
    return address


def get_month_day_range(date):
    first_day = date.replace(day=1)
    last_day = date.replace(day=calendar.monthrange(date.year, date.month)[1])
    return first_day, last_day


def filterDict(d, remove_list: list) -> dict:
    return {k: v for (k, v) in d.items() if k not in remove_list}

# def fillDefaults(default_val: dict, )


def verify_and_consume_code(code_text: str, user_id: str):
    utcnow = datetime.utcnow()

    # Check if client already used some kind of referrals in current plan
    consumer = sawo_referrals_record_collection.find_one(
        {'user_id': toObjectId(user_id)})
    if consumer:
        if consumer['expiresAt'] > utcnow.replace(
                tzinfo=timezone(settings.TIME_ZONE)):
            raise AlreadyUsed()

    user_tracker = "users_list." + user_id
    # Check if client already used this referral code
    if sawo_referrals_collection.find_one({
        'code_text': code_text,
        user_tracker: {
            '$exists': True
        }
    }):
        raise AlreadyUsed()
    # Consume the referral
    result = sawo_referrals_collection.find_one_and_update(
        {
            '$and': [{
                'code_text': code_text
            }, {
                'referral_available': {
                    '$gt': 0
                }
            }]
        }, {'$inc': {
            'referral_available': -1,
            user_tracker: 1
        }})

    if result and ('auths_offered' in result):
        # Add auths to the current active plan
        result2 = sawo_clients_plans_collection.find_one_and_update(
            {
                '$and': [{
                    'related_client_id': toObjectId(user_id)
                }, {
                    'is_active': True
                }]
            }, {
                '$push': {
                    'used_referrals': {
                        'code_text': code_text,
                        'auths_count': result['auths_offered']
                    }
                }
            })
        if not result2:
            # Revive expired plan by filling auths if expire_date is not reached yet
            latest_plan = sawo_clients_plans_collection.find({
                'is_expired': True,
                'related_client_id': toObjectId(user_id),
                'is_active': False,
            }).sort([('expire_date', -1)]).limit(1)
            if latest_plan.count() > 0:
                for plan in latest_plan:
                    if plan['expire_date'] >= now():
                        result2 = plan
                        sawo_clients_plans_collection.find_one_and_update({
                            '_id': plan['_id']
                        }, {
                            '$set': {
                                'is_expired': False,
                                'is_active': True,
                            },
                            '$push': {
                                'used_referrals': {
                                    'code_text': code_text,
                                    'auths_count': result['auths_offered']
                                }
                            }
                        })
        # if found a plan to add referrals to else create a new plan
        if result2:
            sawo_referrals_record_collection.update_one({
                'user_id':
                toObjectId(user_id)}, {
                '$set':
                {
                    'expiresAt':
                        result2['start_date'] + timedelta(days=30)
                }
            }, upsert=True)
            sawo_users_collection.update_one({'_id': toObjectId(user_id)}, {
                '$inc': {
                    'auths_remaining': result['auths_offered'],
                    'auths_filled': result['auths_offered']
                }
            })
        else:
            expiry_date = utcnow + timedelta(days=30)
            sawo_referrals_record_collection.insert_one({
                'user_id':
                toObjectId(user_id),
                'expiresAt':
                expiry_date
            })

            create_plan({
                "plan_type": "Free",
                "auths_offered": result['auths_offered'],
                "plan_price": 0,
                "plan_currency_code": "INR",
                "client_id": user_id
            }, True)
    else:
        raise CodeExpired('Code has already expired')


def month_to_number(month_name: str) -> int:
    months_dict = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr': 4,
        'may': 5,
        'jun': 6,
        'jul': 7,
        'aug': 8,
        'sep': 9,
        'oct': 10,
        'nov': 11,
        'dec': 12
    }
    return months_dict[month_name]


def get_client_data(month: Optional[str] = None) -> List[Dict]:
    datas = []
    if month:
        sawo_clients = sawo_users_collection.find({
            'is_sawo_client': True,
            '$expr': {
                '$eq': [
                    {'$month': '$joined_at'},
                    month_to_number(month[0:3].lower())
                ]
            }
        })
    else:
        sawo_clients = sawo_users_collection.find({
            'is_sawo_client': True
        })
    for sawo_client in sawo_clients:
        data = {
            'username': sawo_client.get('username', ''),
            'email_id': sawo_client.get('identifier', ''),
            'auths_remaining': sawo_client.get('auths_remaining', ''),
            'ref_id': sawo_client.get('ref_id', ''),
            'joined_date': sawo_client['joined_at'].date()
            if sawo_client.get('joined_at', '') else 'N/A',
            'projects': ['N/A'],
            # 'active_plan': 'N/A'
        }
        projects_list = []
        projects = sawo_clients_projects_collection.find(
            {'related_client_id': sawo_client['_id']})
        for project in projects:
            projects_list.append(project['project_name'])
        if projects_list:
            data['projects'] = projects_list
        # active_plan = sawo_clients_plans_collection.find_one({
        #     'related_client_id': sawo_client['_id'],
        #     'is_active': True
        # })
        # if active_plan:
        #     data['active_plan'] = active_plan['plan_type']
        datas.append(data)
    return datas


def verify_hostname_from_html_source(project_id: str) -> None:
    project = sawo_clients_projects_collection.find_one(
        {'project_id': project_id})
    res = requests.get('http://' + str(project['host_name']))
    if res.status_code == 200:
        soup = BeautifulSoup(res.content, 'html.parser')
        domain_verification_string = soup.find(
            "meta", attrs={'name': 'sawo-hostname-verification'})
        if domain_verification_string and\
            domain_verification_string['content'] == \
                project['hostname_verification_token']:
            sawo_clients_projects_collection.update_one(
                {'_id': project['_id']},
                {
                    "$set": {
                        'is_hostname_verified': True,
                        'hostname_verification_token': ''
                    }
                }
            )
            client = sawo_users_collection.find_one({
                '_id': project['related_client_id']
            })
            send_domain_verified_email(
                client['identifier'], project['project_name'],
                project['host_name']
            )


def verify_hostname_from_dns_entry(project_id: str) -> None:
    project = sawo_clients_projects_collection.find_one(
        {'project_id': project_id})
    txt_records = query(project['host_name'], 'TXT')
    record_to_check = '"sawo-hostname-verification={}"'.format(
        project['hostname_verification_token'])
    if record_to_check in txt_records:
        sawo_clients_projects_collection.update_one(
            {'_id': project['_id']},
            {
                "$set": {
                    'is_hostname_verified': True,
                    'hostname_verification_token': ''
                }
            }
        )
        client = sawo_users_collection.find_one({
            '_id': project['related_client_id']
        })
        send_domain_verified_email(
            client['identifier'], project['project_name'],
            project['host_name']
        )


def send_domain_verified_email(
        client_email_id: str, project_name: str, hostname: str) -> int:
    email_template = loader.get_template(
        'client/emails/send-domain-verified.html')
    msg = EmailMultiAlternatives(
        f'Congratualtions! Domain for project {project_name} verified',
        f'The domain {hostname} for project {project_name} is verified',
        'help-noreply@sawolabs.com', [client_email_id])
    msg.attach_alternative(
        email_template.render({
            'client_email_id': client_email_id,
            'project_name': project_name,
            'hostname': hostname
        }), 'text/html')
    return msg.send()


def check_object_permission(request, project):
    if 'related_client_id' in project.keys():
        return (str(project['related_client_id']) == str(request.user['_id']))
    if 'is_sawo_admin' in request.user.keys():
        return request.user['is_sawo_admin']
    return False


def isGoogleSheetPublic(enable_beta_access, google_sheet_link):
    if (enable_beta_access and google_sheet_link):
        try:
            gs = gspread.service_account("service_account.json")
            google_sheet = gs.open_by_url(google_sheet_link)
            sheet = google_sheet.get_worksheet(0)
            sheet.get_values()
            return True

        except Exception as e:
            return False


def send_billing_address_change_emailer(email, parameters):
    email_template = loader.get_template('client/emails/billing-emailer.html')
    msg = EmailMultiAlternatives(parameters['subject'],
                                 '',
                                 'noreply@sawolabs.com', [email])
    msg.attach_alternative(
        email_template.render(parameters), 'text/html')
    return msg.send()


def format_address(address):
    return address['company_name'] + ', ' + \
        address['street']+', ' + address['city'] + ', ' + \
        address['state'] + ', ' + str(address['pincode']) + \
        ', ' + address['country']

def plan_info(plan_type, format=None):
    plans_dict = {
        'Free': {
            'plan_name': 'Free',
            'auths': 5000
        },
        'Inaugurate': {
            "plan_name": "Starter Plan",
            "auths": 15000
        },
        'Grow': {
            'plan_name': 'Start up Plan',
            'auths': 40000
        },
        'Manage': {
            'plan_name': 'Company Plan',
            'auths': 125000
        }
    }

    return (plans_dict[plan_type]['plan_name'], plans_dict[plan_type]['auths'])