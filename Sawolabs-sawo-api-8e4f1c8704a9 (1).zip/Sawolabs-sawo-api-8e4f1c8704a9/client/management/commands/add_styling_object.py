from django.core.management.base import BaseCommand

from client.collections import sawo_clients_projects_collection


class Command(BaseCommand):
    help = """
    This command will add additional fields
    to existing projects but will not check whether it is missing or not
    """

    def handle(self, *args, ** options):
        projects = sawo_clients_projects_collection.find({})
        
        for project in projects:

            mainBgColor = project["main_bg_color"] if "main_bg_color" in project else "#ffffff"
            inputBorderColor = project["input_border_color"] if "input_border_color" in project else "#ffdb59"
            inputLabelColor = project["input_label_text_color"] if "input_label_text_color" in project else "#000000"
            btnBgColor = project["btn_bg_color"] if "btn_bg_color" in project else "#ffdb59"
            btnTextColor = project["btn_text_color"] if "btn_text_color" in project else "#000000"
            privacyPolicyTextColor = project["privacy_policy_text_color"] if "privacy_policy_text_color" in project else "#000000"
            theme_name = project["theme_name"] if "theme_name" in project else "Default"
            themeName = "Default" if theme_name=="" in project else theme_name
            themeType = "dark" if "Dark" in themeName else "light"
            
            styleObj = {
                "preview_container": {
                    "backgroundColor": mainBgColor
                },
                "input_text": {
                    "borderWidth": '2px',
                    "borderStyle": 'solid',
                    "borderColor": inputBorderColor,
                    "backgroundColor": mainBgColor
                },
                "input_label": {
                    "color": inputLabelColor,
                    "backgroundColor": mainBgColor
                    },
                "button": {
                    "borderRadius": '10px',
                    "background": btnBgColor,
                    "color": btnTextColor
                },
                "privacy_policy_text": {
                    "color": privacyPolicyTextColor
                },
                "other_texts": {
                    "color": inputLabelColor,
                }
            }

            # print(styleObj,themeName,themeType)
            sawo_clients_projects_collection.update_one(
                {'_id': project['_id']},
                {
                    '$set': {
                        "style": styleObj,
                        "theme_name": themeName,
                        "theme_type": themeType
                    }
                }
            )
        
