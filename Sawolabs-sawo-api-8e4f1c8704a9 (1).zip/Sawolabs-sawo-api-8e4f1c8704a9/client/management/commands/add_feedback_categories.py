from django.core.management.base import BaseCommand

from landing.collections import sawo_feedback_collection


class Command(BaseCommand):
    help = """
    This command will add additional fields
    to existing projects but will not check whether it is missing or not
    """

    def handle(self, *args, ** options):
        feedback_data = sawo_feedback_collection.find({})

        for feedback in feedback_data:

            if 'feedback_text' in feedback:

                feedback_text_clone = []
                feedback_text_clone.append(feedback['feedback_text'])

                sawo_feedback_collection.update_one(
                    {'_id': feedback['_id']},
                    {
                        '$set': {
                            "feedback_categories": [],
                            "feedback_text": feedback_text_clone
                        }
                    }
                )

        print("done")
