from django.core.management.base import BaseCommand

from client.collections import sawo_clients_projects_collection

from datetime import datetime


class Command(BaseCommand):
    help = """
    This command will add additional fields
    to existing projects but will not check whether it is missing or not
    """

    def handle(self, *args, ** options):
        projects = sawo_clients_projects_collection.find({})

        for project in projects:

            sawo_clients_projects_collection.update_one(
                {'_id': project['_id']},
                {
                    '$set': {

                        "blocked_request_timestamp": datetime.utcnow(),

                        "limit_otp_data": {
                            "blocked_time": 3600,
                            "max_otp_requests": 5,
                            "blocked_timespan": 10,
                        },

                        "restricted_email_domains": [],
                        "email_domain_error": ""
                    }
                }
            )

        print("done")
