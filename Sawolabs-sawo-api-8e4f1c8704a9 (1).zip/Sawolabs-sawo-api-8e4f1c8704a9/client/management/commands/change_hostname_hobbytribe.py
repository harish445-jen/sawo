from django.core.management.base import BaseCommand

from client.collections import sawo_clients_projects_collection

from datetime import datetime


class Command(BaseCommand):
    help = """
    This command will add additional fields
    to existing projects but will not check whether it is missing or not
    """

    def handle(self, *args, ** options):
        try:
            sawo_clients_projects_collection.find_one_and_update({"api_key":"cee42b69-bbba-4b30-ab8b-f5197142b0c5"},{"$set": {"host_name": "thehobbytribe.com"}})
        except Exception as e:
            print(e)
        print("done")
