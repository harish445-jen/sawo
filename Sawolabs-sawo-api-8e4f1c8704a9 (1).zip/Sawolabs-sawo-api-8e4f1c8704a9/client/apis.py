from threading import Thread
from django.utils.crypto import get_random_string

from paymentgateway.tasks import task_send_plan_upgrade_emailer

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from authhelper.utils import (get_or_create_user, create_token, update_user)
from authhelper.auth import SawoAuthentication
from authhelper.permissions import IsAuthenticated
from authhelper.serializers import TokenAPISerializer
from authhelper.collections import sawo_users_collection

from admindash.utils import (
    create_plan, verify_purchase_token, decimal128Tofloat2)
from admindash.exceptions import PurchaseTokenInvalid, FreePlanAlreadyUsed

from client.serializers import (ProjectSerializer, PlanSerializer,
                                PlanTokenSerializer, ProjectHostSerializer,
                                ProjectSecretKeySerializer,
                                ReferralCodeSerializer,
                                AdvancedConfigSerializer,
                                ProjectCoolDownSerializer,
                                HostnameVerifcationSerializer,
                                ClientRoleSerializer,
                                ClientAddressSerializer)
from client.collections import (sawo_clients_projects_collection,
                                sawo_clients_plans_collection,
                                sawo_clients_purchased_plan_collection,
                                sawo_auths_log_collection,
                                sawo_clients_address_collection)
from client.tasks import (
    task_send_billing_address_change_emailer,
    task_send_secret_key,
    task_verify_hostname_from_dns_entry,
    task_verify_hostname_from_html_source
)
from client.utils import (create_project, format_address, get_month_day_range, plan_info,
                          verify_and_consume_code, filterDict, create_address, check_object_permission, isGoogleSheetPublic)
from client.permissions import IsClientUser
from client.exceptions import CodeExpired, AlreadyUsed

from datetime import datetime, time
from pymongo import ReturnDocument
# from bson.ObjectId import ObjectId
from core.utils import toObjectId

from sawo.utils import setSanitizeData

# NOTE: Maybe in later version when this module gets bigger
# We should divide in submodule


class TokenAPI(APIView):
    """
    This API will be used to login/register an user and
    send a token to use throughout site
    """

    def post(self, request, format=None):
        serializer = TokenAPISerializer(data=request.data)
        if serializer.is_valid():
            created, user = get_or_create_user(
                serializer.validated_data['identifier'],
                serializer.validated_data['verification_token'])
            if user:
                if created:
                    update_user(user, {'is_sawo_client': True})
                responsedata = create_token(user)
                responsedata['have_profile_data'] = bool(
                    user.get('username', ''))
                responsedata['identifier'] = user['identifier']
                responsedata['has_plan'] = bool(user.get('auths_filled', ''))
                responsedata['has_project'] = \
                    True if sawo_clients_projects_collection.find_one(
                        {'related_client_id': user.get('_id', '')}) else False
                responsedata['client_role'] = user.get('client_role', '')
                return Response(responsedata)
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ClientRoleAPI(APIView):
    """
    This API will be used to update a clients role
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (IsAuthenticated, IsClientUser,)

    def post(self, request, format=None):
        serializer = ClientRoleSerializer(data=request.data)
        if serializer.is_valid():
            sawo_users_collection.update_one(
                {'_id': request.user['_id']},
                {'$set': {
                    'client_role': serializer.validated_data['client_role']}}
            )
            return Response(
                {'client_role': serializer.validated_data['client_role']}
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ProjectAPI(APIView):
    """
    This API will be used to get/create/update projects of a client
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def get(self, request, format=None):
        projects = []
        projects_cursor = sawo_clients_projects_collection.find(
            {'related_client_id': request.user['_id']})
        for project in projects_cursor:
            project['_id'] = str(project['_id'])
            project.pop('related_client_id')
            projects.append(project)
        return Response(ProjectSerializer(projects, many=True).data)

    def post(self, request, format=None):
        serializer = ProjectSerializer(data=request.data)
        if serializer.is_valid():
            if serializer.validated_data.get('enable_beta_access', False):
                GoogleSheetStatus = isGoogleSheetPublic(serializer.validated_data.get('enable_beta_access', False), serializer.validated_data.get(
                    'google_sheet_link', ''))
                if not GoogleSheetStatus:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            project = create_project(serializer.validated_data['project_name'],
                                     request.user,
                                     serializer.validated_data.get(
                'host_name', ''),
                serializer.validated_data.get(
                'enable_beta_access', False),
                serializer.validated_data.get(
                'google_sheet_link', ''),
                serializer.validated_data.get(
                'type_of_project', ''),
                serializer.validated_data.get(
                'web_project_type', ''),

            )
            return Response(ProjectSerializer(project).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, format=None):
        setSanitizeData(request)
        serializer = AdvancedConfigSerializer(data=request.data)
        if serializer.is_valid():
            data_to_update = filterDict(
                serializer.validated_data, remove_list=['project_id'])
            if data_to_update:
                project = sawo_clients_projects_collection.find_one({
                    'project_id': str(serializer.validated_data['project_id'])
                })
                if check_object_permission(request, project):
                    sawo_clients_projects_collection.update_one(project, {
                        '$set': data_to_update
                    })
                    project = sawo_clients_projects_collection.find_one({
                        'project_id': str(serializer.validated_data['project_id'])
                    })
                else:
                    return Response({"error": "Permission Denied"}, status=status.HTTP_400_BAD_REQUEST)
                return Response(ProjectSerializer(project).data)
            return Response(status=status.HTTP_304_NOT_MODIFIED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        _id = request.query_params.get('project_id', False)
        if _id:
            try:
                sawo_clients_projects_collection.delete_one(
                    {'_id': toObjectId(_id)})
                sawo_auths_log_collection.delete_one({
                    'related_client_id':
                    request.user['_id'],
                    'related_project_id':
                    toObjectId(_id)
                })
                return Response({"msg": "Project Successfully deleted"},
                                status=status.HTTP_200_OK)
            except Exception:
                return Response({"error": "Project could not be deleted"},
                                status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)


# To Change HostName (when client want to change hostname)
class ProjectHostAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = ProjectHostSerializer(data=request.data)
        if serializer.is_valid():
            project = sawo_clients_projects_collection.find_one(
                {'project_id': str(serializer.validated_data['project_id'])})
            if check_object_permission(request, project):
                if project:
                    data_to_update = {
                        'host_name': serializer.validated_data['host_name'],
                        'message_body': 'Here\'s your code OTP_HERE.'
                    }
                    if project['host_name'] != serializer.validated_data['host_name'] and \
                            serializer.validated_data['host_name'] != 'localhost':
                        data_to_update.update({
                            'is_hostname_verified': False,
                            'hostname_verification_token':
                            str(project['_id']) + get_random_string(
                                length=24,
                                allowed_chars='abcdefghijklmnopqrstuvwxyz1234567890'
                            )
                        })
                    if not serializer.validated_data['host_name'] or\
                            serializer.validated_data['host_name'] == 'localhost':
                        data_to_update.update({
                            'is_hostname_verified': True,
                            'hostname_verification_token': ''
                        })
                    sawo_clients_projects_collection.update_one(
                        {'project_id': str(
                            serializer.validated_data['project_id'])},
                        {'$set': data_to_update}
                    )

                    return Response(data_to_update)
                return Response(status=status.HTTP_404_NOT_FOUND)
            return Response({'Error':'Permission Denied'},status=status.HTTP_403_FORBIDDEN)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# To send the Project Secret Key to registered email address of client
class ProjectSecretKey(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = ProjectSecretKeySerializer(data=request.data)
        if serializer.is_valid():
            cur_project = sawo_clients_projects_collection.find_one(
                {'_id': toObjectId(serializer.validated_data['project_id'])})
            if not cur_project:
                return Response(status=status.HTTP_404_NOT_FOUND)
            task_send_secret_key.delay(request.user['identifier'],
                                       cur_project['api_key'],
                                       cur_project['secret_key'])
            return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Get plans
class PlanAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def get(self, request, plan_id=None, format=None):
        if plan_id:
            plan = sawo_clients_plans_collection.find_one({
                '$and': [{
                    'plan_id': plan_id
                }, {
                    'related_client_id': request.user['_id']
                }]
            })
            if plan:
                plan.pop('_id')
                plan['plan_price'] = decimal128Tofloat2(plan['plan_price'])
                client = request.user
                client.pop('_id')
                plan['client'] = client
                plan.pop('related_client_id')
                return Response(plan)
            else:
                return Response({"error": "No plan found"})
        else:
            plan_cursor = sawo_clients_plans_collection.find(
                {'related_client_id': request.user['_id']})

        plans = []
        client = request.user
        client.pop('_id')
        for plan in plan_cursor:
            plan['_id'] = str(plan['_id'])
            plan['plan_price'] = decimal128Tofloat2(plan['plan_price'])
            plan['client'] = client
            plan.pop('related_client_id')
            plans.append(plan)
        return Response(plans)

    def post(self, request, format=None):
        serializer = PlanSerializer(data=request.data)

        if serializer.is_valid():
            try:
                serializer.validated_data['client_id'] = request.user['_id']
                verify_purchase_token(
                    str(serializer.validated_data['client_id']),
                    str(serializer.validated_data['plan_type']))

                current_plan = sawo_clients_plans_collection.find_one({
                    'related_client_id': toObjectId(serializer.validated_data['client_id']),
                    'is_active': True
                })

                plan = create_plan(serializer.validated_data)
                plan.pop('_id')
                plan.pop('related_client_id')
                plan['plan_price'] = decimal128Tofloat2(plan['plan_price'])

                if current_plan is not None:
                    # # Send the plan upgrade emailer
                    try:
                        sawo_user = sawo_users_collection.find_one(
                            request.user['_id'])
                        new_plan, new_auths = plan_info(
                            serializer.validated_data['plan_type'])
                        old_plan, old_auths = plan_info(
                            current_plan['plan_type'])
                        dt = datetime.now()
                        subscription_date = dt.strftime("%d/%m/%y")

                        t = Thread(target=task_send_plan_upgrade_emailer, kwargs={
                            "email": sawo_user['identifier'],
                            "parameters": {"user_name": sawo_user['first_name'], "old_plan": old_plan,
                                        "new_plan": new_plan, "type": "plan_upgrade",
                                        'auths_offered': new_auths, 'subscription_date': subscription_date}})
                        t.start()
                    except:
                        pass

                return Response(plan)
            except PurchaseTokenInvalid:
                return Response({'error_message': 'Invalid purchase Token'},
                                status=status.HTTP_403_FORBIDDEN)
            except FreePlanAlreadyUsed:
                return Response({'error_message': 'Free plan already used'},
                                status=status.HTTP_400_BAD_REQUEST)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# Used when Client buys a plan
class PlanTokenAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = PlanTokenSerializer(data=request.data)
        if serializer.is_valid():
            plantoken = {
                'is_consumed':
                False,
                'related_client_id':
                request.user["_id"],
                'plan_currency_code':
                serializer.validated_data["plan_currency_code"],
                'plan_type':
                serializer.validated_data['plan_type'],
                'created_at':
                datetime.utcnow()
            }
            sawo_clients_purchased_plan_collection.insert_one(plantoken)
            plantoken.pop('is_consumed')
            plantoken.pop('_id')
            plantoken.pop('related_client_id')
            return Response(plantoken)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# To Change SessionCoolDown (when client wants to change session cooldown time)
class ProjectCoolDownAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = ProjectCoolDownSerializer(data=request.data)
        if serializer.is_valid():
            cur_project = sawo_clients_projects_collection.find_one_and_update(
                {'project_id': str(serializer.validated_data['project_id'])}, {
                    '$set': {
                        'session_cooldown':
                        serializer.validated_data['session_cooldown']
                    }
                },
                return_document=ReturnDocument.AFTER)
            return Response(
                {"new_session_cooldown": cur_project['session_cooldown']})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Used to fill data in client dashboard
class TotalRecordsAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def get(self, request, format=None):
        client_id = request.user['_id']

        client = sawo_users_collection.find_one({'_id': client_id})
        auths_remaining = client['auths_remaining']
        auths_used = client['auths_filled'] - auths_remaining

        project_list = []

        projects_cursor = sawo_clients_projects_collection.find(
            {'related_client_id': client_id}, {
                'project_name': 1,
                'project_id': 1,
                'used_plans': 1,
                'createdAt': 1,
                '_id': 0
            })

        for project in projects_cursor:
            plans = []
            for plan in project.get('used_plans', []):
                pl = sawo_clients_plans_collection.find_one(
                    {'_id': toObjectId(plan)}, {
                        '_id': 0,
                        'related_client_id': 0
                    })
                if pl:
                    pl['total_records'] = project['used_plans'][plan][
                        'total_records']
                    pl['total_records_week'] = project['used_plans'][plan][
                        'total_records_week']
                    pl.pop('plan_price')
                    pl.pop('overage_charge', None)
                    plans.append(pl)
            project.pop('used_plans', None)
            new_project_dict = {
                "project_name": project['project_name'],
                "plans": list(plans),
                "createdAt": project.get('createdAt', None)
            }

            project_list.append(new_project_dict)
        return Response({
            "auths_remaining": auths_remaining,
            "auths_used": auths_used,
            "projects": project_list
        })


# used to get auth-logs
class GetAuthsInCurMon(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def get(self, request, format=None):
        client_id = request.user['_id']
        project_list = []

        # -- START
        #    Getting First and Last day of month
        (first_day, last_day) = get_month_day_range(datetime.today())
        first_day = datetime(first_day.year, first_day.month, first_day.day)
        last_day = datetime(last_day.year, last_day.month, last_day.day)
        last_day = datetime.combine(last_day, time.max)
        # -- END

        projects_cursor = sawo_clients_projects_collection.find(
            {'related_client_id': client_id}, {
                'project_name': 1,
                'project_id': 1
            })
        for project in projects_cursor:
            auths_list = []
            logs = sawo_auths_log_collection.aggregate([{
                '$match': {
                    'related_project_id': project['_id']
                }
            }, {
                '$unwind': '$auths'
            }, {
                '$match': {
                    'auths.auths_list.createdAt': {
                        '$gte': first_day,
                        '$lt': last_day
                    }
                }
            }, {
                '$project': {
                    "auths": 1,
                    "_id": 0
                }
            }])
            for log in logs:
                log['auths'].pop('plan_id')
                auths_list.append(log['auths'])
            project_list.append({
                "project_name": project['project_name'],
                "logs": auths_list
            })
        return Response(project_list)


class ReferralCode(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = ReferralCodeSerializer(data=request.data)
        if serializer.is_valid():
            try:
                verify_and_consume_code(serializer.validated_data['code_text'],
                                        str(request.user['_id']))
                return Response({'message': 'Successfully added.'})
            except AlreadyUsed:
                return Response({'error': 'Code already used'},
                                status=status.HTTP_400_BAD_REQUEST)
            except CodeExpired:
                return Response({'error': 'Code has Expired'},
                                status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class HostnameVerificationAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def post(self, request, format=None):
        serializer = HostnameVerifcationSerializer(data=request.data)
        if serializer.is_valid():
            if serializer.validated_data['verification_method'] == 'dns':
                task_verify_hostname_from_dns_entry.delay(
                    serializer.validated_data['project_id'])
            if serializer.validated_data['verification_method'] == 'html':
                task_verify_hostname_from_html_source.delay(
                    serializer.validated_data['project_id'])
            return Response({"message": "Succesfully Executed"})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Client Address
class ClientAddress(APIView):
    """
    This API will be used to get/create/update projects of a client
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsClientUser,
    )

    def get(self, request, format=None):
        try:
            address = sawo_clients_address_collection.find_one(
                {'related_client_id': request.user['_id']})
            return Response(ClientAddressSerializer(address).data)
        except:
            return Response({'error_message': 'No address found'},
                            status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        serializer = ClientAddressSerializer(data=request.data)
        if serializer.is_valid():
            address = create_address(request.user,
                                     serializer.validated_data['company_name'],
                                     serializer.validated_data['street'],
                                     serializer.validated_data['city'],
                                     serializer.validated_data['state'],
                                     serializer.validated_data['pincode'],
                                     serializer.validated_data['country'])

            try:
                # Format the address
                formatted_address = format_address(address)
                sawo_user = sawo_users_collection.find_one(request.user['_id'])
                    
                t = Thread(target=task_send_billing_address_change_emailer, kwargs={
                    "email": sawo_user['identifier'],
                    "parameters": {"user_name": sawo_user['first_name'], "address": formatted_address, 
                    "type": "add_address", "subheading_text" : 'Hope you are doing good!', 
                    "subject" : "Address changed for your sawo account."
                    }
                })

                t.start()
            except Exception as e:
                pass

            return Response(ClientAddressSerializer(address).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, format=None):
        serializer = ClientAddressSerializer(data=request.data)
        if serializer.is_valid():
            address = sawo_clients_address_collection.find_one_and_update({
                'related_client_id': request.user['_id']
            }, {
                '$set': serializer.validated_data
            }, return_document=ReturnDocument.BEFORE)

            # Find user name and email address

            try :
                sawo_user = sawo_users_collection.find_one(request.user['_id'])
                #  FORMATTED ADDRESS :
                if address is not None:
                    old_formatted_address = format_address(address)
                    new_formatted_address = format_address(
                        serializer.validated_data)

                    t = Thread(target=task_send_billing_address_change_emailer, kwargs={
                        "email": sawo_user['identifier'],
                        "parameters": {"user_name": sawo_user['first_name'], "old_address": old_formatted_address, 
                        "new_address": new_formatted_address , "type":"change_address",'subheading_text':'Greetings from SAWO Labs Team,' ,
                        "subject" : "Address associated with account changed"}
                    })

                    t.start()
            except Exception as e:
                pass

            return Response(serializer.validated_data)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
