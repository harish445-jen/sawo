from rest_framework.permissions import BasePermission


class IsClientUser(BasePermission):

    def has_permission(self, request, view):
        return request.user.get('is_sawo_client', False)


class IsOwnerOfProject(BasePermission):

    def has_object_permission(self, request, view, obj):
        return obj['related_client_id'] == request.user['_id']
