PLAN_CHOICES = (("Free", "Free"), ("Inaugurate", "Inaugurate"), ("Grow", "Grow"),
                ("Manage", "Manage"), ("Custom", "Custom"))

PLAN_AUTHS = {
    "Free": 5000,
    "Inaugurate": 15000,
    "Grow": 40000,
    "Manage": 125000
}

IDENTIFIER_TYPE_CHOICES = (
    ('email', 'email'),
    ('phone_number_sms', 'phone_number_sms')
)

CUSTOM_FIELD_TYPE_CHOICES = (
    ('text', 'text'),
    ('number', 'number'),
    ('password', 'password')
)

HOSTNAME_VERIFICATION_CHOICES = {
    ('html', 'html'),
    ('dns', 'dns')
}
