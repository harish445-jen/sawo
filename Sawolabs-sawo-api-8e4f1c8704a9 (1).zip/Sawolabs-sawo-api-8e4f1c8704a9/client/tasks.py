from celery import shared_task

from client.utils import (
    send_billing_address_change_emailer,
    send_secret_key,
    verify_hostname_from_dns_entry,
    verify_hostname_from_html_source
)


@shared_task
def task_send_secret_key(email_id: str, api_key: str, secret_key: str):
    return send_secret_key(email_id, api_key, secret_key)


@shared_task
def task_verify_hostname_from_html_source(project_id: str):
    return verify_hostname_from_html_source(project_id)


@shared_task
def task_verify_hostname_from_dns_entry(project_id: str):
    return verify_hostname_from_dns_entry(project_id)


@shared_task
def task_send_billing_address_change_emailer(email: str, parameters: dict):
    return send_billing_address_change_emailer(email, parameters)
