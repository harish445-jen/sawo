from django.urls import path

from client import apis

urlpatterns = [
    path('token/', apis.TokenAPI.as_view()),
    path('projects/', apis.ProjectAPI.as_view()),
    path('plans/<str:plan_id>/', apis.PlanAPI.as_view()),
    path('plans/', apis.PlanAPI.as_view()),
    path('plan/new/', apis.PlanAPI.as_view()),
    path('plan/token/', apis.PlanTokenAPI.as_view()),
    path('project/hostname/', apis.ProjectHostAPI.as_view()),
    path('project/session_cooldown/', apis.ProjectCoolDownAPI.as_view()),
    path('project/records/', apis.TotalRecordsAPI.as_view()),
    path('project/logs/', apis.GetAuthsInCurMon.as_view()),
    path('referral/', apis.ReferralCode.as_view()),
    path('sendkey/', apis.ProjectSecretKey.as_view()),
    path('project/verifyhostname/', apis.HostnameVerificationAPI.as_view()),
    path('address/', apis.ClientAddress.as_view()),
    path('role/', apis.ClientRoleAPI.as_view()),
]
