import re

from rest_framework import serializers


class CheckStringContainsSubString(object):
    def __init__(self, substring):
        self.substring = substring

    def __call__(self, value):
        if self.substring not in value:
            raise serializers.ValidationError(
                f"This field must contain {self.substring}")


def check_valid_hex_string(value):
    # NOTE: To future developer: I am not sure about the regex
    # string to match hex color code If it don't works for some color codes
    # please change the regex string
    matched = re.search(r'^#(?:[0-9a-fA-F]{3}){1,2}$', value)
    if not matched:
        raise serializers.ValidationError("Not a valid hex string")


class CheckStringEndsWithSubstring(object):
    def __init__(self, substring):
        self.substring = substring

    def __call__(self, value):
        if value[len(value) - 1] != self.substring:
            raise serializers.ValidationError(
                f"This field must end with '{self.substring}'")
