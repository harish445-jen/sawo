
from rest_framework import serializers
from .choices import (
    PLAN_CHOICES, IDENTIFIER_TYPE_CHOICES, CUSTOM_FIELD_TYPE_CHOICES,
    HOSTNAME_VERIFICATION_CHOICES,
)
from client.validators import (
    CheckStringContainsSubString,
    check_valid_hex_string,
    CheckStringEndsWithSubstring
)


class CustomFieldSerializer(serializers.Serializer):
    field_label = serializers.CharField()
    field_type = serializers.ChoiceField(choices=CUSTOM_FIELD_TYPE_CHOICES)
    field_placeholder_text = serializers.CharField(allow_blank=True)
    # NEW FIELDS
    custom_error_text = serializers.CharField(allow_blank=True, required=False)
    min_characters = serializers.CharField(allow_blank=True, required=False)
    max_characters = serializers.CharField(allow_blank=True, required=False)
    max_value = serializers.CharField(allow_blank=True, required=False)
    validation_type = serializers.CharField(allow_blank=True, required=False)
    regex_value = serializers.CharField(allow_blank=True, required=False)


class LimitInvalidOTPSerializer(serializers.Serializer):
    max_otp_requests = serializers.IntegerField()
    blocked_time = serializers.CharField()
    blocked_timespan = serializers.CharField()


class ProjectSerializer(serializers.Serializer):
    _id = serializers.CharField(read_only=True)
    project_id = serializers.UUIDField(read_only=True)
    project_name = serializers.CharField()
    api_key = serializers.UUIDField(read_only=True)
    host_name = serializers.CharField(allow_blank=True, required=False)
    session_cooldown = serializers.CharField(required=False)
    identifier_check = serializers.CharField(allow_blank=True, required=False)
    secret_key = serializers.CharField(read_only=True)
    email_header = serializers.CharField(required=False, allow_blank=True)
    email_body = serializers.CharField(required=False, allow_blank=True)
    email_domain = serializers.CharField(required=False, allow_blank=True)
    restricted_email_domains = serializers.ListField(
        required=False)
    email_domain_error = serializers.CharField(
        required=False)
    message_body = serializers.CharField(required=False, allow_blank=True)
    is_hostname_verified = serializers.BooleanField(read_only=True)
    hostname_verification_token = serializers.CharField(read_only=True)
    identifier_type = serializers.ChoiceField(
        choices=IDENTIFIER_TYPE_CHOICES, required=False)
    custom_fields = CustomFieldSerializer(many=True, required=False)
    login_button_text = serializers.CharField(required=False)
    show_sawo_logo = serializers.BooleanField(required=False)
    type_of_project = serializers.CharField(allow_blank=True, required=False)
    web_project_type = serializers.CharField(allow_blank=True, required=False)
    show_captcha = serializers.BooleanField(required=False)
    enable_beta_access = serializers.BooleanField(required=False)
    google_sheet_link = serializers.CharField(allow_blank=True, required=False)
    maximum_users = serializers.IntegerField(required=False)
    beta_access_type = serializers.CharField(allow_blank=True, required=False)
    company_name = serializers.CharField(allow_blank=True, required=False)
    company_website = serializers.CharField(allow_blank=True, required=False)
    company_logo_iframe = serializers.CharField(
        allow_blank=True, required=False)
    company_logo_email = serializers.CharField(
        allow_blank=True, required=False)
    from_name = serializers.CharField(allow_blank=True, required=False)
    theme_name = serializers.CharField(allow_blank=True, required=False)
    theme_type = serializers.CharField(allow_blank=True, required=False)
    showPrivacy = serializers.BooleanField(required=False)
    privacyLink = serializers.CharField(allow_blank=True, required=False)
    style = serializers.DictField(required=False)
    limit_otp_data = LimitInvalidOTPSerializer(required=False)


class PlanSerializer(serializers.Serializer):
    plan_id = serializers.UUIDField(read_only=True)
    auths_offered = serializers.IntegerField(read_only=True)
    plan_type = serializers.ChoiceField(choices=PLAN_CHOICES)
    is_active = serializers.BooleanField(read_only=True)
    is_expired = serializers.BooleanField(read_only=True)
    plan_price = serializers.DecimalField(max_digits=10, decimal_places=2)
    plan_currency_code = serializers.CharField()
    shopify_app = serializers.BooleanField(required=False, default=False)


class ClientSerializer(serializers.Serializer):
    client_name = serializers.CharField()


class PlanTokenSerializer(serializers.Serializer):
    plan_type = serializers.ChoiceField(choices=PLAN_CHOICES)
    plan_currency_code = serializers.CharField()
    is_consumed = serializers.BooleanField(read_only=True)


class UserAuthsSerializer(serializers.Serializer):
    api_key = serializers.UUIDField()


class ProjectHostSerializer(serializers.Serializer):
    host_name = serializers.CharField()
    project_id = serializers.UUIDField()


class ProjectSecretKeySerializer(serializers.Serializer):
    project_id = serializers.CharField()


class ProjectCoolDownSerializer(serializers.Serializer):
    session_cooldown = serializers.CharField()
    project_id = serializers.UUIDField()


class ReferralCodeSerializer(serializers.Serializer):
    code_text = serializers.CharField()


class AdvancedConfigSerializer(serializers.Serializer):
    project_id = serializers.UUIDField()
    identifier_check = serializers.CharField(allow_blank=True, required=False)
    email_header = serializers.CharField(required=False)
    email_body = serializers.CharField(
        required=False, validators=[
            CheckStringContainsSubString('OTP_HERE')])
    email_domain = serializers.CharField(required=False)
    restricted_email_domains = serializers.ListField(
        required=False)
    email_domain_error = serializers.CharField(
        required=False)
    message_body = serializers.CharField(
        required=False, validators=[
            CheckStringContainsSubString('OTP_HERE')])
    identifier_type = serializers.ChoiceField(
        choices=IDENTIFIER_TYPE_CHOICES, required=False)
    custom_fields = CustomFieldSerializer(many=True, required=False)
    login_button_text = serializers.CharField(required=False)
    session_cooldown = serializers.CharField(
        required=False, validators=[CheckStringEndsWithSubstring('d')])
    show_sawo_logo = serializers.BooleanField(required=False)
    show_captcha = serializers.BooleanField(required=False)
    enable_beta_access = serializers.BooleanField(required=False)
    google_sheet_link = serializers.CharField(required=False)
    maximum_users = serializers.IntegerField(required=False)
    beta_access_type = serializers.CharField(allow_blank=True, required=False)
    company_name = serializers.CharField(allow_blank=True, required=False)
    company_website = serializers.CharField(allow_blank=True, required=False)
    company_logo_iframe = serializers.CharField(
        allow_blank=True, required=False)
    company_logo_email = serializers.CharField(
        allow_blank=True, required=False)
    from_name = serializers.CharField(allow_blank=True, required=False)
    theme_name = serializers.CharField(allow_blank=True, required=False)
    theme_type = serializers.CharField(allow_blank=True, required=False)
    showPrivacy = serializers.BooleanField(required=False)
    privacyLink = serializers.CharField(allow_blank=True, required=False)
    style = serializers.DictField(required=False)
    limit_otp_data = LimitInvalidOTPSerializer(required=False)


class HostnameVerifcationSerializer(serializers.Serializer):
    project_id = serializers.UUIDField()
    verification_method = serializers.ChoiceField(
        choices=HOSTNAME_VERIFICATION_CHOICES)


class ClientRoleSerializer(serializers.Serializer):
    client_role = serializers.ChoiceField(choices=(
        'founder', 'founder',
        'developer', 'developer',
        'product', 'product',
        'ux', 'ux'
    ))


class ClientAddressSerializer(serializers.Serializer):
    company_name = serializers.CharField(allow_blank=True)
    street = serializers.CharField(allow_blank=True)
    city = serializers.CharField(allow_blank=True)
    state = serializers.CharField(allow_blank=True)
    pincode = serializers.IntegerField()
    country = serializers.CharField(allow_blank=True)
