class CodeExpired(Exception):
    pass


class AlreadyUsed(Exception):
    pass
