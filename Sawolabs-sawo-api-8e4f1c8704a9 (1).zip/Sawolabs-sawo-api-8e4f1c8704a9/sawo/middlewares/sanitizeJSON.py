from datetime import date
import  bleach
import json
from bleach.sanitizer import ALLOWED_ATTRIBUTES


class SanitizeJSON:
    allowed_styles= [
	"margin", "margin-left", "margin-top", "margin-bottom", "margin-right", "padding", "padding-left", "padding-top", "padding-bottom", "padding-right", "border", "font-size", "background-color", "color", "font-weight", "font-style", "font-family"
    ]
    allowed_tags = ['a','map','p','s','area', 'abbr', 'acronym', 'b', 'blockquote', 'em', 'i', 'li', 'ol', 'strong', 'ul','div','h1', 'h2', 'h3', 'h4', 'h5', 'h6']

    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.
        if 'CONTENT_TYPE' in request.META.keys() and 'application/json' in request.META['CONTENT_TYPE']:
            req = request.body
            try:
                data = json.loads(req)
                dataS = json.dumps(data)
                dataS = bleach.clean(dataS,
                                        strip=True,
                                        tags=self.allowed_tags,
                                        attributes=ALLOWED_ATTRIBUTES,
                                        styles=self.allowed_styles,
                                        strip_comments=True) 
                request.sanitisedData = json.loads(dataS)
            except:
                request.sanitisedData = req 
        
        
        
        # Code to be executed for each request/response after
        # the view is called.
        response = self.get_response(request)

        return response
