import sys
from django.conf import settings
from pymongo import (MongoClient, ASCENDING)
import mongomock
from pytz import timezone
from bson.codec_options import CodecOptions

if 'test' in sys.argv:
    db = mongomock.MongoClient().db
    settings.IS_TESTING_MODE = True
else:
    _client = MongoClient(host=settings.MONGODB_DATABASE['HOST'],
                          port=int(settings.MONGODB_DATABASE['PORT']),
                          username=settings.MONGODB_DATABASE['USERNAME'],
                          password=settings.MONGODB_DATABASE['PASSWORD'],
                          authSource=settings.MONGODB_DATABASE['AUTH_DB'])
    db = _client[settings.MONGODB_DATABASE['NAME']]

sawo_freemium_plan_collection = db.sawo_freemium_plan.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)
                               if not settings.IS_TESTING_MODE else None))

sawo_premium_plan_collection = db.sawo_premium_plan.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)
                               if not settings.IS_TESTING_MODE else None))

# INDEXING
sawo_freemium_plan_collection.create_index("start_date",
                                           expireAfterSeconds=2592000)
sawo_premium_plan_collection.create_index("start_date",
                                          expireAfterSeconds=2592000)

db.sawo_clients_projects.create_index([("api_key", ASCENDING),
                                       ("host_name", ASCENDING),
                                       ("secret_key", ASCENDING)])

db.sawo_clients_plans.create_index([("is_active", ASCENDING),
                                    ("related_client_id", ASCENDING),
                                    ("plan_id", ASCENDING),
                                    ("expire_date", ASCENDING),
                                    ])

db.users.create_index("user_id")

db.device_verification.create_index("identifier")

db.blocked_devices.create_index("device_id")
