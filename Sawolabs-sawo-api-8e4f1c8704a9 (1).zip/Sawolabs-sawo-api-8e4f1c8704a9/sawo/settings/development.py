from .base import *
DEBUG = True

# local EMAIL settings
EMAIL_PORT = 1025
EMAIL_USE_TLS = False


ALLOWED_HOSTS = ['*']

# CORS
# CORS_ORIGIN_WHITELIST = [
#     'http://' + get_env_var('CORE_HOST'),
#     'http://' + get_env_var('CLIENT_DASH_HOST'),
#     'http://' + get_env_var('ADMIN_DASH_HOST'),
#     'http://' + get_env_var('WEBSDK_HOST'),
#     'http://' + get_env_var('LANDING_HOST'),
#     'http://' + get_env_var('CMS_SDK_HOST'),
# ]

CORS_ORIGIN_ALLOW_ALL = True

CORS_ALLOW_HEADERS = (
    'x-requested-with',
    'content-type',
    'accept',
    'origin',
    'authorization',
    'x-csrftoken',
    'access-token'
)

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [],
    'DEFAULT_PERMISSION_CLASSES': [],
    'UNAUTHENTICATED_USER': None,
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    )
}