from .base import *
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration


DEBUG = False

ALLOWED_HOSTS = [
    get_env_var('CORE_HOST'),
    get_env_var('CLIENT_DASH_HOST'),
    get_env_var('ADMIN_DASH_HOST'),
    get_env_var('WEBSDK_HOST'),
    get_env_var('LANDING_HOST'),
    get_env_var('HACKATHON_HOST'),
    get_env_var('ADMIN_DASH_STAGING')
]

# CORS

CORS_ORIGIN_WHITELIST = [
    'https://' + get_env_var('CORE_HOST'),
    'https://' + get_env_var('CLIENT_DASH_HOST'),
    'https://' + get_env_var('ADMIN_DASH_HOST'),
    'https://' + get_env_var('WEBSDK_HOST'),
    'https://' + get_env_var('LANDING_HOST'),
    'https://' + get_env_var('HACKATHON_HOST'),
    'https://' + get_env_var('ADMIN_DASH_STAGING')
]

CORS_ALLOW_HEADERS = (
    'x-requested-with',
    'content-type',
    'accept',
    'origin',
    'authorization',
    'x-csrftoken',
    'access-token',
    'sentry-trace'
)

STATIC_ROOT = "" if not DEBUG else os.path.join(BASE_DIR, "static")

STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder'
)

# Rest Framework Config
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [],
    'DEFAULT_PERMISSION_CLASSES': [],
    'UNAUTHENTICATED_USER': None,
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    )
}

SECURE_BROWSER_XSS_FILTER = True

SESSION_COOKIE_SECURE = True

CSRF_COOKIE_SECURE = True

X_FRAME_OPTIONS = 'DENY'

SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'filters': None,
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'DEBUG',
        },
    },
}

# sentry - A module to report error
sentry_sdk.init(
    dsn=get_env_var("SENTRY_DSN"),
    integrations=[DjangoIntegration()],
    traces_sample_rate=1.0,

    # If you wish to associate users to errors (assuming you are using
    # django.contrib.auth) you may enable sending PII data.
    send_default_pii=True
)
