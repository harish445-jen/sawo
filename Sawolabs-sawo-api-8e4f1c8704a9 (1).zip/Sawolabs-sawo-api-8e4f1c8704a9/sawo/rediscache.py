import redis
from sawo.settings.base import get_env_var

r = redis.StrictRedis(
    host=get_env_var('REDIS_HOST'), port=6379, db=1, decode_responses=True)
