from django.urls import path, include

urlpatterns = [
    path('', include('core.urls')),
    path('client/', include('client.urls')),
    path('auth/', include('authhelper.urls')),
    path('admin/', include('admindash.urls')),
    path('landing/', include('landing.urls')),
    path('blog/', include('blog.urls')),
    path('payment/', include('paymentgateway.urls')),
]
