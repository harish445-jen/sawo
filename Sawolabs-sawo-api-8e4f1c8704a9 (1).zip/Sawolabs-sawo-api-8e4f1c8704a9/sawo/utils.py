def setSanitizeData(request):
    request.data.clear()
    request.data.update(request.sanitisedData)
    return request