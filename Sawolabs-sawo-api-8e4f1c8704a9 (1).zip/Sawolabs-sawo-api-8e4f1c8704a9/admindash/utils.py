from datetime import (datetime, date)
from django.utils.timezone import now, timedelta
from django.utils.crypto import get_random_string
from django.template import loader
from django.core.mail import EmailMultiAlternatives
from django.conf import settings

from admindash.collections import (sawo_admin_invitations_collection,
                                   currency_rates_collection)
from admindash.exceptions import PurchaseTokenInvalid, FreePlanAlreadyUsed

from client.collections import (sawo_clients_purchased_plan_collection,
                                sawo_clients_plans_collection,
                                sawo_premium_plan_collection)

from sawo.mongodb import sawo_freemium_plan_collection

from authhelper.collections import sawo_users_collection

from client.choices import PLAN_AUTHS

from uuid import uuid4
from bson.decimal128 import Decimal128
# from bson.ObjectId import ObjectId
from core.utils import toObjectId
import json
import random
import string
import requests
from decimal import Decimal
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from pathlib import Path
import csv


class Fixer_Currency_Rates:
    rates = {}
    retry_strategy = Retry(
        total=5,
        backoff_factor=10,
        status_forcelist=[429, 500, 502, 503, 504, 521],
    )

    def __init__(self, url):
        adapter = HTTPAdapter(max_retries=self.retry_strategy)
        http = requests.Session()
        http.mount("https://", adapter)
        data = http.get(url).json()

        # Extracting only the rates from the json data
        if 'rates' in data:
            self.rates = data["rates"]
        else:
            raise Exception


class CurrencyConverter:
    def __init__(self):
        self.rates = currency_rates_collection.find_one({})['rates']

    def convert(self, from_currency, to_currency, amount):
        if from_currency != 'EUR':
            amount = amount / self.rates[from_currency]

        # limiting the precision to 2 decimal places
        amount = round(amount * self.rates[to_currency], 6)
        return amount


def create_invitation(email_id: str) -> dict:
    invitation = sawo_admin_invitations_collection.find_one(
        {'email_id': email_id})
    if not invitation:
        invitation = {
            'email_id': email_id,
            'created_on': datetime.utcnow(),
            'invitation_key': get_random_string(length=36),
            'has_joined': False
        }
        sawo_admin_invitations_collection.insert_one(invitation)
    invitation.pop('_id')
    return invitation


def send_invitation(email_id: str) -> int:
    invitation = sawo_admin_invitations_collection.find_one(
        {'email_id': email_id})
    invitation_url = 'http://{}/{}'.format(settings.ADMIN_DASH_HOST_URL,
                                           invitation['invitation_key'])
    email_template = loader.get_template('admindash/emails/invitation.html')
    msg = EmailMultiAlternatives('You are invited to sawo admin',
                                 'Use url {} to join'.format(invitation_url),
                                 'invitation-noreply@sawolabs.com', [email_id])
    msg.attach_alternative(
        email_template.render({
            'email_id': invitation['email_id'],
            'invitation_url': invitation_url
        }), 'text/html')
    return msg.send()


def create_plan(plan_details: dict,
                by_referral: bool = False,
                by_subscription: bool = False):
    # Create A Plan Using Token Created
    paid_plan = not (by_referral or by_subscription)

    # Basic plan data
    start_date = datetime.utcnow()
    plan = {
        "plan_id":
        str(uuid4()),
        "plan_type":
        plan_details['plan_type'],
        "auths_offered":
        plan_details['auths_offered']
        if by_referral or by_subscription else PLAN_AUTHS[
            plan_details['plan_type']],
        "is_active":
        True,
        "is_expired":
        False,
        "plan_price":
        Decimal128(Decimal(plan_details['plan_price'])),
        "plan_currency_code":
        plan_details['plan_currency_code'],
        "related_client_id":
        toObjectId(plan_details['client_id']),
        "start_date":
        start_date,
        # "shopify_app": plan_details['shopify_app']
    }

    # Plan Tracker
    plan2 = {"plan_id": plan["plan_id"], "start_date": start_date}

    if paid_plan:
        plan.update({
            'razorpay_plan_id': plan_details.get('razorpay_plan_id', '')
        })

    if plan_details['plan_type'] == 'Free':
        # Free plan can only be subscribed once per client
        user = sawo_users_collection.find_one(
            {'_id': toObjectId(plan_details['client_id'])})
        if (not by_referral and not by_subscription)  \
                and bool(user.get('auths_filled', '')):
            raise FreePlanAlreadyUsed()

    current_plan = sawo_clients_plans_collection.find_one({
        'related_client_id': toObjectId(plan_details['client_id']),
        'is_active': True
    })

    if not current_plan:
        sawo_users_collection.update_one(
            {'_id': toObjectId(plan_details['client_id'])}, {
                '$set': {
                    'auths_remaining': plan['auths_offered'],
                    'auths_filled': plan['auths_offered']
                }
            })
    else:
        upgrade_now = current_plan['plan_type'] == 'Free' and \
            plan != 'Free'

        # Put new plan in queue if not required to switch immediately
        if not upgrade_now and current_plan[
                'start_date'] + timedelta(days=30) > now():
            plan['start_date'] = plan2['start_date'] = (
                current_plan['start_date'] + timedelta(days=30))
            plan['is_active'] = False
        else:
            # Mark current plan as expired
            update_fields = {
                'is_expired': True,
                'is_active': False,
                'expire_date': current_plan['start_date'] + timedelta(days=30)
            }
            sawo_clients_plans_collection.update_one(
                {
                    '_id': current_plan['_id'],
                }, {'$set': update_fields})
            sawo_users_collection.update_one(
                {'_id': toObjectId(plan_details['client_id'])}, {
                    '$set': {
                        'auths_remaining': plan['auths_offered'],
                        'auths_filled': plan['auths_offered']
                    }
                })

    sawo_clients_plans_collection.insert_one(plan)
    plan['plan_price'] = plan['plan_price'].to_decimal()
    if plan['plan_type'] != 'Free':
        sawo_premium_plan_collection.insert_one(plan2)
    else:
        sawo_freemium_plan_collection.insert_one(plan2)
    return plan


def verify_purchase_token(related_client_id: str, plan_type: str):
    # each purchase by client will generate a token,
    # plan will be created against this token and it can be consumed only once

    plan = sawo_clients_purchased_plan_collection.find_one({
        "$and": [{
            "related_client_id": toObjectId(related_client_id)
        }, {
            "plan_type": plan_type
        }, {
            'is_consumed': False
        }]
    })
    if plan:
        sawo_clients_purchased_plan_collection.update_one(
            {"_id": plan['_id']}, {'$set': {
                'is_consumed': True
            }})
        return plan['_id']
    else:
        raise PurchaseTokenInvalid('Purchase Token Invalid')


def generateReferralCode():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))


def update_currency_rates():
    url = str.__add__('http://data.fixer.io/api/latest?access_key=',
                      settings.FIXERIO_ACCESS_KEY)
    try:
        c = Fixer_Currency_Rates(url)
        currency_rates_collection.update_one({}, {"$set": {
            "rates": c.rates
        }},
            upsert=True)
    except (json.decoder.JSONDecodeError, Exception):
        print("Failure in fetching currency rates from Fixer API")


def assign_free_plan_on_expire():
    p = Path('plansubscription')
    p.mkdir(exist_ok=True)
    with open(p / f'{date.today()}.csv', 'w') as my_file:
        wr = csv.writer(my_file, delimiter=',')
        wr.writerow(['username',
                     'plan type',
                     'plan price',
                     'auths offered',
                     'plan starts on',
                     'last plan expire(s/d) on'
                     ])
        clients = sawo_users_collection.find({})
        for client in clients:
            # Find current active plan
            current_plan = sawo_clients_plans_collection.find_one({
                'is_expired': False,
                'related_client_id': client['_id'],
                'is_active': True,
            })
            if current_plan:
                # Check if current plan will expire in some time
                if (current_plan['start_date'] + timedelta(days=30) <=
                        now() + timedelta(days=1)):
                    # Even though it will expire, check for backup plans
                    has_other_plan = sawo_clients_plans_collection.find_one({
                        'is_expired': False,
                        'related_client_id': client['_id'],
                        'start_date': {
                            '$gt': now() - timedelta(days=30)
                        },
                        '_id': {
                            '$ne': current_plan['_id']
                        }
                    })
                    if not has_other_plan:
                        auths_from_referrals = 0
                        for used_referral in current_plan.get(
                                'used_referrals', []):
                            auths_from_referrals += used_referral[
                                'auths_count']
                        # Finally create the backup plan
                        pl = create_plan({
                            "plan_type": current_plan['plan_type'],
                            "plan_price": current_plan['plan_price'].to_decimal(),
                            "plan_currency_code": current_plan[
                                'plan_currency_code'],
                            "client_id": client['_id'],
                            "auths_offered": current_plan['auths_offered'] + auths_from_referrals
                        }, False, True)
                        wr.writerow([client.get('username', 'ID ' + str(client['_id'])),
                                     current_plan['plan_type'],
                                     current_plan['plan_price'].to_decimal(
                        ),
                            current_plan['auths_offered'],
                            pl['start_date'],
                            current_plan['start_date'] +
                            timedelta(days=30)
                        ])
            else:
                # find the latest plan expired
                latest_plan = sawo_clients_plans_collection.find({
                    'is_expired': True,
                    'related_client_id': client['_id'],
                    'is_active': False,
                }).sort([('expire_date', -1)]).limit(1)
                if latest_plan.count() > 0:
                    for plan in latest_plan:
                        has_other_plan = sawo_clients_plans_collection.find_one({
                            'is_expired': False,
                            'related_client_id': client['_id'],
                            'start_date': {
                                '$gt': now() - timedelta(days=30)
                            },
                            '_id': {
                                '$ne': plan['_id']
                            }
                        })
                        if not has_other_plan:
                            auths_from_referrals = 0
                            for used_referral in plan.get(
                                    'used_referrals', []):
                                auths_from_referrals += used_referral[
                                    'auths_count']
                            # Renew it if finished 30 days
                            if (plan['start_date']
                                    + timedelta(days=30) <= now()):
                                pl = create_plan({
                                    "plan_type": plan['plan_type'],
                                    "plan_price": plan['plan_price'].to_decimal(),
                                    "plan_currency_code": plan['plan_currency_code'],
                                    "client_id": client['_id'],
                                    "auths_offered": plan['auths_offered'] + auths_from_referrals
                                }, False, True)
                                wr.writerow([client.get('username', 'ID ' + str(client['_id'])),
                                             plan['plan_type'],
                                             plan['plan_price'].to_decimal(),
                                             plan['auths_offered'],
                                             pl['start_date'],
                                             plan['start_date'] +
                                             timedelta(days=30)
                                             ])

                else:
                    pl = create_plan({
                        "plan_type": 'Free',
                        "plan_price": 0.0,
                        "plan_currency_code": 'INR',
                        "client_id": client['_id'],
                        "auths_offered": 5000
                    }, False, True)
                    wr.writerow([client.get('username', 'ID ' + str(client['_id'])),
                                 'Free',
                                 0.0,
                                 5000,
                                 pl['start_date'],
                                 'First Plan'
                                 ])


def decimal128Tofloat2(num):
    # Check if num is of Type Decimal128
    if(type(Decimal128(Decimal(1))) == type(num)):
        return round(float(num.to_decimal()), 2)
    return round(float(num), 2)
