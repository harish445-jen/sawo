from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core.paginator import Paginator

from authhelper.serializers import TokenAPISerializer
from authhelper.collections import sawo_users_collection
from authhelper.utils import (create_token, get_or_create_user, update_user)
from authhelper.auth import SawoAuthentication
from authhelper.permissions import IsAuthenticated

from client.collections import (sawo_clients_projects_collection,
                                sawo_clients_plans_collection,
                                sawo_auths_log_collection,
                                sawo_clients_purchased_plan_collection)
from client.serializers import PlanSerializer
from client.utils import (get_month_day_range)

from admindash.permissions import IsSawoAdmin
from admindash.collections import (sawo_admin_invitations_collection,
                                   sawo_referrals_collection)
from admindash.serializers import (InvitationSerializer, SignupSerializer,
                                   ReferralCodeSerializer,
                                   ReferralCodeUpdateSerializer)
from admindash.utils import (CurrencyConverter, create_invitation,
                             verify_purchase_token, create_plan)
from admindash.tasks import task_send_invitation
from admindash.exceptions import PurchaseTokenInvalid

from landing.collections import (newsletter_subscription_collection,
                                 sawo_feedback_collection)

# from bson.ObjectId import ObjectId
from core.utils import toObjectId
from pymongo.collection import ReturnDocument
from datetime import datetime, time


class TokenAPI(APIView):
    """
    This API will be used to login admin user and
    send a token to use throughout site
    """

    def post(self, request, format=None):
        serializer = TokenAPISerializer(data=request.data)
        if serializer.is_valid():
            user = sawo_users_collection.find_one(
                {'identifier': serializer.validated_data['identifier']}, {
                    'auths_remaining': 0,
                    'auths_filled': 0
                })
            if user:
                if user.get('is_sawo_admin', False):
                    responsedata = create_token(user)
                    responsedata['have_profile_data'] = bool(
                        user.get('username', ''))
                    responsedata['identifier'] = user['identifier']
                    return Response(responsedata)
            return Response(status=status.HTTP_403_FORBIDDEN)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SignupAPI(APIView):
    """
    This API will be used to signup an admin user using
    invitation token
    """

    def post(self, request, format=None):
        serializer = SignupSerializer(data=request.data)
        if serializer.is_valid():
            created, user = get_or_create_user(
                serializer.validated_data['identifier'],
                serializer.validated_data['verification_token'])
            if user:
                update_user(user, {'is_sawo_admin': True})
                sawo_admin_invitations_collection.update_one(
                    {
                        'invitation_key':
                        serializer.validated_data['invitation_key']
                    }, {'$set': {
                        'has_joined': True
                    }})
                responsedata = create_token(user)
                responsedata['have_profile_data'] = bool(
                    user.get('username', ''))
                responsedata['identifier'] = user['identifier']
                return Response(responsedata)
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ClientAPI(APIView):
    """
    This API will be used to get sawo client lists
    route: /admin/client/1

    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None, page_number=None):
        print(page_number)
        page_number=int(page_number)    
        clients = []
        clients_cursor = sawo_users_collection.find({'is_sawo_client': True},
        {
            'client_role':0
        })
        total_number=0
        for client in clients_cursor:
            total_number=total_number+1
            #NEED TO OPTMIZE MORE BY REMOVING LOOPS
            # projects = []
            # projects_c = sawo_clients_projects_collection.find(
            #     {'related_client_id': client['_id']})
            # for project in projects_c:
            #     project.pop('_id')
            #     project.pop('related_client_id')
            #     project.pop('api_key')
            #     project.pop('used_plans', None)
            #     projects.append(project)
            # client['projects'] = projects
            # plans = sawo_clients_plans_collection.find(
            #     {
            #         'related_client_id': client['_id']
            #     }, {
            #         'related_client_id': 0,
            #         '_id': 0
            #     }).sort('start_date', -1)
            # pls = []
            # for plan in plans:
            #     plan['plan_price'] = plan['plan_price'].to_decimal()
            #     plan.pop('overage_charge', None)
            #     pls.append(plan)
            # client['plans'] = pls
            client['_id'] = str(client['_id'])
            clients.append(client)
        p = Paginator(clients,10)
        page_obj = p.page(page_number)
        clients= list(page_obj)
        clients_data={
            'total_records': total_number,
            'clients':clients
            
        }
        return Response(clients_data)


class InvitationAPI(APIView):
    """
    This API will be used to get list of invitation and
    create invitation
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        invitations = []
        invitation_collection = sawo_admin_invitations_collection.find({})
        for invitation in invitation_collection:
            invitation.pop('_id')
            invitations.append(invitation)
        return Response(invitations)

    def post(self, request, format=None):
        serializer = InvitationSerializer(data=request.data)
        if serializer.is_valid():
            invitation = create_invitation(
                serializer.validated_data['email_id'])
            task_send_invitation.delay(invitation['email_id'])
            return Response(invitation)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        if request.query_params.get('invitation_key', False):
            sawo_admin_invitations_collection.delete_one(
                {'invitation_key': request.query_params['invitation_key']})
            return Response({'message': "successfully deleted"})
        return Response({'error': 'No code found'},
                        status=status.HTTP_400_BAD_REQUEST)


class NewsletterAPI(APIView):
    """
    This API will be used to get list of all newletter subscribers
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        subscribers = []
        subscribers_cursor = newsletter_subscription_collection.find({})
        for sub in subscribers_cursor:
            sub.pop('_id')
            subscribers.append(sub)
        return Response(subscribers)


# NOTE: Following API are not exposed and not complete


class ProjectAPI(APIView):
    """
    This API will be used to get list of all projects
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, project_id=None, client_id=None, format=None):
        projects = []
        if project_id:
            project = sawo_clients_projects_collection.find_one(
                {'project_id': project_id})
            if project:
                client = sawo_users_collection.find_one(
                    {'_id': project['related_client_id']})
                client.pop('_id')
                project['client'] = client
                project.pop('_id')
                project.pop('related_client_id')
                return Response(project)
            else:
                return Response(status=status.HTTP_404_NOT_FOUND)
        if client_id:
            projects_cursor = sawo_clients_projects_collection.find(
                {'related_client_id': toObjectId(client_id)})
        else:
            projects_cursor = sawo_clients_projects_collection.find({})
        for project in projects_cursor:
            client = sawo_users_collection.find_one(
                {'_id': project['related_client_id']})
            client['_id'] = str(client['_id'])
            project['client'] = client
            project.pop('related_client_id')
            project.pop('_id')
            plans = []
            for plan in project.get('used_plans', {}):
                pl = sawo_clients_plans_collection.find_one(
                    {'_id': toObjectId(plan)}, {
                        '_id': 0,
                        'related_client_id': 0
                    })
                pl['plan_price'] = pl['plan_price'].to_decimal()
                pl.pop('overage_charge', None)
                # pl['overage_charge'] = pl['overage_charge'].to_decimal()
                c = CurrencyConverter()
                cost = c.convert(pl['plan_currency_code'], 'INR',
                                 int(pl['plan_price']) / pl['auths_offered'])
                pl['cost_per_auth'] = cost
                pl['total_records'] = project['used_plans'][plan][
                    'total_records']
                pl['total_records_week'] = project['used_plans'][plan][
                    'total_records_week']
                plans.append(pl)
            project.pop('used_plans', None)
            project['plan'] = list(plans)

            projects.append(project)
        return Response(projects)


class UsersAPI(APIView):
    """
    This API will be used to get sawo admins list and
    TODO: set roles and permissions
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        users = []
        users_cursor = sawo_users_collection.find({'is_sawo_admin': True})
        for user in users_cursor:
            user.pop('_id')
            users.append(user)
        return Response(users)


class PlanAPI(APIView):

    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, plan_id=None, client_id=None, format=None):
        if plan_id:
            plan = sawo_clients_plans_collection.find_one({'plan_id': plan_id})
            if plan:
                plan.pop('_id')
                plan['plan_price'] = plan['plan_price'].to_decimal()
                plan.pop('overage_charge', None)
                # plan['overage_charge'] = plan['overage_charge'].to_decimal()
                return Response(plan)
            else:
                return Response(status=status.HTTP_404_NOT_FOUND)
        elif client_id:
            print(client_id)
            plan_cursor = sawo_clients_plans_collection.find(
                {'related_client_id': toObjectId(client_id)})
        else:
            plan_cursor = sawo_clients_plans_collection.find({})

        plans = []
        for plan in plan_cursor:
            print(plan)
            plan['_id'] = str(plan['_id'])
            plan['plan_price'] = plan['plan_price'].to_decimal()
            plan.pop('overage_charge', None)
            # plan['overage_charge'] = plan['overage_charge'].to_decimal()
            plans.append(plan)
        return Response(plans)

    def post(self, request, format=None):
        serializer = PlanSerializer(data=request.data)
        if serializer.is_valid():
            try:
                # each purchase by client will generate a token,
                # plan will be created against this token, it can be consumed only once
                serializer.validated_data.update({
                    'razorpay_plan_id': verify_purchase_token(
                        str(serializer.validated_data['client_id']),
                        str(serializer.validated_data['plan_type']))
                })
                plan = create_plan(serializer.validated_data)
                plan.pop('_id')
                plan.pop('related_client_id')
                plan.pop('razorpay_plan_id', None)
                return Response(plan)
            except PurchaseTokenInvalid:
                return Response({'error_message': 'Invalid purchase Token'},
                                status=status.HTTP_403_FORBIDDEN)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ReferralCode(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        referrals = sawo_referrals_collection.find({})
        result = []
        for ref in referrals:
            ref.pop('_id')
            ref['clients_list'] = []
            if 'users_list' in ref:
                for (key, value) in ref['users_list'].items():
                    client = sawo_users_collection.find_one(
                        {"_id": toObjectId(key)}, {
                            'auths_remaining': 0,
                            'auths_filled': 0
                        })
                    if client:
                        ref['clients_list'].append({client['username']: value})
                ref.pop('users_list')
            result.append(ref)
        return Response(result)

    def post(self, request, format=None):
        serializer = ReferralCodeSerializer(data=request.data)
        if serializer.is_valid():
            try:
                referral = {
                    "auths_offered":
                    serializer.validated_data['auths_offered'],
                    "referral_available":
                    serializer.validated_data['num_of_referrals'],
                    "code_text":
                    serializer.validated_data['code_text'],
                    "created_referral_for": serializer.validated_data['created_referral_for']
                }
                inserted_referral = sawo_referrals_collection.insert_one(
                    referral)
                referral['_id'] = str(inserted_referral.inserted_id)
                referral['clients_list'] = []
                return Response(referral)
            except Exception:
                return Response(
                    {'error_message': 'Could not create referral code'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, format=None):
        serializer = ReferralCodeUpdateSerializer(data=request.data)
        if serializer.is_valid():
            referral = sawo_referrals_collection.find_one_and_update(
                {'code_text': serializer.validated_data['code_text']}, {
                    '$inc': {
                        "referral_available":
                        serializer.validated_data['change_count']
                    }
                },
                return_document=ReturnDocument.AFTER)
            referral.pop('_id')
            return Response(referral)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        if request.query_params.get('code_text', False):
            sawo_referrals_collection.delete_one(
                {'code_text': request.query_params['code_text']})
            return Response({'message': "successfully deleted"})
        return Response({'error': 'No code found'},
                        status=status.HTTP_400_BAD_REQUEST)


class TotalRecordsAPI(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        # -- Get Dately Records
        # Getting First and Last day of month
        (first_day, last_day) = get_month_day_range(datetime.today())
        first_day = datetime(first_day.year, first_day.month, first_day.day)
        last_day = datetime(last_day.year, last_day.month, last_day.day)
        last_day = datetime.combine(last_day, time.max)
        cost_dict = {}

        projects = []
        projects_cursor = sawo_clients_projects_collection.find()
        for project in projects_cursor:
            # Getting Weekly, Monthly, Yearly Records
            client = sawo_users_collection.find_one(
                {'_id': project['related_client_id']})
            client['_id'] = str(client['_id'])
            project['client'] = client
            project.pop('related_client_id')
            _id = project['_id']
            project.pop('_id')
            plans = []
            for plan in project.get('used_plans', {}):
                pl = sawo_clients_plans_collection.find_one(
                    {'_id': toObjectId(plan)}, {
                        '_id': 0,
                        'related_client_id': 0
                    })
                if pl:
                    pl['plan_price'] = pl['plan_price'].to_decimal()
                    pl.pop('overage_charge', None)
                    # pl['overage_charge'] = pl['overage_charge'].to_decimal()
                    c = CurrencyConverter()
                    cost = c.convert(
                        pl['plan_currency_code'], 'INR',
                        int(pl['plan_price']) / pl['auths_offered'])
                    cost_dict[plan] = pl['cost_per_auth'] = cost
                    pl['total_records'] = project['used_plans'][plan][
                        'total_records']
                    pl['total_records_week'] = project['used_plans'][plan][
                        'total_records_week']
                    plans.append(pl)
            project.pop('used_plans', None)
            project['plan'] = list(plans)

            # Getting Dately Records for Current Month
            auths_list = []
            logs = sawo_auths_log_collection.aggregate([
                {
                    '$match': {
                        'related_project_id': _id
                    }
                },
                {
                    '$unwind': '$auths'
                },
                #  {
                #     '$unwind':
                #     '$auths.auths_list'
                # },
                {
                    '$match': {
                        'auths.auths_list.createdAt': {
                            '$gte': first_day,
                            '$lt': last_day
                        }
                    }
                },
                # {
                #     '$group': {
                #         '_id': '$_id',
                #         'auths_list': {
                #             '$push': '$auths.auths_list'
                #         }
                #     }
                # },
                {
                    '$project': {
                        # "auths_list": 1,
                        "auths": 1,
                        "_id": 0
                    }
                }
            ])
            auths_list = []
            for log in logs:
                log['auths']['cost_per_auth'] = cost_dict[str(
                    log['auths']['plan_id'])]
                log['auths'].pop('plan_id')
                auths_list.append(log['auths'])
            project['logs'] = auths_list

            projects.append(project)

        plans = sawo_clients_plans_collection.find({}, {
            'plan_type': 1,
            'is_active': 1,
            '_id': 0
        })

        plans_dict = {
            "Free": 0,
            "Launch": 0,
            "Grow": 0,
            "Manage": 0,
            "Advance": 0,
            "Enterprise": 0
        }

        for plan in plans:
            if plan['is_active']:
                plans_dict[plan['plan_type']] += 1

        return Response({"projects": projects, "plans_overview": plans_dict})


class PurchasedPlans(APIView):
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        result = []
        records_cursor = sawo_clients_purchased_plan_collection.find({})
        for record in records_cursor:
            client = sawo_users_collection.find_one(
                {'_id': record['related_client_id']})
            if client == None:
                continue
            record['_id'] = str(client['_id'])
            record['identifier'] = client['identifier']
            record.pop('related_client_id')
            record.pop('is_consumed')
            result.append(record)
        return Response(result)


class FeedbackAPI(APIView):
    """
    This API will be used to get record of rating data
    """
    authentication_classes = (SawoAuthentication, )
    permission_classes = (
        IsAuthenticated,
        IsSawoAdmin,
    )

    def get(self, request, format=None):
        total_records = sawo_feedback_collection.find_one({})
        total_records.pop('_id')
        return Response({'records': total_records})
