from django.urls import path
from admindash import apis

urlpatterns = [
    path('token/', apis.TokenAPI.as_view()),
    path('signup/', apis.SignupAPI.as_view()),
    path('client/<str:page_number>', apis.ClientAPI.as_view()),
    path('invitation/', apis.InvitationAPI.as_view()),
    path('plan/new/', apis.PlanAPI.as_view()),
    path('plan/<str:plan_id>/', apis.PlanAPI.as_view()),
    path('plan/client/<str:client_id>/', apis.PlanAPI.as_view()),
    path('plans/', apis.PlanAPI.as_view()),
    path('projects/', apis.ProjectAPI.as_view()),
    path('projects/<str:project_id>/', apis.ProjectAPI.as_view()),
    path('projects/client/<str:client_id>/', apis.ProjectAPI.as_view()),
    path('referral/', apis.ReferralCode.as_view()),
    path('records/', apis.TotalRecordsAPI.as_view()),
    path('newsletter/', apis.NewsletterAPI.as_view()),
    path('purchaserecords/', apis.PurchasedPlans.as_view()),
    path('getfeedback/', apis.FeedbackAPI.as_view()),
]
