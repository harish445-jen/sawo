from celery import shared_task, task

from admindash.utils import (send_invitation,
                             update_currency_rates,
                             assign_free_plan_on_expire)


@shared_task
def task_send_invitation(email_id):
    return send_invitation(email_id)


@task(name='task_update_currency_rates')
def task_update_currency_rates():
    return update_currency_rates()


@task(name='task_assign_free_plan_on_expire')
def task_assign_free_plan_on_expire():
    return assign_free_plan_on_expire()
