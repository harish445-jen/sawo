class PurchaseTokenInvalid(Exception):
    pass


class FreePlanAlreadyUsed(Exception):
    pass
