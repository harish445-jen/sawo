from pytz import timezone
from bson.codec_options import CodecOptions

from sawo.mongodb import db

from django.conf import settings

sawo_admin_invitations_collection = db.sawo_admin_invitations.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

sawo_referrals_collection = db.sawo_referrals.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

currency_rates_collection = db.currency_rates.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))