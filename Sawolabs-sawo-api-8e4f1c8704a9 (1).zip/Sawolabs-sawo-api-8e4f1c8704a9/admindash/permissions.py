from rest_framework.permissions import BasePermission


class IsSawoAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.get('is_sawo_admin', False)
