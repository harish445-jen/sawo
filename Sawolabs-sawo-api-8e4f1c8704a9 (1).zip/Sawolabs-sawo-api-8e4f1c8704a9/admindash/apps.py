from django.apps import AppConfig


class AdmindashConfig(AppConfig):
    name = 'admindash'
