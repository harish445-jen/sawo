from rest_framework import serializers

from admindash.collections import sawo_admin_invitations_collection


class InvitationSerializer(serializers.Serializer):
    email_id = serializers.EmailField()


class SignupSerializer(serializers.Serializer):
    user_id = serializers.UUIDField()
    created_on = serializers.DateTimeField()
    identifier = serializers.CharField()
    identifier_type = serializers.CharField()
    verification_token = serializers.CharField()
    invitation_key = serializers.CharField()

    def validate(self, data):
        invitation = sawo_admin_invitations_collection.find_one(
            {'invitation_key': data['invitation_key']})
        if invitation:
            if invitation['email_id'] != data['identifier']:
                raise serializers.ValidationError('Email id is not same')
            return data
        raise serializers.ValidationError('Invalid Inviation Key')

class ReferralCodeSerializer(serializers.Serializer):
    auths_offered = serializers.IntegerField()
    code_text = serializers.CharField()
    num_of_referrals = serializers.IntegerField()
    created_referral_for = serializers.CharField()

class ReferralCodeUpdateSerializer(serializers.Serializer):
    change_count = serializers.IntegerField()
    code_text = serializers.CharField()
    created_referral_for = serializers.CharField()