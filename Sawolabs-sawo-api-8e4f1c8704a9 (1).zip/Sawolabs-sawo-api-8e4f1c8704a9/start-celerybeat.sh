#!/bin/sh
echo "Starting celery beat"
celery -A sawo beat -l info 
