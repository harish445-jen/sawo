### How to run the project

##### Install poetry

This is our package manager, this will handle all virtualenv and package managements

```
curl -sSL https://raw.githubusercontent.com/python-poetry/poetry/master/get-poetry.py | python
```

Poetry should add itself to PATH variable if it doesn't works for you add the following line to ~/.profile or file relevant to your OS

```
export PATH="$HOME/.poetry/bin:$PATH"
```

Sometime poetry throws an error `'PosixPath' is not defined`, execute following command to fix it, this will update poetry from preview channel

```
poetry self update --preview
```

Close your terminal and reopen and run following command to check everything went well

```
poetry --version
```

##### Install dotenv

Poetry doesn't support .env file, to use .env file we will need a python package `dotenv`, we need this installed globally on PC(Or atleast available for the current user), ensure no other command is available with same name

```
pip install "python-dotenv[cli]"
```

Run following command to ensure it is installed

```
dotenv --version
```

##### Clone the project

Clone the project

```
git clone <path to git repo>
```

##### Env file preparation

```
cp sample.env .env
```
Fill the .env file


##### Prepare the virtual env. and install dependencies
```
poetry install
```

##### Test the setup

```
dotenv run poetry run python manage.py runserver
```

If everything went well, the project should run at port 8000

##### Initialize the project

Use an usable email id to intialize the project, this email id will be needed to
login in admin and client console

```
dotenv run poetry run python manage.py initiate_project <initiator_email> <project_name>
```

##### Run the project

```
dotenv run poetry run python manage.py runserver
```

Run sawo-sdk-browser and client or admin dashboard as per your need, and you are ready to start coding!!

Happy coding

##### Add Referrals (2000, 3000, 5000)

```
dotenv run poetry run python manage.py make_referrals
```
##### Add an alias(Optional)

As adding `dotenv run poetry run` before every command is tedious work, add an alias to your shell rc file such as ~/.bashrc or ~/.zshrc

```
alias dp_run='dotenv run poetry run'
```
