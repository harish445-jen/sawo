from pytz import timezone
from bson.codec_options import CodecOptions

from django.conf import settings

from sawo.mongodb import db

verification_collection = db.verifications.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)))

blocked_devices_collection = db.blocked_devices.with_options(
    codec_options=CodecOptions(tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))

device_verification_collection = db.device_verification.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)
                               if not settings.IS_TESTING_MODE else None))

user_collection = db.users.with_options(codec_options=CodecOptions(
    tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))

sawo_cms_collection = db.sawo_cms.with_options(codec_options=CodecOptions(
    tz_aware=True, tzinfo=timezone(settings.TIME_ZONE)))

trusted_devices_collection = db.trusted_devices.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)
                               if not settings.IS_TESTING_MODE else None))

devices_subscription_collection = db.devices_subscription.with_options(
    codec_options=CodecOptions(tz_aware=True,
                               tzinfo=timezone(settings.TIME_ZONE)
                               if not settings.IS_TESTING_MODE else None))
