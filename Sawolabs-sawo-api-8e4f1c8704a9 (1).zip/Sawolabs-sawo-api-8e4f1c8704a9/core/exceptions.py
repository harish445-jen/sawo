class ValueDoesNotMatch(Exception):
    pass


class PlanExpired(Exception):
    pass


class UnAuthorized(Exception):
    pass


class NotSubscribed(Exception):
    pass


class NotAuthorised(Exception):
    pass


class TrustedDenied(Exception):
    pass
