IDENTIFIER_TYPE_CHOICES = (
    ('email', 'email'),
    ('phone_number_sms', 'phone_number_sms'),
    ('both_email_phone', 'both_email_phone')

)
DEVICE_TYPE_CHOICES = (
    ('browser', 'browser'),
    ('android', 'android'),
    ('ios', 'ios')
)
TRUSTED_RESPONSE_CHOICES = (('allowed', 'allowed'), ('denied', 'denied'))
