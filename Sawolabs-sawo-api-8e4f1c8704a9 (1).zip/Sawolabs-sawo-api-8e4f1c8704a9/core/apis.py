import redis
from datetime import datetime
from django.utils.timezone import now, timedelta
from django.conf import settings

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response

from client.collections import sawo_clients_projects_collection

from core.serializers import (VerificationInitiateSerializer,
                              VerificationSerializer,
                              UserVerificationSerializer,
                              ProjectInfoSerializer,
                              ShopifyIntegrateSerializer,
                              BigCommerceIntegrateSerializer,
                              IdentifierCheckSerializer,
                              SecondaryStatusCheckSerializer,
                              SecondaryTrustedDeviceSerializer,
                              DeviceRegisterSerializer,
                              MarkTrustedDevice,
                              ShopifyCustomerSerializer, BlockedDeviceSerializer)
from core.utils import (match_entries, get_challenge, verify_message,
                        construct_message_string, generate_otp,
                        get_or_create_user, log_user_entry, encrypt,
                        is_email_valid, is_phone_valid, update_data,
                        is_verification_required, from_sawo,
                        process_secondary_device, WPpassHash, validate_recaptcha, check_device_status, insert_blocked_device, verify_email_domain)
from core.exceptions import (
    ValueDoesNotMatch, PlanExpired, UnAuthorized, NotAuthorised, NotSubscribed,
    TrustedDenied)
from core.tasks import (task_send_otp, task_register_device,
                        task_mark_current_device_trusted,
                        task_remove_denied_sec_device,
                        task_update_cms_id,
                        task_send_shopify_cust_data)
from core.collections import (verification_collection,
                              device_verification_collection,
                              user_collection,
                              sawo_cms_collection,
                              trusted_devices_collection,
                              devices_subscription_collection, blocked_devices_collection)

import json
import copy
import gspread
from pymongo import ReturnDocument

from core.utils import toObjectId
# from core.utils2 import register_device, mark_current_device_trusted

from threading import Timer

from datetime import datetime, timezone

# Caching Part
from sawo.rediscache import r
CACHE_TIMEOUT = 24 * 60 * 60  # 1 day
CACHE_FRESHNESS = 60 * 60  # 1 hour
# If TTL less than this value, needs recalculate
REMAINING_CUTOFF = CACHE_TIMEOUT - CACHE_FRESHNESS


class VerificationInitiateAPI(APIView):
    """
    This API will initiate a verification process
    """

    def is_identifier_valid(self, identifier_info):
        if 'identifier' not in identifier_info:
            return False
        if identifier_info['identifier_type'] == 'email':
            return is_email_valid(identifier_info['identifier'])
        else:
            return is_phone_valid(identifier_info['identifier'])

    def post(self, request, format=None):
        serializer = VerificationInitiateSerializer(data=request.data)
        if serializer.is_valid():

            is_from_shopify = serializer.validated_data.get(
                'is_from_shopify', False)
            isfromBubble = serializer.validated_data.get('isfromBubble', False)
            serializer.validated_data.pop('is_from_shopify', None)
            serializer.validated_data.pop('isfromBubble', None)
            recaptcha_token = serializer.validated_data.get(
                'recaptcha_token', False)
            serializer.validated_data.pop('recaptcha_token', None)
            if recaptcha_token:  # add backend validation also for show_captcha later
                res = validate_recaptcha(recaptcha_token)
                if res['score'] >= 0.5:
                    pass
                else:
                    return Response(
                        {'error': "reCaptchaFailed",
                         'error_code': "420"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

            response_data = {}
            # raw_identifier -> required to send otp
            # (as it gets encrypted afterwards)
            raw_identifier = serializer.validated_data['identifier']
            has_trusted_device, is_identifier_valid = False, False

            # check if this device_id exists in the blockedDevices collection and
            # if it has been blocked, if yes, return 403 - not authorized
            # if not, proceed with the flow

            is_device_blocked, error_msg = check_device_status(serializer.validated_data['api_key'],
                                                               serializer.validated_data['host_name'],
                                                               serializer.validated_data['device_id'],
                                                               serializer.validated_data['secret_key'],
                                                               serializer.validated_data['device_type'],
                                                               serializer.validated_data['blocked_request_timestamp'])

            if is_device_blocked:

                return Response(error_msg,
                                status=status.HTTP_403_FORBIDDEN)

            verification = verification_collection.find_one_and_update(
                {"session_id": serializer.validated_data['session_id']},
                {'$set': {
                    'last_verification': now()
                }})
            device_verification = device_verification_collection.find_one(
                {"_id": toObjectId(serializer.validated_data['device_id'])})

            project = sawo_clients_projects_collection.find_one(
                {'api_key': request.data['api_key']})

            if serializer.validated_data['identifier_type'] == "email":

                restricted_email_domain = verify_email_domain(
                    raw_identifier, project)

                if restricted_email_domain:
                    return Response({'email_domain_error': project['email_domain_error']}, status=status.HTTP_403_FORBIDDEN)

            has_trusted_device = trusted_devices_collection.find_one({
                'identifier':
                    serializer.validated_data['identifier']
                    if not self.is_identifier_valid(serializer.validated_data)
                    else encrypt(raw_identifier, 'we_are_sawo_team'),
                'related_project_id': project['_id']
            })

            # require_verification -> check if re-verification is required
            #  based on project's session_cooldown
            require_verification = is_verification_required(
                verification, device_verification,
                serializer.validated_data['secret_key'], has_trusted_device)

            if device_verification and not require_verification:
                is_identifier_valid = self.is_identifier_valid(
                    device_verification)
                otp_info, are_values_matched = False, True
                if has_trusted_device:
                    trusted_device = devices_subscription_collection.find_one(
                        {'_id': has_trusted_device['subscribed_device_id']})
                try:
                    if raw_identifier != device_verification.get(
                            'identifier', False) and not from_sawo(
                                serializer.validated_data):
                        serializer.validated_data['identifier'] = encrypt(
                            raw_identifier, 'we_are_sawo_team')
                    elif not is_identifier_valid and encrypt(
                            raw_identifier,
                            'we_are_sawo_team') == device_verification.get(
                                'identifier', False) and from_sawo(
                                    serializer.validated_data):
                        device_verification = device_verification_collection.find_one_and_update(
                            {"_id": device_verification['_id']},
                            {"$set": {
                                "identifier": raw_identifier
                            }},
                            return_document=ReturnDocument.AFTER)

                    match_entries(device_verification,
                                  serializer.validated_data, [
                                      'identifier_type',  'identifier',
                                      'public_key', 'device_type',
                                      'device_info'
                                  ])

                except ValueDoesNotMatch:
                    are_values_matched = False

                challenge = get_challenge()
                response_data['challenge'] = challenge
                updated_data = {'challenge': challenge}

                # decide process of verification (trusted device or otp)
                if has_trusted_device:
                    # check if this is a trusted device or different device
                    if trusted_device[
                            'device_id'] == device_verification[
                                'device_id']:
                        response_data['verification_required'] = False
                    else:
                        try:
                            device_verification_copy = copy.copy(
                                device_verification)
                            (response_data['verification_required'],
                             response_data['secondary_id'],
                             response_data['trusted_id']) = \
                                process_secondary_device(
                                device_verification_copy,
                                has_trusted_device, trusted_device)
                            response_data['trusted_device_brand'] = \
                                trusted_device.get('device_brand', '')
                            response_data['trusted_device_model'] = \
                                trusted_device.get('device_model', '')
                        except NotSubscribed:
                            return Response('Current device not subscribed',
                                            status=status.HTTP_404_NOT_FOUND)
                        except TrustedDenied:
                            return Response(
                                'Current device was denied',
                                status=status.HTTP_403_FORBIDDEN
                            )
                else:
                    if are_values_matched:
                        otp_info = device_verification['otp']

                    if otp_info and otp_info['verified']:
                        response_data['otp_required'] = False
                    else:
                        if (serializer.validated_data['identifier'] ==
                            '+919833956848' or
                                serializer.validated_data['identifier']
                                == encrypt('+919833956848',
                                           'we_are_sawo_team')):
                            otp_info = generate_otp(static=True)
                        else:
                            otp_info = generate_otp()
                        updated_data['otp'] = otp_info
                        serializer.validated_data['otp'] = otp_info
                        # if serializer.validated_data['identifier_type'] == "phone_number_sms":
                        #     raw_identifier = serializer.validated_data['country_code'] + \
                        #         raw_identifier

                        task_send_otp.delay(
                            serializer.validated_data['project_id'],
                            serializer.validated_data['identifier_type'],
                            raw_identifier, otp_info)
                        response_data['otp_required'] = True

                if are_values_matched:
                    device_verification_collection.update_one(
                        {'_id': device_verification['_id']},
                        {'$set': updated_data})
                else:
                    update_data(
                        serializer.validated_data, {
                            'challenge': challenge,
                            'device_id': device_verification['device_id']
                        }, ['session_id', 'host_name',
                            'secret_key', 'project_id',
                            'device_token'])
                    device_verification_collection.replace_one(
                        {'_id': device_verification['_id']},
                        serializer.validated_data)
                    # TODO: test whether below statement can be safely removed
                    update_data(device_verification,
                                serializer.validated_data)

            else:
                if serializer.validated_data['identifier'] != (
                    device_verification['identifier']
                    if 'identifier' in device_verification else '') and \
                        not from_sawo(
                        serializer.validated_data):
                    serializer.validated_data['identifier'] = encrypt(
                        raw_identifier, 'we_are_sawo_team')
                challenge = get_challenge()
                updated_data = {
                    'challenge': challenge,
                    'identifier': serializer.validated_data['identifier'],
                    'device_id': device_verification.get('device_id', '')
                }
                if has_trusted_device:
                    trusted_devices_collection.delete_one({
                        'identifier':
                        serializer.validated_data['identifier'] if
                        not self.is_identifier_valid(serializer.validated_data)
                        else encrypt(raw_identifier, 'we_are_sawo_team'),
                        'related_project_id': project['_id']
                    })
                if (serializer.validated_data['identifier'] ==
                    '+919833956848' or
                    serializer.validated_data['identifier']
                    == encrypt('+919833956848',
                               'we_are_sawo_team')):
                    otp_info = generate_otp(static=True)
                else:
                    otp_info = generate_otp()
                # if serializer.validated_data['identifier_type'] == "phone_number_sms":
                #     raw_identifier = serializer.validated_data['country_code'] + \
                #         raw_identifier

                task_send_otp.delay(
                    serializer.validated_data['project_id'],
                    serializer.validated_data['identifier_type'],
                    raw_identifier, otp_info)

                response_data['otp_required'] = True
                updated_data['otp'] = otp_info
                update_data(
                    serializer.validated_data, updated_data,
                    ['session_id', 'host_name',
                     'secret_key', 'project_id',
                     'device_token'])
                device_verification_collection.replace_one(
                    {"_id":
                        device_verification.get('_id', '')},
                    serializer.validated_data)
                response_data['challenge'] = challenge
            # TODO: Fetch customer ID from the shopify store
            """
                PSEUDOCODE:
                1) [✔] Make a celery task and inside it ->
                2) Call the CMS server for fetching the ID of the customer
                    (provide the identifier)
                3) wait for its response...it will return the ID
                4) Take the customer ID and update the shopify.store_name with
                    the ID
                ** LETS BEGIN **
            """
            host_name = request.data.get('host_name',
                                         '')
            if is_from_shopify:
                task_update_cms_id(host_name=host_name,
                                   identifier=raw_identifier)

            return Response(response_data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class VerificationAPI(APIView):
    """
    This API will verify an identifier against a device e.g browser
    """

    def is_otp_valid(self, otp_info, validated_data):

        if otp_info['code'] != validated_data['otp']:
            return (False, 'OTP is invalid')
        if otp_info['created_on'] + timedelta(
                seconds=settings.IDENTIFIER_VALIDATION_OTP_EXPIRES_IN) < now():
            return (False, 'OTP is expired')
        return (True, '')

    def is_identifier_valid(self, identifier_info):
        if 'identifier' not in identifier_info:
            return False
        if identifier_info['identifier_type'] == 'email':
            return is_email_valid(identifier_info['identifier'])
        else:
            return is_phone_valid(identifier_info['identifier'])

    def post(self, request, format=None):

        serializer = VerificationSerializer(data=request.data)

        if serializer.is_valid():
            is_from_shopify = serializer.validated_data.get(
                'is_from_shopify', False)
            isfromWP = serializer.validated_data.get(
                'isfromWP', False)
            serializer.validated_data.pop('is_from_shopify', None)
            isfromBubble = serializer.validated_data.get('isfromBubble', False)
            serializer.validated_data.pop('isfromBubble', None)
            response_data = {}
            device_verification = device_verification_collection.find_one(
                {"_id": toObjectId(serializer.validated_data['device_id'])})

            if device_verification:

                raw_identifier = serializer.validated_data['identifier']
                # if serializer.validated_data['identifier_type'] == "phone_number_sms":
                #     raw_identifier = serializer.validated_data['country_code'] + \
                #         serializer.validated_data['identifier']
                try:
                    message, has_trusted_device = None, False
                    if raw_identifier != device_verification[
                            'identifier'] and from_sawo(
                                serializer.validated_data):
                        device_verification = device_verification_collection \
                            .find_one_and_update(
                                {"_id": device_verification['_id']},
                                {"$set": {
                                    "identifier": raw_identifier
                                }},
                                return_document=ReturnDocument.AFTER)
                    else:
                        key = encrypt(raw_identifier, 'we_are_sawo_team')
                        if raw_identifier != device_verification['identifier']:
                            serializer.validated_data['identifier'] = key
                        elif raw_identifier == device_verification[
                                'identifier'] and not from_sawo(
                                    serializer.validated_data):
                            signature_matcher = copy.copy(
                                serializer.validated_data)
                            signature_matcher['identifier'] = key
                            message = construct_message_string(
                                signature_matcher)
                    match_entries(
                        device_verification, serializer.validated_data, [
                            'identifier_type', 'identifier', 'public_key',
                            'device_type', 'device_info', 'challenge'
                        ])
                    project = sawo_clients_projects_collection.find_one(
                        {'api_key': str(serializer.validated_data['api_key'])})
                    # if serializer.validated_data['secret_key']:
                    has_trusted_device = \
                        trusted_devices_collection.find_one(
                            {
                                'identifier':
                                serializer.validated_data['identifier']
                                if not self.is_identifier_valid(
                                    serializer.validated_data)
                                else encrypt(
                                    raw_identifier, 'we_are_sawo_team'),
                                'related_project_id': project['_id']})
                    if has_trusted_device:
                        trusted_device = \
                            devices_subscription_collection.find_one(
                                {
                                    '_id':
                                    has_trusted_device['subscribed_device_id']
                                })
                        if trusted_device[
                                'device_id'] != device_verification[
                                    'device_id']:
                            secondary_device = \
                                devices_subscription_collection.find_one(
                                    {
                                        'device_id':
                                        device_verification[
                                            'device_id']
                                    })
                            if not secondary_device:
                                secondary_device = device_verification

                            device_status = has_trusted_device.get(
                                'secondary_devices',
                                {}).get(str(secondary_device['_id']), '')
                            if device_status != 'allowed':
                                return Response(
                                    {'error': 'Device not trusted'},
                                    status=status.HTTP_400_BAD_REQUEST)
                    else:
                        otp_info = device_verification['otp']
                        if not otp_info.get('verified', False):
                            is_valid, msg = self.is_otp_valid(
                                otp_info, serializer.validated_data)
                            if is_valid:
                                otp_info['verified'] = True
                                device_verification_collection.update_one(
                                    {'_id': device_verification['_id']},
                                    {'$set': {
                                        'otp': otp_info
                                    }})
                                if serializer.validated_data['secret_key']:
                                    user_identifier = encrypt(raw_identifier,
                                                              'we_are_sawo_team')
                                    task_mark_current_device_trusted.delay(
                                        device_verification['device_id'],
                                        user_identifier,
                                        str(serializer.validated_data['api_key']))
                            else:
                                return Response(
                                    {'error': msg},
                                    status=status.HTTP_400_BAD_REQUEST)
                    if not message:
                        message = construct_message_string(
                            serializer.validated_data)

                    if not verify_message(
                            device_verification['public_key'],
                            serializer.validated_data['signature'], message):
                        return Response({"error": "Signature invalid"},
                                        status=status.HTTP_400_BAD_REQUEST)

                    (response_data['user'],
                     response_data['is_already_registered'],
                     response_data['is_old_password_required']) = \
                        get_or_create_user(
                            raw_identifier,
                        serializer.validated_data['identifier'],
                        device_verification['identifier_type'],
                        is_from_shopify,
                        isfromBubble,
                        host_name=request.data[
                            "host_name"]
                    )
                    if serializer.validated_data['identifier_type'] == "phone_number_sms":
                        raw_identifier = raw_identifier.replace(
                            serializer.validated_data['country_code'], '')
                    response_data['user'].update({
                        'identifier': raw_identifier
                    })
                    if serializer.validated_data['identifier_type'] == "phone_number_sms":
                        response_data['user'].update({
                            'country_code': serializer.validated_data['country_code']
                        })
                    # if not from_sawo(serializer.validated_data):
                    if isfromWP:
                        response_data['user']['wp_key'] = WPpassHash(
                            raw_identifier)

                    try:
                        log_user_entry(request.data["api_key"],
                                       request.data["host_name"],
                                       request.data['secret_key'],
                                       response_data['user'])
                    except UnAuthorized:
                        return Response(
                            {"error": "Invalid Project Credentials"},
                            status=status.HTTP_400_BAD_REQUEST)
                    except PlanExpired:
                        return Response(
                            status=status.HTTP_402_PAYMENT_REQUIRED)
                    return Response(response_data)
                except ValueDoesNotMatch:
                    return Response({"error": "ValueDoesNotMatch"},
                                    status=status.HTTP_400_BAD_REQUEST)
            return Response({"error": """No device found.
                                Try again after refreshing the page"""},
                            status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class BlockDevice(APIView):
    """
    This API will block any device that can be a potential threat.
    """

    def post(self, request, request_type, format=None):
        """
        The post request is made when a threat is detected on the client side.
        """
        serializer = BlockedDeviceSerializer(data=request.data)

        if serializer.is_valid():
            # to check if the device_id already exists in the db
            blocked_device = blocked_devices_collection.find_one(
                {"device_id": serializer.validated_data['device_id']})

            if serializer.validated_data['device_type'] == "browser":

                # to check if the device_id and the web project already exist in the db
                blocked_device_with_same_project = blocked_devices_collection.find_one({'$and':
                                                                                        [{'api_key': serializer.validated_data['api_key']},
                                                                                         {'host_name': serializer.validated_data['host_name']},
                                                                                            {'device_id': serializer.validated_data['device_id']}]})
            else:
                # to check if the device_id and native project already exist in the db
                blocked_device_with_same_project = blocked_devices_collection.find_one({'$and':
                                                                                        [{'api_key': serializer.validated_data['api_key']},
                                                                                         {'secret_key': serializer.validated_data['secret_key']},
                                                                                            {'device_id': serializer.validated_data['device_id']}]
                                                                                        })

            # if it's the same device_id
            if blocked_device:

                # if it's the same device_id and project_id
                if blocked_device_with_same_project:

                    # if the client updates these three values from the client dashboard
                    blocked_devices_collection.update_one(blocked_device_with_same_project, {'$set': {
                        "max_otp_requests": serializer.validated_data['max_otp_requests'],
                        "blocked_time": serializer.validated_data['blocked_time'],
                        "blocked_timespan": serializer.validated_data['blocked_timespan']
                    }})

                    otp_requests_count = blocked_device_with_same_project['otp_requests_count']

                    updated_data = {}

                    request_interval = (
                        serializer.validated_data['timestamp'] - blocked_device_with_same_project['timestamp']).total_seconds()

                    invalid_otp_request = request_type == "invalidOTP"
                    otp_request = request_type == "OTPRequest"
                    invalid_otp_interval = request_interval <= blocked_device_with_same_project[
                        'blocked_timespan']
                    otp_request_interval = invalid_otp_interval
                    resend_otp_request = request_type == "resendOTP"
                    resend_otp_interval = request_interval <= (
                        blocked_device_with_same_project['blocked_timespan'] * 120)

                    if invalid_otp_request or otp_request:
                        if invalid_otp_interval or otp_request_interval:

                            updated_data['otp_requests_count'] = otp_requests_count + 1

                            if updated_data['otp_requests_count'] >= blocked_device_with_same_project['max_otp_requests']:
                                updated_data['blocked'] = True
                                updated_data['otp_requests_count'] = 0
                                updated_data['time_of_blocking'] = datetime.utcnow(
                                )

                        else:
                            updated_data['otp_requests_count'] = 0
                            updated_data['blocked'] = False

                    if resend_otp_request:
                        if resend_otp_interval:
                            updated_data['otp_requests_count'] = otp_requests_count + 1

                            if updated_data['otp_requests_count'] >= blocked_device_with_same_project['max_otp_requests']:

                                updated_data['blocked'] = True
                                updated_data['otp_requests_count'] = 0

                                updated_data['time_of_blocking'] = datetime.utcnow(
                                )
                        else:
                            updated_data['otp_requests_count'] = 0
                            updated_data['blocked'] = False

                    updated_data['timestamp'] = serializer.validated_data['timestamp']

                    blocked_devices_collection.update_one(blocked_device_with_same_project, {
                        '$set': updated_data
                    })

                    if blocked_device_with_same_project['device_type'] == "browser":

                        updated_blocked_device = blocked_devices_collection.find_one({'$and':
                                                                                      [{'api_key': blocked_device_with_same_project['api_key']},
                                                                                       {'host_name': blocked_device_with_same_project['host_name']},
                                                                                       {'device_id': blocked_device_with_same_project['device_id']}]
                                                                                      })
                    else:

                        updated_blocked_device = blocked_devices_collection.find_one({'$and':
                                                                                      [{'api_key': blocked_device_with_same_project['api_key']},
                                                                                       {'secret_key': blocked_device_with_same_project['secret_key']},
                                                                                       {'device_id': blocked_device_with_same_project['device_id']}]
                                                                                      })

                    if updated_blocked_device['blocked'] == True:

                        response_data = {}

                        blocked_time = timedelta(
                            seconds=float(updated_blocked_device['blocked_time']))

                        if blocked_time.days:
                            str_blocked_time = str(blocked_time).split(',')[1]
                        else:
                            str_blocked_time = str(blocked_time)

                        response_data['blocked'] = updated_blocked_device['blocked']
                        response_data['device_id'] = updated_blocked_device['device_id']
                        response_data['api_key'] = updated_blocked_device['api_key']
                        response_data['secret_key'] = updated_blocked_device['secret_key']
                        response_data['host_name'] = updated_blocked_device['host_name']
                        response_data['blocked_timespan'] = updated_blocked_device['blocked_timespan']
                        response_data['blocked_time_days'] = json.dumps(
                            blocked_time.days, default=str)
                        response_data['blocked_time_str'] = str_blocked_time
                        response_data['device_type'] = updated_blocked_device['device_type'].capitalize(
                        )
                        response_data['timestamp'] = updated_blocked_device['timestamp']
                        response_data['count'] = updated_blocked_device['otp_requests_count']

                        return Response(response_data,
                                        status=status.HTTP_403_FORBIDDEN)

                # if it's the same device_id but different project_id
                else:
                    otp_requests_count = 1
                    blocked = False
                    time_of_blocking = None
                    inserted_device = insert_blocked_device(
                        serializer._validated_data['device_id'],
                        serializer.validated_data['max_otp_requests'],
                        serializer.validated_data['blocked_time'],
                        otp_requests_count,
                        serializer.validated_data['api_key'],
                        serializer.validated_data['secret_key'],
                        serializer.validated_data['host_name'],
                        serializer.validated_data['device_type'],
                        blocked,
                        serializer.validated_data['blocked_timespan'],
                        serializer.validated_data['timestamp'],
                        time_of_blocking
                    )
                    inserted_device.pop('_id')

                    return Response(inserted_device, status=status.HTTP_200_OK)

            # if it's a different device_id
            else:
                otp_requests_count = 1
                blocked = False
                time_of_blocking = None
                inserted_device = insert_blocked_device(
                    serializer._validated_data['device_id'],
                    serializer.validated_data['max_otp_requests'],
                    serializer.validated_data['blocked_time'],
                    otp_requests_count,
                    serializer.validated_data['api_key'],
                    serializer.validated_data['secret_key'],
                    serializer.validated_data['host_name'],
                    serializer.validated_data['device_type'],
                    blocked,
                    serializer.validated_data['blocked_timespan'],
                    serializer.validated_data['timestamp'],
                    time_of_blocking
                )

                inserted_device.pop('_id')

                return Response(inserted_device,
                                status=status.HTTP_200_OK)
            return Response({'message': 'found device'},
                            status=status.HTTP_200_OK)

        else:
            return Response(serializer.errors,
                            status=status.HTTP_400_BAD_REQUEST)


class SecondaryTrustedDeviceAPI(APIView):
    """
    This API will be used to handle secondary trusted device.
    """

    def get(self, request, format=None):
        """
        Used to frequently check the status of secondary device
        """
        serializer = SecondaryStatusCheckSerializer(data=request.query_params)
        if serializer.is_valid():
            trusted_device = trusted_devices_collection.find_one(
                {'_id': toObjectId(serializer.validated_data['trusted_id'])})
            res = {}
            if trusted_device:
                device_status = trusted_device.get(
                    'secondary_devices',
                    {}).get(serializer.validated_data['secondary_id'], '')
                if device_status in ('allowed', 'pending'):
                    res['trusted_response'] = device_status
                else:
                    res['trusted_response'] = 'denied'
                return Response(res)
            return Response({"error": "No trusted device found"},
                            status=status.HTTP_404_NOT_FOUND)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        serializer = SecondaryTrustedDeviceSerializer(data=request.data)
        if serializer.is_valid():
            trusted_device = trusted_devices_collection.find_one(
                {'_id': toObjectId(serializer.validated_data['trusted_id'])})
            if trusted_device:
                try:
                    actual_device = devices_subscription_collection.find_one(
                        {'_id': trusted_device['subscribed_device_id']})
                    if actual_device[
                            'device_id'] != serializer.validated_data[
                                'device_id']:
                        raise NotAuthorised()
                    update_secondary_device = \
                        'secondary_devices.' + serializer.validated_data[
                            'secondary_id']
                    trusted_devices_collection.update_one(
                        {'_id': trusted_device['_id']},
                        {'$set': {
                            update_secondary_device:
                            serializer.validated_data['trusted_response']
                        }}
                    )
                    if serializer.validated_data['trusted_response'] == 'denied':
                        entry_secondary_device = 'secondary_devices.' + str(
                            serializer.validated_data['secondary_id'])
                        day_after_tomorrow = datetime.utcnow() + timedelta(days=2)
                        task_remove_denied_sec_device.apply_async((str(
                            trusted_device['_id']),
                            entry_secondary_device),
                            eta=day_after_tomorrow)
                    return Response()
                except NotAuthorised:
                    return Response(
                        {"error": "Not Authorised to perform this operation"},
                        status=status.HTTP_401_UNAUTHORIZED)
            else:
                return Response({"error": "No trusted device found"},
                                status=status.HTTP_404_NOT_FOUND)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class DeviceRegisterAPI(APIView):
    """
    This API will be used to add record device info
    and mark a device trusted against an identifier.
    """

    def post(self, request, format=None):
        serializer = DeviceRegisterSerializer(data=request.data)
        if serializer.is_valid():
            # register_device(serializer.validated_data)
            task_register_device.delay(serializer.validated_data)
            return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, format=None):
        # TODO: This method will need project api key in request.data
        serializer = MarkTrustedDevice(data=request.data)
        if serializer.is_valid():
            user_identifier = encrypt(serializer.validated_data['identifier'],
                                      'we_are_sawo_team')
            task_mark_current_device_trusted.delay(
                serializer.validated_data['subscribed_device'],
                user_identifier)
            return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserVerificationAPI(APIView):
    """
    This API will be used to verify an user
    """

    def post(self, request, format=None):
        serializer = UserVerificationSerializer(data=request.data)
        if serializer.is_valid():
            res = {
                "user_valid": False
            }
            user = user_collection.find_one(
                {'user_id': str(serializer.validated_data['user_id'])})
            if not user:
                return Response("User not Found", status=status.HTTP_400_BAD_REQUEST)
            if(user['verification_token'] == serializer.validated_data['verification_token']):
                res.update(
                    {
                        "user_valid": True
                    }
                )
                return Response(res, status=status.HTTP_200_OK)
            else:
                return Response(res, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class GetProjectInfoAPI(APIView):
    """
    This API will be used to get project info
    from client SDK
    """

    def get(self, request, format=None):
        serializer = ProjectInfoSerializer(data=request.query_params)

        if serializer.is_valid():
            verification = device_verification_collection.find_one_and_update(
                {'public_key': serializer.validated_data['data']
                    ['public_key']},
                {
                    '$set': {
                        'device_id':
                        serializer.validated_data['data']['device_id']
                    }
                })

            # take out values from serializer.validated_data
            session_id = serializer.validated_data['data']['session_id']
            project_id = serializer.validated_data['project']['_id']
            style = serializer.validated_data[
                'project']['style']
            identifier_check_endpoint = serializer.validated_data[
                'project'].get(
                'identifier_check', '')
            enable_beta_access = serializer.validated_data['project'].get(
                'enable_beta_access', '')
            limit_otp_data = serializer.validated_data['project']['limit_otp_data']

            res = dict()

            serializer.validated_data['data'].pop('session_id')
            if not verification:
                device = device_verification_collection.insert_one(
                    serializer.validated_data['data'])
                res['_device_id'] = str(device.inserted_id)

            else:
                res['_device_id'] = str(verification['_id'])
            verification_collection.update_one({'session_id': session_id}, {
                '$set': {
                    'device_id': toObjectId(res['_device_id']),
                    'project_id': project_id
                }
            },
                upsert=True)

            res.update({
                'project_id': str(project_id),
                'style': style,
                'limit_otp_data': limit_otp_data,
                'enable_beta_access': enable_beta_access
            })

            if identifier_check_endpoint:
                res.update({
                    'identifier_check_endpoint': identifier_check_endpoint
                })
            res.update({
                'identifier_type': serializer.validated_data['project']['identifier_type'],
                'custom_fields': serializer.validated_data[
                    'project']['custom_fields'],
                'login_button_text': serializer.validated_data[
                    'project']['login_button_text'],
                'show_sawo_logo': serializer.validated_data[
                    'project']['show_sawo_logo'],
                'show_captcha': serializer.validated_data[
                    'project']['show_captcha'],
                'company_logo_iframe': serializer.validated_data[
                    'project']['company_logo_iframe'],
                'showPrivacy': serializer.validated_data[
                    'project']['showPrivacy'],
                'privacyLink': serializer.validated_data[
                    'project']['privacyLink'],

            })
            return Response(res)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class IdentifierCheck(APIView):
    """
    This API will check if identifier should be allowed
    """

    def post(self, request, format=None, project_id=None):
        serializer = IdentifierCheckSerializer(data=request.data)

        if serializer.is_valid() and project_id:
            is_valid = False
            identifier = serializer.validated_data['identifier']
            identifier_type = serializer.validated_data['identifier_type']
            if identifier_type == "phone_number_sms":
                # country_code = serializer.validated_data['country_code']
                # identifier = country_code[1:] + identifier
                identifier = identifier[1:]

            # project_id = serializer.validated_data['project_id']
            try:
                project = sawo_clients_projects_collection.find_one(
                    {'project_id': project_id})

                if not project['enable_beta_access']:
                    is_valid = True

                if (project['enable_beta_access'] and project['google_sheet_link']):

                    gs = gspread.service_account("service_account.json")
                    google_sheet = gs.open_by_url(project['google_sheet_link'])
                    sheet = google_sheet.get_worksheet(0)
                    sheetData = sheet.get_values()
                    sheetData = (sheetData, sheetData[:project['maximum_users']+1])[
                        len(sheetData) > project['maximum_users']+1]

                    if ([identifier] in sheetData):
                        is_valid = True

            except Exception as e:
                print(e)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            return Response({'valid': is_valid})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ShopifyIntegrateAPI(APIView):
    """
    This API will be used to get/post the shopify app credentials
    entered by client
    """

    def get(self, request, shop_name=None, format=None):
        if shop_name:
            cache_key = 'ShopifyIntegrateAPI:get:{}'.format(shop_name)
            lock_key = 'Lock:{}'.format(cache_key)
            cache_value = r.get(cache_key)

            if cache_value is not None:
                cache_value = json.loads(cache_value)
            remaining_ttl = r.ttl(cache_key)

            should_recalculate = remaining_ttl < REMAINING_CUTOFF

            if not should_recalculate and cache_value is not None:
                # if key is fresh enough, and value exists, just return!
                return Response(cache_value)

            # try to acquire lock to recalculate..
            try:
                with r.lock(lock_key, timeout=60, blocking_timeout=0):
                    res = sawo_cms_collection.find_one({'host': shop_name})
                    if not res:
                        return Response(status=status.HTTP_404_NOT_FOUND)
            except redis.exceptions.LockError:
                # somebody else is calculating,
                # if cache value exists, no problem, no error
                if cache_value is not None:
                    return Response(cache_value)
                else:
                    return Response(
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            res['_id'] = str(res['_id'])
            cache_representation = json.dumps(res)

            r.set(cache_key, cache_representation, CACHE_TIMEOUT)
            return Response(res)
        return Response({"error": "Invalid Request"},
                        status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        serializer = ShopifyIntegrateSerializer(data=request.data)

        if serializer.is_valid():
            data = serializer.validated_data
            if '_id' in data and data['_id']:
                res = sawo_cms_collection.find_one_and_update(
                    {'_id': toObjectId(data['_id'])}, {
                        "$set": {
                            "api_key": data['api_key'],
                            "identifier": data['identifier'],
                            "login_path": data['login_path']
                        }
                    },
                    upsert=True,
                    return_document=ReturnDocument.AFTER)
                res['_id'] = str(res['_id'])
                cache_key = 'ShopifyIntegrateAPI:get:{}'.format(res['host'])
                cache_value = r.get(cache_key)
                if cache_value is not None:
                    r.delete(cache_key)
                cache_representation = json.dumps(res)
                r.set(cache_key, cache_representation, CACHE_TIMEOUT)
                return Response(res)
            elif ('host' in data and data['host']) and ('token' in data
                                                        and data['token']):
                # api_key = create_shopify_client(data['email'],
                #                                 data['host'],
                #                                 data['domain'])
                res = sawo_cms_collection.find_one_and_update({
                    'host': data['host']
                },
                    {
                    '$set': {
                        'token': data['token'],
                        'domain': data['domain'],
                        'email': data['email'],
                        "api_key": data['api_key'],
                        "identifier": 'email',
                        "login_path": '/account/login'
                    }
                }, upsert=True)
                cache_key = 'ShopifyIntegrateAPI:get:{}'.format(data['host'])
                r.delete(cache_key)
                return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, shop_name=None, format=None):
        if shop_name:
            sawo_cms_collection.delete_many({'host': shop_name})
            cache_key = 'ShopifyIntegrateAPI:get:{}'.format(shop_name)
            r.delete(cache_key)
            return Response()
        return Response(status=status.HTTP_404_NOT_FOUND)


@api_view(['DELETE'])
def delete_shopify_customers(request):
    serializer = ShopifyCustomerSerializer(data=request.query_params)
    if serializer.is_valid():
        shop_name = serializer.validated_data['shop_name']
        shopify_user = f'shopify.{shop_name}'
        shopify_user_new_user = shopify_user + '_new_user'
        shopify_user_old_user = shopify_user + '_old_user'
        user_collection.update_many({
            shopify_user: {
                '$exists': 1
            }
        }, {
            '$unset': {
                shopify_user: 1,
                shopify_user_new_user: 1,
                shopify_user_old_user: 1
            }
        })
        return Response()
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def send_shopify_cust_details(request):
    serializer = ShopifyCustomerSerializer(data=request.data)
    if serializer.is_valid():
        task_send_shopify_cust_data.delay(
            serializer.validated_data.get('shop_name', ''))
        return Response()
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ShopifyCustomerAPI(APIView):
    """
    This API will be used to sync customers signed-in to stores
    on shopify with our system
    """

    def put(self, request, shop_name=None, format=None):
        if shop_name:
            shopify_user = f'shopify.{shop_name}'
            shopify_user_new_user = shopify_user + '_new_user'
            user_collection.find_one_and_update({
                'identifier': {
                    '$in': [encrypt(
                        request.data['email'], 'we_are_sawo_team'),
                        request.data['email']]}},
                {'$set': {
                    shopify_user: int(request.data['id']),
                    shopify_user_new_user: False
                }
            })
            return Response()
        return Response(status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, shop_name=None, format=None):
        if shop_name:
            shopify_user = f'shopify.{shop_name}'
            shopify_user_new_user = shopify_user + '_new_user'
            shopify_user_old_user = shopify_user + '_old_user'
            user_collection.update({
                shopify_user: int(request.data['id'])},
                {'$unset': {
                    shopify_user: 1,
                    shopify_user_new_user: 1,
                    shopify_user_old_user: 1
                }
            })
            return Response()
        return Response(status=status.HTTP_404_NOT_FOUND)


class BigCommerceIntegrateAPI(APIView):
    """
    This API will be used to get/post the BigCommerce app credentials
    entered by client
    """

    def get(self, request, store_hash=None, format=None):
        if store_hash:
            cache_key = 'BigCommerceIntegrateAPI:get:{}'.format(store_hash)
            lock_key = 'Lock:{}'.format(cache_key)
            cache_value = r.get(cache_key)

            if cache_value is not None:
                cache_value = json.loads(cache_value)
            remaining_ttl = r.ttl(cache_key)

            should_recalculate = remaining_ttl < REMAINING_CUTOFF

            if not should_recalculate and cache_value is not None:
                # if key is fresh enough, and value exists, just return!
                return Response(cache_value)

            # try to acquire lock to recalculate..
            try:
                with r.lock(lock_key, timeout=60, blocking_timeout=0):
                    res = sawo_cms_collection.find_one(
                        {'store_hash': store_hash})
                    if not res:
                        return Response(status=status.HTTP_404_NOT_FOUND)
            except redis.exceptions.LockError:
                # somebody else is calculating,
                # if cache value exists, no problem, no error
                if cache_value is not None:
                    return Response(cache_value)
                else:
                    return Response(
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            res['_id'] = str(res['_id'])
            cache_representation = json.dumps(res)
            r.set(cache_key, cache_representation, CACHE_TIMEOUT)
            return Response(res)
        return Response({"error": "Invalid Request"},
                        status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        serializer = BigCommerceIntegrateSerializer(data=request.data)
        if serializer.is_valid():
            data = serializer.validated_data
            if '_id' in data and data['_id']:
                updated_data = {
                    "api_key": data['api_key'],
                    "identifier": data['identifier'],
                    "login_trigger_method": data['login_trigger_method'],
                    "redirect_link": data['redirect_link'],
                    "restricted_urls": data['restricted_urls']
                }
                if 'script_uuid' in data:
                    updated_data['script_uuid'] = data['script_uuid']

                res = sawo_cms_collection.find_one_and_update(
                    {'_id': toObjectId(data['_id'])}, {"$set": updated_data},
                    upsert=True,
                    return_document=ReturnDocument.AFTER)

                res['_id'] = str(res['_id'])
                cache_key = 'BigCommerceIntegrateAPI:get:{}'.format(
                    res['store_hash'])
                cache_value = r.get(cache_key)
                if cache_value is not None:
                    r.delete(cache_key)
                cache_representation = json.dumps(res)
                r.set(cache_key, cache_representation, CACHE_TIMEOUT)
                return Response(res)
            elif ('store_hash' in data and
                  data['store_hash']) and ('token' in data and data['token']):
                sawo_cms_collection.insert_one({
                    'store_hash':
                    data['store_hash'],
                    'token':
                    data['token']
                })
            return Response()
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, store_hash=None, format=None):
        if store_hash:
            sawo_cms_collection.delete_one({'store_hash': store_hash})
            cache_key = 'BigCommerceIntegrateAPI:get:{}'.format(store_hash)
            r.delete(cache_key)
            return Response()
        return Response(status=status.HTTP_404_NOT_FOUND)
