from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from core.collections import user_collection
from core.utils import encrypt


class WPCustomerAPI(APIView):
    """
    This API will be used to sync customers signed-in to wordpress
    with our system
    """

    def put(self, request, host_name=None, format=None):
        if host_name:
            host_name = host_name.replace('.', '_')
            wp_user = f'wp.{host_name}'
            wp_user_new_user = wp_user + '_new_user'
            user_collection.find_one_and_update({
                'identifier': {
                    '$in': [encrypt(
                        request.data['email'], 'we_are_sawo_team'),
                        request.data['email']]}},
                {'$set': {
                    wp_user: int(request.data['id']),
                    wp_user_new_user: False
                }
            })
            return Response()
        return Response(status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, host_name=None, format=None):
        if host_name:
            host_name = host_name.replace('.', '_')
            wp_user = f'wp.{host_name}'
            wp_user_new_user = wp_user + '_new_user'
            wp_user_old_user = wp_user + '_old_user'
            user_collection.update({
                wp_user: int(request.data['id'])},
                {'$unset': {
                    wp_user: 1,
                    wp_user_new_user: 1,
                    wp_user_old_user: 1
                }
            })
            return Response()
        return Response(status=status.HTTP_404_NOT_FOUND)
