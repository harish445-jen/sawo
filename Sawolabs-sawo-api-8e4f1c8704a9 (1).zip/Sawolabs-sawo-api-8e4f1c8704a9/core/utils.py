import re
from threading import Thread

from uuid import uuid4
from django.conf import settings
from django.utils.timezone import now, timedelta
from datetime import datetime
from paymentgateway.tasks import task_send_plan_expired_emailer
# from django.conf import settings
from sawo.settings.base import get_env_var

from nacl import encoding, signing
from nacl.exceptions import BadSignatureError
import hashlib

from django.utils.crypto import get_random_string
from authhelper.collections import sawo_users_collection

from core.exceptions import (
    ValueDoesNotMatch, PlanExpired, UnAuthorized,
    TrustedDenied)
from core.collections import (
    user_collection,
    devices_subscription_collection,
    trusted_devices_collection,
    sawo_cms_collection, blocked_devices_collection)
from core.tasks import (task_send_expiry,
                        task_remove_sec_device,
                        task_ask_from_trusted_device)

from client.collections import (sawo_clients_projects_collection,
                                sawo_clients_plans_collection,
                                sawo_auths_log_collection,
                                )

from sawo.mongodb import (sawo_freemium_plan_collection,
                          sawo_premium_plan_collection)

from pymongo import ReturnDocument
from sawo.rediscache import r
from bson.objectid import ObjectId
import requests


def is_email_valid(email):
    regex = r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w+$'
    # pass the regular expression
    # and the string in search() method
    if (re.search(regex, email)):
        return True
    else:
        return False


def is_phone_valid(phone):

    regex = r'^[\+\(]?\d+(?:[- \)\(]+\d+)+$'
    if re.search(regex, phone):
        return True
    else:
        return False


def from_sawo(data):
    return data['host_name'] == get_env_var(
        'CLIENT_DASH_HOST') or data['host_name'] == get_env_var(
            'ADMIN_DASH_HOST') or data['host_name'] == get_env_var(
            'CMS_SDK_HOST') or settings.SITE_TYPE in ['local', 'staging']


def is_verification_required(verification: dict, otp_info: dict,
                             is_mobile_platform: bool,
                             trusted_device_info) -> bool:
    try:
        prj = sawo_clients_projects_collection.find_one(
            {'_id': verification['project_id']})
        cooldown_days = int(prj.get('session_cooldown', '15d').split('d')[0])
        # if not is_mobile_platform:
        #     if otp_info.get('otp', None):
        #         return (otp_info['otp']['created_on'] +
        #                 timedelta(days=cooldown_days)) < now()
        #     return True
        if trusted_device_info:
            if trusted_device_info.get('created_on', None):
                return (trusted_device_info['created_on'] +
                        timedelta(days=cooldown_days)) < now()
        else:
            if otp_info.get('otp', None):
                return (otp_info['otp']['created_on'] +
                        timedelta(days=cooldown_days)) < now()
        return True
    except Exception as e:
        print(e)
        return True


def process_secondary_device(device_obj, trusted_device,
                             trusted_device_info):
    secondary_device = devices_subscription_collection.find_one(
        {'device_id': device_obj['device_id']})
    if not secondary_device:
        secondary_device = device_obj
        # raise NotSubscribed()
    # Check if the secondary device is already allowed
    device_status = trusted_device.get('secondary_devices',
                                       {}).get(str(secondary_device['_id']),
                                               '')
    if device_status == 'allowed':
        return False, '', ''
    elif device_status != 'denied':
        if not device_status:
            entry_secondary_device = 'secondary_devices.' + str(
                secondary_device['_id'])
            trusted_devices_collection.find_one_and_update(
                {'_id': trusted_device['_id']},
                {'$set': {
                    entry_secondary_device: 'pending'
                }})
            task_remove_sec_device.apply_async((str(trusted_device['_id']),
                                                entry_secondary_device),
                                               countdown=300
                                               #    countdown=15
                                               )
            trusted_device_info['_id'] = str(trusted_device_info['_id'])
            secondary_device['_id'] = str(secondary_device['_id'])
            task_ask_from_trusted_device.delay(str(trusted_device['_id']),
                                               trusted_device_info,
                                               secondary_device)
        return True, str(secondary_device['_id']), str(trusted_device['_id'])
    raise TrustedDenied("Trusted device denied permission.")


def update_data(data: dict, data_to_be_added: dict,
                data_to_be_removed: list = []) -> dict:
    data.update(data_to_be_added)
    [data.pop(key, None) for key in data_to_be_removed]
    # return data


def match_entries(db_entry: dict, request_data: dict, keys: list) -> None:
    """
    Matches users request data and entry stored in db, if fails raises
    ValueDoesNotMatch
    """
    for key in keys:
        if db_entry[key] != request_data[key]:
            raise ValueDoesNotMatch('{} doesn\'t matches'.format(key))


def verify_email_domain(identifier: str, project: dict):
    identifier_domain = identifier.split('@')[1]
    if len(project['restricted_email_domains']) > 0:
        if identifier_domain in project['restricted_email_domains']:
            return True
    return False


def insert_blocked_device(device_id, max_otp_requests, blocked_time,
                          otp_requests_count, api_key, secret_key, host_name, device_type, blocked, blocked_timespan, timestamp, time_of_blocking=None):
    new_blocked_device = {}

    new_blocked_device["device_id"] = device_id
    new_blocked_device["max_otp_requests"] = max_otp_requests
    new_blocked_device["blocked_time"] = blocked_time
    new_blocked_device["otp_requests_count"] = otp_requests_count
    new_blocked_device["api_key"] = api_key
    new_blocked_device["secret_key"] = secret_key
    new_blocked_device["host_name"] = host_name
    new_blocked_device["device_type"] = device_type
    new_blocked_device['blocked'] = blocked
    new_blocked_device['blocked_timespan'] = blocked_timespan
    new_blocked_device['timestamp'] = timestamp
    new_blocked_device['time_of_blocking'] = time_of_blocking

    # new_blocked_device['ip_address'] = ip_address

    inserted_blocked_device = blocked_devices_collection.insert_one(
        new_blocked_device)

    return new_blocked_device


def check_device_status(api_key: str, host_name: str, device_id: str, secret_key: str, device_type: str, blocked_request_timestamp):
    if device_type == "browser":
        unblocked_device = blocked_devices_collection.find_one({'$and':
                                                                [{'api_key': api_key},
                                                                 {'host_name': host_name},
                                                                    {'device_id': device_id}]
                                                                })
    else:

        # to check if the device_id and native project already exist in the db
        unblocked_device = blocked_devices_collection.find_one({'$and':
                                                                [{'api_key': api_key},
                                                                 {'secret_key': secret_key},
                                                                    {'device_id': device_id}]
                                                                })

    if unblocked_device:
        request_interval = (blocked_request_timestamp -
                            unblocked_device['timestamp']).total_seconds()
        otp_requests_count = unblocked_device['otp_requests_count']

        if request_interval > unblocked_device['blocked_timespan']:
            otp_requests_count = 0
        blocked_devices_collection.update_one(unblocked_device, {'$set': {
            'timestamp': blocked_request_timestamp,
            'otp_requests_count': otp_requests_count
        }})

    if device_type == "browser":
        blocked_device = blocked_devices_collection.find_one({'$and':
                                                              [{'api_key': api_key},
                                                               {'host_name': host_name},
                                                               {'device_id': device_id}, {
                                                                  'blocked': True
                                                              }]
                                                              })
    else:

        # to check if the device_id and native project already exist in the db
        blocked_device = blocked_devices_collection.find_one({'$and':
                                                              [{'api_key': api_key},
                                                               {'secret_key': secret_key},
                                                               {'device_id': device_id},
                                                               {
                                                                  'blocked': True
                                                              }]
                                                              })
    is_device_blocked = False

    if blocked_device:

        still_blocked = (datetime.utcnow(
        ) - blocked_device['time_of_blocking'].replace(tzinfo=None)).total_seconds()

        # print(still_blocked)

        time_left_to_unblock = float(
            blocked_device['blocked_time']) - still_blocked

        time_left_to_unblock = timedelta(
            seconds=float(time_left_to_unblock))

        # str_time_left_to_unblock = str(time_left_to_unblock)

        # display_time = str_time_left_to_unblock.split(':')

        is_device_blocked = (datetime.utcnow() - blocked_device['time_of_blocking'].replace(
            tzinfo=None)).total_seconds() <= float(blocked_device['blocked_time'])

        if not is_device_blocked:
            blocked_devices_collection.update_one(blocked_device, {"$set": {
                "blocked": False
            }})
    display_time = ""
    if is_device_blocked:
        display_time = time_left_to_unblock

    return construct_blocked_device_message(is_device_blocked, display_time, device_type)


def construct_blocked_device_message(is_device_blocked, display_time, device_type):
    error_msg = {}

    if is_device_blocked:

        if display_time.days:
            blocked_time_days = display_time.days
        else:
            blocked_time_str = str(display_time)

        if display_time.days:
            error_msg['blocked_time_days'] = blocked_time_days

        error_msg['device_type'] = device_type.capitalize(
        )
        error_msg['blocked'] = True
        error_msg['blocked_time_str'] = blocked_time_str

    return is_device_blocked, error_msg


def construct_message_string(data: dict) -> str:
    return data['identifier_type'] \
        + data['identifier'] \
        + data['device_type'] \
        + data['device_info'] \
        + data['challenge'] \
        + data['secret_key']


def get_challenge(length: int = 36) -> str:
    return get_random_string(
        length, allowed_chars='abcdefghijklmnopqrstuvwxyz1234567890')


def validate_recaptcha(recaptcha_response):
    data = {
        'secret': settings.GOOGLE_RECAPTCHA_SECRET_KEY,
        'response': recaptcha_response
    }
    r = requests.post(
        'https://www.google.com/recaptcha/api/siteverify', data=data)
    result = r.json()
    return result


def generate_otp(length: int = 6, static: bool = False) -> dict:
    if static:
        code = '1234'
    else:
        code = get_random_string(length, allowed_chars='1234567890')
    print(code)
    return {'code': code, 'created_on': datetime.utcnow(), 'verified': False}


def verify_message(public_key: str, smessage: str, message: str) -> bool:
    verify_key = signing.VerifyKey(public_key, encoder=encoding.Base64Encoder)
    try:
        m = verify_key.verify(smessage, encoder=encoding.Base64Encoder)
        return m.decode('utf-8') == message
    except BadSignatureError:
        return False


def from_shopify(host_name):
    return host_name.split(
        '.')[-2] == 'myshopify' if len(host_name.split('.')) > 2 else False


def get_or_create_user(raw_identifier: str,
                       identifier: str,
                       identifier_type: str,
                       is_from_shopify: bool,
                       isfromBubble: bool,
                       host_name: str) -> tuple:
    # return values
    user = user_collection.find_one({
        "identifier": {
            '$in': [encrypt(
                raw_identifier, 'we_are_sawo_team'),
                raw_identifier]
        }
    })
    is_already_registered, ask_old_pass = True, False

    if is_from_shopify:
        cms_res = sawo_cms_collection.find_one({
            'domain':
            host_name})
        shopify_store = cms_res.get('host', '')
        shopify_user = f'shopify.{shopify_store}'

    if user:
        updated_data = {
            'verification_token': get_random_string(length=36)
        }
        if user['identifier'] != identifier:
            updated_data['identifier'] = raw_identifier

        if is_from_shopify:
            try:
                is_user_new = user['shopify'][shopify_store+'_new_user']
                if is_user_new:
                    updated_data.update({
                        f'{shopify_user}_new_user': False
                    })
                    is_already_registered = False
            except KeyError:
                try:
                    if user['shopify'][shopify_store+'_old_user']:
                        # is_already_registered = True
                        ask_old_pass = True
                except KeyError:
                    is_already_registered = False
        if isfromBubble:
            try:
                is_user_old = user['bubble']['bubble_new_user']
                if is_user_old:
                    print("entered here!!")
                    updated_data.update({
                        'bubble': {
                            f'{"bubble"}_new_user': False
                        }
                    })
                    is_already_registered = True
            except KeyError:
                print("updated new user true")
                updated_data.update({
                    'bubble': {
                        f'{"bubble"}_new_user': True
                    }
                })
                is_already_registered = False

        user = user_collection.find_one_and_update(
            {'_id': user['_id']},
            {
                '$set': updated_data
            },
            return_document=ReturnDocument.AFTER)
    else:
        user = {
            'user_id': str(uuid4()),
            'created_on': datetime.utcnow(),
            'identifier': identifier,
            'identifier_type': identifier_type,
            'verification_token': get_random_string(length=36)
        }

        if is_from_shopify:
            user.update({
                'shopify': {
                    f'{shopify_store}_new_user': False
                }
            })
            is_already_registered = False
        if isfromBubble:
            user.update({
                'bubble': {
                    f'{"bubble"}_new_user': True
                }
            })
            is_already_registered = False
            ask_old_pass = False
        user_collection.insert_one(user)
    user.pop('_id')
    return user, is_already_registered, ask_old_pass


def generate_signature(challenge: str) -> str:
    signing_key = signing.SigningKey.generate()
    signature = signing_key.sign()
    return signature


def toObjectId(string):
    try:
        return ObjectId(string)
    except Exception:
        return ""


def encrypt(secret: str, salt: str) -> str:
    encrypted_cached_val = r.get(secret)
    if (encrypted_cached_val):
        return encrypted_cached_val
    encryption_result = hashlib.pbkdf2_hmac('sha256', secret.encode('utf-8'),
                                            salt.encode('utf-8'), 100000).hex()
    r.set(secret,
          encryption_result,
          2 * 60 * 60  # 2 hours
          )
    return encryption_result


def log_user_entry(api_key: str, host_name: str, secret_key: str,
                   user: object):
    host_name_updated = ""
    if 'www' in str(host_name):
        host_name_updated = str(host_name).replace('www.', '')
    else:
        host_name_updated = str(host_name)
    
    project = sawo_clients_projects_collection.find_one({
        'api_key': api_key,
        '$or': [{
                'host_name': host_name_updated
                }, {
                'secret_key': secret_key
                }]
    })
    if not project:
        raise UnAuthorized("Invalid Project Credentials")

    # Taking useful values in variables
    _id = project['_id']
    client_id = project['related_client_id']

    # check active plan
    active_plan = sawo_clients_plans_collection.find_one_and_update({
        'is_active': True,
        'related_client_id': client_id
    }, {
        '$inc': {
            'auths_consumed': 1
        }
    })

    if not active_plan:
        # [PLAN SWITCH] - make any other plan active, if available in queue
        start_date = now()
        active_plan = sawo_clients_plans_collection.find_one_and_update({
            'is_expired': False,
            'related_client_id': client_id,
            'start_date': {
                '$gt': start_date - timedelta(days=30)
            },
        }, {
            '$set': {
                'is_active': True,
                'start_date': start_date
            },
            '$inc': {
                'auths_consumed': 1
            }
        })
        if active_plan:
            if active_plan['plan_type'] == 'Free':
                sawo_freemium_plan_collection.find_one_and_update({
                    'plan_id': active_plan['plan_id']
                }, {
                    '$set': {
                        'start_date': start_date
                    }
                })
            else:
                sawo_premium_plan_collection.find_one_and_update({
                    'plan_id': active_plan['plan_id']
                }, {
                    '$set': {
                        'start_date': start_date
                    }
                })
            sawo_users_collection.update_one(
                {'_id': client_id}, {
                    '$set': {
                        'auths_remaining': active_plan['auths_offered'],
                        'auths_filled': active_plan['auths_offered']
                    }
                })
    # If no plan found to log auth, simply return with error
    if not active_plan:

        # SEND PLAN EXPIRED EMAILER
        try:
            sawo_user = sawo_users_collection.find_one(client_id)
            t = Thread(target=task_send_plan_expired_emailer, kwargs={
                "email": sawo_user['identifier'],
                "parameters": {"user_name": sawo_user['first_name']}})
            t.start()
        except:
            pass

        raise PlanExpired("Plan has expired")

    # log user auth
    auth = {'createdAt': datetime.utcnow(), 'user': user['user_id']}
    auth_plan = 'auths.plan_id'
    # push auth to auths_list against already active plan
    sawo_auths_log_collection.update_one(
        {
            'related_client_id': client_id,
            'related_project_id': _id,
            auth_plan: active_plan['_id']
        }, {'$push': {
            "auths.$.auths_list": auth
        }})
    # create auths_list if its first time plan is used
    sawo_auths_log_collection.update_one(
        {
            'related_client_id': client_id,
            'related_project_id': _id,
            auth_plan: {
                '$ne': active_plan['_id']
            }
        }, {
            '$addToSet': {
                'auths': {
                    'plan_id': active_plan['_id'],
                    'auths_list': [auth]
                }
            }
        })

    # Make record entry format
    today = datetime.today()
    week = today.weekday()
    plan = 'used_plans.' + str(active_plan['_id'])
    entry = plan + ".total_records." + str(today.month) + "/" + str(today.year)
    entry_week = plan + ".total_records_week." + str(week)

    # update the auths count of client user
    remaining_auths = sawo_users_collection.find_one_and_update(
        {'_id': client_id}, {'$inc': {
            'auths_remaining': -1
        }},
        return_document=ReturnDocument.AFTER)['auths_remaining']
    # log plan activity to project record by increasing auth usage count
    sawo_clients_projects_collection.find_one_and_update(
        {'_id': project['_id']}, {'$inc': {
            entry: 1,
            entry_week: 1
        }})
    # check if plan exhausted or time expired
    exhausted_plan = (remaining_auths == 0)
    does_plan_exist = True
    if active_plan['plan_type'] == 'Free':
        does_plan_exist = sawo_freemium_plan_collection.find_one(
            {'plan_id': active_plan["plan_id"]})
    else:
        does_plan_exist = sawo_premium_plan_collection.find_one(
            {'plan_id': active_plan["plan_id"]})

    if (not does_plan_exist) or exhausted_plan:
        # Mark plan as expired
        update_fields = {
            'is_expired': True,
            'is_active': False,
            'expire_date': datetime.utcnow()
        }
        sawo_users_collection.update_one(
            {'_id': client_id}, {
                '$set': {
                    'auths_remaining': 0,
                    'auths_filled': 0
                }
            })
        sawo_clients_plans_collection.find_one_and_update(
            {
                'is_active': True,
                'related_client_id': client_id
            }, {'$set': update_fields})
        task_send_expiry.delay(str(client_id))
        # raise PlanExpired("Plan has expired")


# def create_shopify_client(email: str, shop_name: str, domain: str) -> str:
#     sawo_client = sawo_users_collection.find_one({'identifier': email})
#     if not sawo_client:
#         if not user_collection.find_one({'identifier': email}):
#             user = {
#                 'user_id': str(uuid4()),
#                 'created_on': datetime.utcnow(),
#                 'identifier': email,
#                 'identifier_type': 'email',
#                 'verification_token': get_random_string(length=36)
#             }
#             user_collection.insert_one(user)
#         user = sawo_users_collection.insert_one(
#             {'identifier': email,
#              'ref_id': get_random_string(length=10),
#              'joined_at': datetime.utcnow(),
#              'is_sawo_client': True})
#         plan_details = {
#             'plan_type': 'Free',
#             'auths_offered': 5000,
#             'plan_price': Decimal(0),
#             'plan_currency_code': 'INR',
#             'client_id': user.inserted_id
#         }
#         admindash.utils.create_plan(plan_details, True)
#         base_project = {
#             "project_name": shop_name,
#             "project_id": str(uuid4()),
#             "api_key": str(uuid4()),
#             "related_client_id": user.inserted_id,
#             "host_name": domain,
#             'session_cooldown': '15d',
#             'email_header': 'Validate email',
#             'email_body': 'Use code OTP_HERE',
#             'message_body': 'Use OTP_HERE to verify',
#             'email_domain': 'sawolabs.com',
#             'main_bg_color': '#ffffff',
#             'btn_bg_color': '#ffdb59',
#             'btn_text_color': '#000000'
#         }
#         sawo_clients_projects_collection.insert_one(base_project)
#         return base_project.get('api_key', '')
#     else:
#         shopify_project = sawo_clients_projects_collection.find_one({
#             'related_client_id': sawo_client['_id'],
#             'host_name': domain
#         })
#         if shopify_project:
#             return shopify_project.get('api_key', '')
#         base_project = {
#             "project_name": shop_name,
#             "project_id": str(uuid4()),
#             "api_key": str(uuid4()),
#             "related_client_id": sawo_client['_id'],
#             "host_name": domain,
#             'session_cooldown': '15d',
#             'email_header': 'Validate email',
#             'email_body': 'Use code OTP_HERE',
#             'message_body': 'Use OTP_HERE to verify',
#             'email_domain': 'sawolabs.com',
#             'main_bg_color': '#ffffff',
#             'btn_bg_color': '#ffdb59',
#             'btn_text_color': '#000000'
#         }
#         sawo_clients_projects_collection.insert_one(base_project)
#         return base_project.get('api_key', '')

def WPpassHash(id):
    add = id[(len(id)//2):len(id)]
    wpPass = ''.join(reversed(id)).join(add)
    return encrypt(wpPass, "SaW0 LoV35 W0RdPrEs5")
