from django.urls import path

from core import (apis, apis_wp)

urlpatterns = [
    path('verification/initiate/', apis.VerificationInitiateAPI.as_view()),
    path('verification/', apis.VerificationAPI.as_view()),
    path('getprojectinfo/', apis.GetProjectInfoAPI.as_view()),
    path('userverify/', apis.UserVerificationAPI.as_view()),
    path('identifierCheck/<str:project_id>/', apis.IdentifierCheck.as_view()),

    #     API for Cap on OTP limit
    path('blockdevice/<str:request_type>', apis.BlockDevice.as_view()),

    # Trusted Device APIs
    path('secondary_trusted_device/',
         apis.SecondaryTrustedDeviceAPI.as_view(),
         name='sec_trusted_device'),
    path('register_device/',
         apis.DeviceRegisterAPI.as_view(),
         name='register_device'),

    # Shopify APIs
    path('myshopify/verify/<str:shop_name>/',
         apis.ShopifyIntegrateAPI.as_view()),
    path('myshopify/verify/', apis.ShopifyIntegrateAPI.as_view()),
    path('myshopify/delete/<str:shop_name>/',
         apis.ShopifyIntegrateAPI.as_view()),
    path('myshopify/customer/<str:shop_name>/',
         apis.ShopifyCustomerAPI.as_view()),
    path('myshopify/shop',
         apis.delete_shopify_customers),
    path('myshopify/shop/send_customer',
         apis.send_shopify_cust_details),

    # Wordpress APIs
    path('wordpress/customer/<str:host_name>/',
         apis_wp.WPCustomerAPI.as_view()),

    # BigCommerce APIs
    path('mybigcommerce/verify/<str:store_hash>/',
         apis.BigCommerceIntegrateAPI.as_view()),
    path('mybigcommerce/verify/', apis.BigCommerceIntegrateAPI.as_view()),
    path('mybigcommerce/delete/<str:store_hash>/',
         apis.BigCommerceIntegrateAPI.as_view()),
]
