from boto3 import client
from core.exceptions import NotSubscribed
from uuid import uuid4
import core
import json
import requests
from datetime import datetime
from django.template import loader
from django.core.mail import EmailMultiAlternatives

from authhelper.collections import sawo_users_collection
from client.collections import sawo_clients_projects_collection

from core.collections import (
    trusted_devices_collection, devices_subscription_collection,
    user_collection,
    sawo_cms_collection)

from django.conf import settings
from bson.objectid import ObjectId
from datetime import datetime
from onesignal_sdk.client import Client
import requests
import time


def toObjectId(string):
    try:
        return ObjectId(string)
    except Exception:
        return ""


def send_plan_expire_email(user_name: str, address: str) -> int:
    email_template = loader.get_template('core/emails/plan-expiry.html')
    msg = EmailMultiAlternatives(
        'Validate email',
        'Dear {}, This is to inform you that current plan with SAWO has ' +
        'expired. To continue using our service you need to buy another plan.'.
        format(user_name), 'billing-noreply@sawolabs.com', [address])
    msg.attach_alternative(email_template.render({
        'username': user_name,
    }), 'text/html')
    return msg.send()


def send_expiry(client_id: str) -> int:
    user = sawo_users_collection.find_one({"_id": toObjectId(client_id)})
    send_plan_expire_email(user['username'], user['identifier'])


# FUNCTION FOR SENDING WELCOME EMAIL
def send_welcome_email(profile_data, has_project) -> int:

    email_template = loader.get_template('core/emails/welcome.html')
    msg = EmailMultiAlternatives(
        'Welcome to SAWO Labs',
        '',
        f"noreply@sawolabs.com",
        [profile_data['email']]
    )

    msg.attach_alternative(email_template.render({'user_name': profile_data['username'], 'has_project': has_project}),
                           'text/html')
    try:
        return msg.send()
    except Exception:
        return 0


def delay_welcome_email(profile_data, user_id):
    time.sleep(300)
    has_project = True if sawo_clients_projects_collection.find_one(
        {'related_client_id': user_id}
    ) else False

    send_welcome_email(profile_data, has_project)


def send_otp_email(project: dict,
                   raw_identifier: str,
                   otp_info: dict) -> int:
    email_template = loader.get_template('core/emails/otp.html')
    email_customised_template = loader.get_template(
        'core/emails/otp_customised.html')
    email_body = project['email_body'].replace("OTP_HERE", otp_info['code'])
    company_name = ""
    company_logo_email = ""
    company_from_name = ""
    msg = EmailMultiAlternatives(project['email_header'],
                                 email_body,
                                 f"otp-noreply@{project['email_domain']}",
                                 [raw_identifier])
    try:
        company_name = project['company_name']
        company_logo_email = project['company_logo_email']
        company_from_name = project['from_name']
    except:
        pass
    if(len(company_name) > 0):
        msg.attach_alternative(email_customised_template.render({'email_body': email_body, 'company_name': company_name, 'company_logo_email': company_logo_email, 'company_from_name': company_from_name}),
                               'text/html')
    else:
        msg.attach_alternative(email_template.render({'email_body': email_body}),
                               'text/html')
    try:
        return msg.send()
    except Exception:
        return 0


# TODO: Correct return type


def send_otp_sms(project: dict, raw_identifier: str, otp_info: dict) -> str:
    try:
        snsclient = client('sns',
                           aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                           aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                           region_name='ap-south-1')
        sms_content = project['message_body'] + '\n @' + \
            project['host_name'] + ' #OTP_HERE @websdk.sawolabs.com'

        sms_body = sms_content.replace(
            "OTP_HERE", otp_info['code'])
        response = snsclient.publish(PhoneNumber=raw_identifier,
                                     Message=sms_body,
                                     MessageAttributes={
                                         'AWS.SNS.SMS.SMSType': {
                                             'DataType': 'String',
                                             'StringValue': 'Transactional'
                                         }
                                     })
        return response
    except Exception:
        return 0

# TODO: Correct return type


def send_otp(project_id: str,
             identifier_type: str,
             raw_identifier: str,
             otp_info: dict) -> int:
    project = sawo_clients_projects_collection.find_one(
        {'_id': toObjectId(project_id)})
    if identifier_type == 'email':
        return send_otp_email(project, raw_identifier, otp_info)
    if identifier_type == 'phone_number_sms':
        return send_otp_sms(project, raw_identifier, otp_info)


def register_device(device_info: dict):
    device_id = device_info['device_id']

    is_device_subscribed = devices_subscription_collection.find_one(
        {'device_id': device_id})

    if not is_device_subscribed:
        devices_subscription_collection.insert_one(device_info)
    elif is_device_subscribed['device_token'] != device_info['device_token']:
        if is_device_subscribed.get('tokens', False):
            device_info['tokens'] = is_device_subscribed['tokens']
            device_info['tokens'].append(is_device_subscribed['device_token'])
        else:
            device_info['tokens'] = [is_device_subscribed['device_token']]
        devices_subscription_collection.update({
            'device_id': device_id
        }, device_info)


def mark_current_device_trusted(
        device_id: str, identifier: str, project_api_key: str):
    subscribed_device = devices_subscription_collection.find_one(
        {'device_id': device_id})
    project = sawo_clients_projects_collection.find_one(
        {'api_key': project_api_key})
    if subscribed_device:
        trusted_devices_collection.update(
            {'identifier': identifier}, {
                'identifier': identifier,
                'related_project_id': project['_id'],
                'subscribed_device_id': subscribed_device['_id'],
                'created_on': datetime.utcnow()
            },
            upsert=True)
    else:
        raise NotSubscribed()


# Sending Notification


onesignal_client = Client(app_id=settings.ONE_SIG_API_ID,
                          rest_api_key=settings.ONE_SIG_REST_API_KEY)

headers = {
    'Content-Type': 'application/json',
    'Authorization': (f'key={settings.FCM_SERVER_KEY}')
}

payload = {
    "notification": {},
    'priority': 'high',
}

# device_type:
#   0 ➡ iOS
#   1 ➡ Android


def push_notification(player_id: str,
                      device_type: int,
                      assignedToken: str,
                      tokens: list,
                      notification_body: dict):
    if device_type == 0:
        try:
            response = onesignal_client.send_notification(notification_body)
            print(response.body)
        except Exception as e:
            print(e)
    else:
        # ✔ TODO: check if assigned token is ready by sending silent ping
        #       to available device from gcm server.
        payload["to"] = assignedToken
        resp = requests.post('https://fcm.googleapis.com/fcm/send',
                             json=payload, headers=headers)

        if not resp.json()['failure']:
            try:
                response = onesignal_client.send_notification(
                    notification_body)
                print(response.body)
            except Exception as e:
                print(e)
        else:
            # ✔ TODO: check in the tokens list if any other device token is working
            #       and if it works then update the device entry in onesignal to
            #       point to this device id and if none of them works then
            #       simply return trusted device has uninstalled the app

            for token in tokens:
                payload["to"] = token
                resp = requests.post(
                    'https://fcm.googleapis.com/fcm/send',
                    json=payload,
                    headers=headers)
                if not resp.json()['failure']:
                    # ✔ TODO: for iOS devices strip all non alphanumeric characters
                    if not device_type:
                        pattern = r'[\W_]+'
                        token = pattern.sub('', token)
                    body = {
                        'identifier': token,
                        'notification_types': 1
                    }
                    response = onesignal_client.edit_device(player_id, body)

                    if "success" in response.body:
                        devices_subscription_collection.update_one({
                            'device_id': player_id
                        }, {
                            '$set': {'device_token': token},
                            '$pop': {'tokens': -1}
                        })
                        # Emulate delay
                        time.sleep(2)
                        try:
                            response = onesignal_client.send_notification(
                                notification_body)
                            print()
                            print(response.body)
                        except Exception as e:
                            print(e)
                        return
                devices_subscription_collection.update_one({
                    'device_id': player_id
                }, {
                    '$pop': {'tokens': -1}
                })


def ask_from_trusted_device(trusted_id: str, trusted_device_info,
                            secondary_device: dict):
    notification_payload = {
        # "include_player_ids": [trusted_device_info['device_token']],
        "include_player_ids": [trusted_device_info['device_id']],
        "contents": {
            'en':
                # (f"Do you want to trust following device?\n\n Brand: "
                #  f"{secondary_device.get('device_brand', secondary_device.get('device_type', ''))} \n Model: "
                #  f"{secondary_device.get('device_model', secondary_device.get('device_info', ''))}. \n\n\n"
                #  f" Choose YES to allow this device else NO"),
                "Are you trying to login on another device ?"
        },
        "headings": {
            'en': "SAWO - Verify it's you"
        },
        "priority": 10,
        # "android_channel_id": settings.ONE_SIG_ANDROID_CHANNEL_ID,
        "data": {
            "trusted_id": trusted_id,
            "secondary_id": str(secondary_device['_id']),
            "secondary_device_brand": str(secondary_device.get(
                'device_brand', secondary_device.get('device_type', ''))),
            "secondary_device_model": str(
                secondary_device.get('device_model', ''))
        }
    }
    push_notification(trusted_device_info['device_id'],
                      1 if trusted_device_info['sdk_variant'] == 'android'
                      else 0,
                      trusted_device_info['device_token'],
                      trusted_device_info.get('tokens', []),
                      notification_payload)


def remove_sec_device(trusted_device_id: str, secondary_device_entry: str):
    trusted_devices_collection.update_one(
        {'_id': toObjectId(trusted_device_id),
            secondary_device_entry: {
                '$in': ['pending', 'allowed']
        }
        },
        {'$set': {
            secondary_device_entry: ''
        }})


def remove_denied_sec_device(trusted_device_id: str, secondary_device_entry: str):
    trusted_devices_collection.update_one(
        {'_id': toObjectId(trusted_device_id),
            secondary_device_entry: 'denied'
         },
        {'$set': {
            secondary_device_entry: ''
        }})


def update_cms_id(host_name,
                  identifier):
    user = user_collection.find_one({
        'identifier': {'$in': [core.utils.encrypt(
            identifier, 'we_are_sawo_team'),
            identifier]}
    })
    cms_res = sawo_cms_collection.find_one({
        'domain':
        host_name})
    shop = cms_res.get('host', '')
    token = cms_res.get('token', '')
    try:
        user['shopify'][shop+'_new_user']
        if not user['shopify'][shop+'_new_user']:
            if shop not in user['shopify']:
                r = requests.get('http://' + settings.CMS_SDK_HOST_URL +
                                 '/get_cust_id.php',
                                 {
                                     'identifier':  identifier,
                                     'token': token,
                                     'shop': shop
                                 })
                if r.status_code == 200:
                    try:
                        response = json.loads(r.json())
                    except json.decoder.JSONDecodeError:
                        return
                    if response.get('customers', []):
                        user_collection.update_one({
                            '_id': user['_id']
                        }, {
                            '$set': {
                                f'shopify.{shop}': int(response.get(
                                    'customers',
                                    [{}])[0].get('id', 0))
                            }
                        })
                    else:
                        user_collection.update_one({
                            '_id': user['_id']
                        }, {
                            '$unset': {
                                f'shopify.{shop}_new_user': 1
                            }
                        })
        return
    except KeyError:
        if 'shopify' in user and (shop+'_old_user') in user['shopify']:
            return
    except TypeError:
        pass
    r = requests.get('http://' + settings.CMS_SDK_HOST_URL +
                     '/get_cust_id.php',
                     {
                         'identifier':  identifier,
                         'token': token,
                         'shop': shop
                     })
    if r.status_code == 200:
        try:
            response = json.loads(r.json())
        except json.decoder.JSONDecodeError:
            return

        if response.get('customers', []):
            if user:
                user_collection.update_one({
                    '_id': user['_id']
                }, {
                    '$set': {
                        f'shopify.{shop}': int(response.get(
                            'customers',
                            [{}])[0].get('id', 0)),
                        f'shopify.{shop}_old_user': True
                    }
                })
            else:
                user = {
                    'user_id': str(uuid4()),
                    'created_on': datetime.utcnow(),
                    'identifier': core.utils.encrypt(
                        identifier, 'we_are_sawo_team'),
                    'identifier_type': 'email',
                    'verification_token': core.utils.get_random_string(
                        length=36),
                    'shopify': {
                        f'{shop}': int(response.get(
                            'customers',
                            [{}])[0].get('id', 0)),
                        f'{shop}_old_user': True
                    }
                }
                user_collection.insert_one(user)


def send_shopify_cust_data(shop: str):
    shopify_shop = sawo_cms_collection.find_one({
        'host': shop
    })
    if shopify_shop:
        email_template = loader.get_template(
            'core/emails/shopify_cust_data.html')
        email_body = ("We currently don't store any personal data of the" +
                      " customer, we manage the customer login process using" +
                      " the email id(strongly encrypted)" +
                      " and password hash and the shopify customer id.")
        msg = EmailMultiAlternatives("Know the customer data you requested",
                                     email_body,
                                     f"shopify@sawolabs.com",
                                     [shopify_shop['email']])
        msg.attach_alternative(email_template.render({
            'email_body': email_body
        }),
            'text/html')
        try:
            return msg.send()
        except Exception:
            return 0
