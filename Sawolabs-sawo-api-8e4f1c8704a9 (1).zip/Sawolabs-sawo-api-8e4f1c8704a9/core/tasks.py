from celery import shared_task

from core.utils2 import (send_expiry,
                         send_otp,
                         register_device,
                         mark_current_device_trusted,
                         remove_sec_device,
                         remove_denied_sec_device,
                         ask_from_trusted_device,
                         update_cms_id,
                         send_shopify_cust_data)


@shared_task
def task_send_otp(project_id, identifier_type, raw_identifier, otp_info):
    return send_otp(project_id, identifier_type, raw_identifier, otp_info)


@shared_task
def task_send_expiry(client_id):
    return send_expiry(client_id)


@shared_task
def task_register_device(device_info):
    return register_device(device_info)


@shared_task
def task_mark_current_device_trusted(
        subscribed_device, user_identifier, project_api_key):
    return mark_current_device_trusted(
        subscribed_device, user_identifier, project_api_key)


@shared_task
def task_remove_sec_device(trusted_device_id,
                           secondary_device_entry):
    return remove_sec_device(trusted_device_id,
                             secondary_device_entry)


@shared_task
def task_remove_denied_sec_device(trusted_device_id,
                                  secondary_device_entry):
    return remove_denied_sec_device(trusted_device_id,
                                    secondary_device_entry)


@shared_task
def task_ask_from_trusted_device(trusted_device_id,
                                 trusted_device_info,
                                 secondary_device):
    return ask_from_trusted_device(trusted_device_id,
                                   trusted_device_info,
                                   secondary_device)


@shared_task
def task_send_shopify_cust_data(shop):
    return send_shopify_cust_data(shop)


@shared_task
def task_update_cms_id(host_name, identifier):
    return update_cms_id(host_name, identifier)
