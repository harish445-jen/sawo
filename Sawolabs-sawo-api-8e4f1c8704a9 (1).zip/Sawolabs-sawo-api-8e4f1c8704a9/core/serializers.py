from rest_framework import serializers

from client.collections import (sawo_clients_projects_collection,
                                sawo_clients_plans_collection)

from core import constants
from core.collections import (devices_subscription_collection)


class VerificationInitiateSerializer(serializers.Serializer):
    identifier_type = serializers.ChoiceField(
        choices=constants.IDENTIFIER_TYPE_CHOICES)
    identifier = serializers.CharField()
    country_code = serializers.CharField(required=False)
    public_key = serializers.CharField()
    device_type = serializers.ChoiceField(
        choices=constants.DEVICE_TYPE_CHOICES)
    device_info = serializers.CharField()
    session_id = serializers.CharField()
    host_name = serializers.CharField(allow_blank=True)
    secret_key = serializers.CharField(allow_blank=True)
    device_id = serializers.CharField(allow_blank=True)
    device_token = serializers.CharField(allow_blank=True)
    project_id = serializers.CharField()
    is_from_shopify = serializers.BooleanField(required=False)
    isfromBubble = serializers.BooleanField(required=False)
    recaptcha_token = serializers.CharField(required=False, allow_blank=True)
    api_key = serializers.CharField()
    blocked_request_timestamp = serializers.DateTimeField()

    def validate(self, data):
        if data['host_name'] or data['secret_key']:
            return data
        raise serializers.ValidationError(
            "Either host name or app's secret key is required.")


class VerificationSerializer(serializers.Serializer):
    identifier_type = serializers.ChoiceField(
        choices=constants.IDENTIFIER_TYPE_CHOICES)
    identifier = serializers.CharField()
    country_code = serializers.CharField(required=False)
    public_key = serializers.CharField()
    device_type = serializers.ChoiceField(
        choices=constants.DEVICE_TYPE_CHOICES)
    device_id = serializers.CharField()
    device_info = serializers.CharField()
    session_id = serializers.CharField()
    otp = serializers.CharField(allow_blank=True)
    signature = serializers.CharField()
    challenge = serializers.CharField()
    api_key = serializers.UUIDField()
    host_name = serializers.CharField(allow_blank=True)
    secret_key = serializers.CharField(allow_blank=True)
    device_token = serializers.CharField(allow_blank=True)
    is_from_shopify = serializers.BooleanField(required=False)
    isfromBubble = serializers.BooleanField(required=False)
    isfromWP = serializers.BooleanField(required=False)

    def validate(self, data):
        if data['host_name'] or data['secret_key']:
            return data
        raise serializers.ValidationError(
            "Either host name or app's secret key is required.")


class BlockedDeviceSerializer(serializers.Serializer):
    # ip_address = serializers.CharField(required=False, allow_blank=True)
    device_id = serializers.CharField()
    device_type = serializers.CharField()
    max_otp_requests = serializers.IntegerField()
    blocked_time = serializers.CharField()
    blocked_timespan = serializers.IntegerField()
    timestamp = serializers.DateTimeField()
    time_of_blocking = serializers.DateTimeField(
        required=False, allow_null=True)
    # otp_requests_count = serializers.IntegerField(default=0)
    # project_id = serializers.CharField()
    api_key = serializers.CharField()
    secret_key = serializers.CharField(allow_blank=True)
    host_name = serializers.CharField(allow_blank=True)


class UserVerificationSerializer(serializers.Serializer):
    user_id = serializers.UUIDField()
    verification_token = serializers.CharField()


class ProjectInfoSerializer(serializers.Serializer):
    api_key = serializers.UUIDField()
    host_name = serializers.CharField(allow_blank=True)
    secret_key = serializers.CharField(allow_blank=True)
    device_id = serializers.CharField()
    session_id = serializers.CharField()
    public_key = serializers.CharField()
    identifier_type = serializers.ChoiceField(
        choices=constants.IDENTIFIER_TYPE_CHOICES, allow_blank=True)
    device_type = serializers.ChoiceField(
        choices=constants.DEVICE_TYPE_CHOICES)
    device_info = serializers.CharField()

    def validate(self, data):
        host_name_updated = ""
        if 'www' in str(data['host_name']):
            host_name_updated = str(data['host_name']).replace('www.', '')
        else:
            host_name_updated = str(data['host_name'])
        project = sawo_clients_projects_collection.find_one({
            'api_key': str(data['api_key']),
            '$or': [{
                    'host_name': host_name_updated
                    }, {
                    'secret_key': str(data['secret_key'])
                    }]
        })
        if project and data['device_type'] != "browser":
            if str(data['secret_key']) != project['secret_key']:
                raise serializers.ValidationError('Incorrect Secret Key')
        if project:
            data['identifier'] = ''
            data.pop('api_key', None)
            data.pop('host_name', None)
            data.pop('secret_key', None)

            # Taking useful values in variables
            client_id = project['related_client_id']

            # check active plan
            active_plan = sawo_clients_plans_collection.find_one(
                {
                    'is_active': True,
                    'related_client_id': client_id
                }) or sawo_clients_plans_collection.find_one_and_update(
                    {
                        'is_expired': False,
                        'related_client_id': client_id
                    }, {'$set': {
                        'is_active': True
                    }})
            # If already expired then no need to log auth simple
            # return with error
            if not active_plan:
                raise serializers.ValidationError("Plan has expired")
            return {
                'data': data,
                'project': project
            }
        raise serializers.ValidationError('No Project Found')


class IdentifierCheckSerializer(serializers.Serializer):
    identifier = serializers.CharField(required=True)
    country_code = serializers.CharField(required=False, allow_blank=True)
    identifier_type = serializers.CharField(required=True)


class SecondaryTrustedDeviceSerializer(serializers.Serializer):
    trusted_id = serializers.CharField()
    secondary_id = serializers.CharField()
    device_id = serializers.CharField()
    trusted_response = serializers.ChoiceField(
        choices=constants.TRUSTED_RESPONSE_CHOICES)


class SecondaryStatusCheckSerializer(serializers.Serializer):
    trusted_id = serializers.CharField()
    secondary_id = serializers.CharField()


class DeviceRegisterSerializer(serializers.Serializer):
    device_brand = serializers.CharField()
    device_name = serializers.CharField()
    device_model = serializers.CharField()
    device_id = serializers.CharField()
    device_token = serializers.CharField()
    sdk_variant = serializers.CharField()


class MarkTrustedDevice(serializers.Serializer):
    identifier = serializers.CharField()
    device_id = serializers.CharField()

    def validate(self, data):
        subscribed_device = devices_subscription_collection.find_one(
            {'device_id': data['device_id']})
        if subscribed_device:
            return {
                'subscribed_device': subscribed_device,
                'identifier': data['identifier']
            }
        else:
            raise serializers.ValidationError('No Subscribed device found.')


class ShopifyIntegrateSerializer(serializers.Serializer):
    host = serializers.CharField(allow_null=True, required=False)
    token = serializers.CharField(allow_null=True, required=False)
    domain = serializers.CharField(allow_null=True, required=False)
    email = serializers.CharField(allow_null=True, required=False)
    _id = serializers.CharField(allow_null=True, required=False)
    api_key = serializers.CharField(allow_null=True,
                                    allow_blank=True,
                                    required=False)
    identifier = serializers.CharField(allow_null=True, required=False)
    login_path = serializers.CharField(allow_null=True,
                                       allow_blank=True,
                                       required=False)

    def validate(self, data):
        if ('_id' in data and data['_id']) or ('host' in data
                                               and data['host']):
            return data
        raise serializers.ValidationError(
            "Either host name or id is required.")


class ShopifyCustomerSerializer(serializers.Serializer):
    shop_name = serializers.CharField()


class BigCommerceIntegrateSerializer(serializers.Serializer):
    store_hash = serializers.CharField(allow_null=True, required=False)
    token = serializers.CharField(allow_null=True, required=False)
    _id = serializers.CharField(allow_null=True, required=False)
    api_key = serializers.CharField(allow_null=True,
                                    allow_blank=True,
                                    required=False)
    identifier = serializers.CharField(allow_null=True, required=False)
    login_trigger_method = serializers.CharField(allow_null=True,
                                                 required=False)
    redirect_link = serializers.CharField(allow_null=True,
                                          allow_blank=True,
                                          required=False)
    restricted_urls = serializers.CharField(allow_null=True,
                                            allow_blank=True,
                                            required=False)
    script_uuid = serializers.CharField(allow_null=True,
                                        allow_blank=True,
                                        required=False)

    def validate(self, data):
        if ('_id' in data and data['_id']) or ('store_hash' in data
                                               and data['store_hash']):
            return data
        raise serializers.ValidationError(
            "Either store_hash or id is required.")
