# Classes
from django.core.management.base import BaseCommand
from client.collections import (sawo_auths_log_collection)


class Command(BaseCommand):
    help = "This is a command to count auths in the month of april"

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("Gathering & Processing data..."))
        self.stdout.write(self.style.SUCCESS("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"))
        self.stdout.write(self.style.SUCCESS("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"))
        self.stdout.write(self.style.SUCCESS("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"))
        self.stdout.write(self.style.SUCCESS("Working on it........"))
        auth_log = sawo_auths_log_collection.find({})
        auth_array=[]
        for i in auth_log:
            try:
                if i['auths']:
                    for n in i['auths']:
                        for x in n['auths_list']:
                            if (x['createdAt'].month==4):
                                auth_array.append(n)
            except:
                pass
        self.stdout.write(self.style.SUCCESS("Done. Your AUTHS Consumed for April is "))
        self.stdout.write(self.style.SUCCESS(len(auth_array)))
        
