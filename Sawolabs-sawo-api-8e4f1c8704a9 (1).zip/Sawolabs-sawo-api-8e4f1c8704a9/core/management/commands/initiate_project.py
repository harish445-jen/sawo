from uuid import uuid4
from datetime import datetime

from django.core.management.base import BaseCommand
from django.utils.crypto import get_random_string

from admindash.utils import create_plan
from core.collections import user_collection
from authhelper.collections import sawo_users_collection
from client.collections import sawo_clients_projects_collection
from decimal import Decimal


class Command(BaseCommand):
    help = "This command will make necessary entries in"
    " db to help initialize the project"

    def add_arguments(self, parser):
        parser.add_argument('identifier_email', type=str)
        parser.add_argument('project_name', type=str)

    def handle(self, *args, **options):
        initial_user = {
            'user_id': str(uuid4()),
            'created_on': datetime.utcnow(),
            'identifier': options['identifier_email'],
            'identifier_type': 'email',
            'verification_token': get_random_string(length=36)
        }
        user_collection.insert_one(initial_user)
        sawo_users_collection.insert_one({
            'identifier':
            initial_user['identifier'],
            'is_sawo_admin':
            True,
            'is_sawo_client':
            True,
            'joined_at': datetime.utcnow()
        })
        initial_sawo_user = sawo_users_collection.find_one(
            {'identifier': initial_user['identifier']}, {
                'auths_remaining': 0,
                'auths_filled': 0
            })
        initial_project = {
            "project_name": options['project_name'],
            "project_id": str(uuid4()),
            "api_key": str(uuid4()),
            "related_client_id": initial_sawo_user['_id'],
            "host_name": 'sawolabs.com',
            'session_cooldown': '15d',
            'email_header': 'Validate email',
            'email_body': 'Use code OTP_HERE',
            'message_body': 'Use OTP_HERE to verify',
            'email_domain': 'sawolabs.com',
            'main_bg_color': '#ffffff',
            'btn_bg_color': '#ffde40',
            'btn_text_color': '#000000'
        }
        sawo_clients_projects_collection.insert_one(initial_project)
        plan_details = {
            'plan_type': 'Free',
            'auths_offered': 500000,
            'plan_price': Decimal(0),
            'plan_currency_code': 'INR',
            'client_id': initial_sawo_user['_id']
        }
        create_plan(plan_details, True)
        self.stdout.write(
            self.style.SUCCESS(
                "Project initialized successfully,"
                " use the identifier to login in admin and client console"))
        self.stdout.write(
            self.style.SUCCESS("Identifier used: {}".format(
                initial_user['identifier'])))
        self.stdout.write(
            self.style.SUCCESS("Project name: {}".format(
                initial_project['project_name'])))
        self.stdout.write(
            self.style.SUCCESS("Project API KEY: {}".format(
                initial_project['api_key'])))
