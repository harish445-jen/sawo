from django.core.management.base import BaseCommand
from django.utils.crypto import get_random_string
from admindash.collections import (currency_rates_collection,
                                   sawo_referrals_collection)
from authhelper.collections import (sawo_users_collection)
from admindash.utils import (create_plan)

from core.collections import (
    verification_collection, device_verification_collection)

from client.collections import (sawo_clients_projects_collection,
                                sawo_clients_plans_collection,
                                sawo_auths_log_collection)
from admindash.utils import generateReferralCode
from client.utils import generate_secret_key
from collections import Counter
from bson.objectid import ObjectId
from pathlib import Path
import csv
from datetime import date
from django.utils.timezone import now, timedelta


class Command(BaseCommand):
    help = "This is a temporary command to sync db with changes."

    def handle(self, *args, **options):
        # sawo_clients_projects_collection.update_many({}, {
        #     '$set': {
        #         'message_body': 'Use OTP_HERE to verify',
        #     }
        # })
        p = Path('plansubscription')
        p.mkdir(exist_ok=True)
        with open(p / f'{date.today()}.csv', 'w') as my_file:
            wr = csv.writer(my_file, delimiter=',')
            wr.writerow(['username',
                         'plan type',
                         'plan price',
                         'auths offered',
                         'plan starts on',
                         'last plan expire(s/d) on'
                         ])
            clients = sawo_users_collection.find({})
            for client in clients:
                # Find current active plan
                current_plan = sawo_clients_plans_collection.find_one({
                    'is_expired': False,
                    'related_client_id': client['_id'],
                    'is_active': True,
                })
                if current_plan:
                    # Check if current plan will expire in some time
                    if (current_plan['start_date'] + timedelta(days=30) <=
                            now() + timedelta(days=1)):
                        # Even though it will expire, check for backup plans
                        has_other_plan = sawo_clients_plans_collection.find_one({
                            'is_expired': False,
                            'related_client_id': client['_id'],
                            'start_date': {
                                '$gt': now() - timedelta(days=30)
                            },
                            '_id': {
                                '$ne': current_plan['_id']
                            }
                        })
                        if not has_other_plan:
                            auths_from_referrals = 0
                            for used_referral in current_plan.get(
                                    'used_referrals', []):
                                auths_from_referrals += used_referral[
                                    'auths_count']
                            # Finally create the backup plan
                            pl = create_plan({
                                "plan_type": current_plan['plan_type'],
                                "plan_price": current_plan['plan_price'].to_decimal(),
                                "plan_currency_code": current_plan[
                                    'plan_currency_code'],
                                "client_id": client['_id'],
                                "auths_offered": current_plan['auths_offered'] + auths_from_referrals
                            }, False, True)
                            wr.writerow([client.get('username', 'ID ' + str(client['_id'])),
                                         current_plan['plan_type'],
                                         current_plan['plan_price'].to_decimal(
                            ),
                                current_plan['auths_offered'],
                                pl['start_date'],
                                current_plan['start_date'] +
                                timedelta(days=30)
                            ])
                else:
                    # find the latest plan expired
                    latest_plan = sawo_clients_plans_collection.find({
                        'is_expired': True,
                        'related_client_id': client['_id'],
                        'is_active': False,
                    }).sort([('expire_date', -1)]).limit(1)
                    if latest_plan.count() > 0:
                        for plan in latest_plan:
                            has_other_plan = sawo_clients_plans_collection.find_one({
                                'is_expired': False,
                                'related_client_id': client['_id'],
                                'start_date': {
                                    '$gt': now() - timedelta(days=30)
                                },
                                '_id': {
                                    '$ne': plan['_id']
                                }
                            })
                            if not has_other_plan:
                                auths_from_referrals = 0
                                for used_referral in plan.get(
                                        'used_referrals', []):
                                    auths_from_referrals += used_referral[
                                        'auths_count']
                                # Renew it if finished 30 days
                                if (plan['start_date']
                                        + timedelta(days=30) <= now()):
                                    pl = create_plan({
                                        "plan_type": plan['plan_type'],
                                        "plan_price": plan['plan_price'].to_decimal(),
                                        "plan_currency_code": plan['plan_currency_code'],
                                        "client_id": client['_id'],
                                        "auths_offered": plan['auths_offered'] + auths_from_referrals
                                    }, False, True)
                                    wr.writerow([client.get('username', 'ID ' + str(client['_id'])),
                                                 plan['plan_type'],
                                                 plan['plan_price'].to_decimal(),
                                                 plan['auths_offered'],
                                                 pl['start_date'],
                                                 plan['start_date'] +
                                                 timedelta(days=30)
                                                 ])
                    else:
                        pl = create_plan({
                            "plan_type": 'Free',
                            "plan_price": 0.0,
                            "plan_currency_code": 'INR',
                            "client_id": client['_id'],
                            "auths_offered": 5000
                        }, False, True)
                        wr.writerow([client.get('username', 'ID ' + str(client['_id'])),
                                     'Free',
                                     0.0,
                                     5000,
                                     pl['start_date'],
                                     'First Plan'
                                     ])
        # sawo_clients_plans_collection.delete_many({
        #     'start_date': {'$gt': now() - timedelta(hours=16)}
        # })
        self.stdout.write(self.style.SUCCESS("Done."))
