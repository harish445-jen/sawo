from django.core.management.base import BaseCommand

from admindash.collections import sawo_referrals_collection


class Command(BaseCommand):
    help = "This command will help to create initial referrals to serve client"

    def handle(self, *args, **options):
        referral2000 = {"auths_offered": 2000,
                        "referral_available": 15, "code_text": "SAWOADD2000"}
        referral3000 = {"auths_offered": 3000,
                        "referral_available": 15, "code_text": "SAWOADD3000"}
        referral5000 = {"auths_offered": 5000,
                        "referral_available": 15, "code_text": "SAWOADD5000"}
        sawo_referrals_collection.insert_one(
            referral2000)
        sawo_referrals_collection.insert_one(
            referral3000)
        sawo_referrals_collection.insert_one(
            referral5000)
        self.stdout.write(self.style.SUCCESS("Done."))
