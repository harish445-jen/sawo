# Classes
from django.core.management.base import BaseCommand

# DB Collections
# from authhelper.collections import sawo_users_collection
# from client.collections import sawo_clients_plans_collection

# utility libraries
import csv
# from datetime import date, datetime
# from django.utils.timezone import utc

from client.utils import get_client_data


class Command(BaseCommand):
    help = "This is a command to extract client data to csv"

    def add_arguments(self, parser):
        parser.add_argument('--month', type=str)

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("Gathering & Processing data..."))
        if options['month']:
            datas = get_client_data(options['month'])
            csv_file_name = f"client_report_{options['month']}.csv"
        else:
            datas = get_client_data()
            csv_file_name = 'client_report.csv'
        with open(csv_file_name, 'w') as client_report_file:
            wr = csv.writer(client_report_file, delimiter=',')
            wr.writerow([
                'username',
                'email_id',
                'auths_remaining',
                'ref_id',
                'joined_date',
                'projects'
            ])
            for data in datas:
                wr.writerow([
                    data['username'],
                    data['email_id'],
                    data['auths_remaining'],
                    data['ref_id'],
                    data['joined_date'],
                    ' '.join(data['projects'])
                ])

        # sawo_clients = sawo_users_collection.find({
        #     'is_sawo_client': True
        # })

        # with open('client_report.csv', 'w') as client_report_file:
        #     wr = csv.writer(client_report_file, delimiter=',')
        #     wr.writerow(['username',
        #                  'identifier',
        #                  'reference id',
        #                  'joining date'
        #                  ])
        #     for client in sawo_clients:
        #         first_plan = sawo_clients_plans_collection.find({
        #             '$or': [
        #                 {
        #                     'related_client_id': client['_id']
        #                 },
        #                 {
        #                     'related_client_id': str(client['_id'])
        #                 }
        #             ]
        #         }).sort([('start_date', 1)]).limit(1)
        #         if first_plan.count() > 0:
        #             first_plan = first_plan[0]
        #             if first_plan['start_date'] >=  \
        #                 datetime.combine(date(2021, 3, 1), datetime.min.time()).replace(tzinfo=utc) and \
        #                 first_plan['start_date'] <= \
        #                 datetime.combine(date(2021, 4, 1),
        #                                  datetime.min.time()).replace(tzinfo=utc):
        #                 wr.writerow([
        #                     client.get('username', ''),
        #                     client.get('identifier', ''),
        #                     client.get('ref_id', ''),
        #                     first_plan.get('start_date', '')
        #                 ])
        self.stdout.write(self.style.SUCCESS("Done."))
