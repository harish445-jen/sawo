from django.core.management.base import BaseCommand
from paymentgateway.collections import sawo_razorpay_plans
from sawo.settings.base import get_env_var

import razorpay
import json

client = razorpay.Client(auth=(get_env_var("RAZORPAY_KEY_ID"),
                               get_env_var("RAZORPAY_SECRET")))

CODE_TO_COUNTRY = {
    'IN': 'India',
    'NP': 'Nepal',
    'BT': 'Bhutan',
    'BD': 'Bangladesh',
    'AF': 'Afghanistan',
    'PK': 'Pakistan',
    'LK': 'Sri Lanka',
    'MV': 'Maldives',
    'AE': 'United Arab Emirates (The)',
    'SA': 'Saudi Arabia',
    'IL': 'Israel',
    'EG': 'Egypt',
    'BH': 'Bahrain',
    'KW': 'Kuwait',
    'LB': 'Lebanon',
    'QA': 'Qatar',
    'JO': 'Jordan',
    'OM': 'Oman',
    'TR': 'Turkey',
    'YE': 'Yemen',
    'UG': 'Uganda',
    'RW': 'Rwanda',
    'KE': 'Kenya',
    'MU': 'Mauritius',
    'ET': 'Ethiopia',
    'QW': 'Zimbabwe',
    'ZM': 'Zambia',
    'NA': 'Namibia',
    'NG': 'Nigeria',
    'SL': 'Sierra Leone',
    'AU': 'Australia',
    'US': 'United States of America (The)',
    'GB': 'United Kingdom of Great Britain and Northern Ireland (The)',
    'NL': 'Netherlands (the)',
    'ZA': 'South Africa',
    'ID': 'Indonesia',
    'AR': 'Argentina',
    'TH': 'Thailand',
    'VN': 'Viet Nam',
    'PT': 'Portugal',
    'PH': 'Philippines (the)',
    'MY': 'Malaysia',
    'SG': 'Singapore',
    'EE': 'Estonia',
    'MM': 'Myanmar',
}


class Command(BaseCommand):
    help = "This command will help to create plans in razorpay"

    def handle(self, *args, **options):
        with open('pricing.json') as f:
            data = json.load(f)
            for plan in data.get('plans', []):
                for cc, price in plan.get('price', {}).items():
                    self.stdout.write(self.style.SUCCESS(
                        f'Creating plan {plan["plan_name"]}' +
                        f' for {CODE_TO_COUNTRY[cc]}'))
                    new_plan = client.plan.create(data={
                        'period': 'monthly',
                        'interval': 1,
                        'item': {
                            'name': f'{plan["plan_name"]} ({cc})',
                            'amount': price * 100,
                            'currency': 'INR' if cc == 'IN' else 'USD',
                            'description': f'{plan["plan_name"]}' +
                            f' for {CODE_TO_COUNTRY[cc]}'
                        }
                    })
                    sawo_razorpay_plans.insert_one({
                        'plan_type': plan["plan_name"],
                        'country_code': cc,
                        'plan_id': new_plan['id']
                    })
                    self.stdout.write(self.style.SUCCESS(
                        f'Done creating plan {plan["plan_name"]}' +
                        f' for {CODE_TO_COUNTRY[cc]}'))
        self.stdout.write(self.style.SUCCESS("Done."))
